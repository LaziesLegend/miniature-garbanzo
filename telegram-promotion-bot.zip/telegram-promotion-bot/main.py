import logging
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    ConversationHandler,
    filters
)

from config import BOT_TOKEN, ADMIN_ID
from database import Database
from handlers.start import start_command
from handlers.menu import get_main_menu
from handlers.wallet import balance_callback, transactions_callback
from handlers.campaign import (
    create_campaign_callback,
    campaign_members_selected,
    campaign_channel_received,
    my_campaigns_callback,
    cancel_campaign,
    CAMPAIGN_MEMBERS,
    CAMPAIGN_CHANNEL
)
from handlers.deposit import (
    deposit_callback,
    deposit_amount_received,
    deposit_method_selected,
    deposit_proof_received,
    cancel_deposit,
    DEPOSIT_AMOUNT,
    DEPOSIT_METHOD,
    DEPOSIT_PROOF
)
from handlers.referral import referral_callback
from handlers.admin import (
    admin_panel_callback,
    admin_stats_callback,
    admin_deposits_callback,
    admin_approve_deposit,
    admin_reject_deposit,
    admin_add_tokens_start,
    admin_add_tokens_process,
    admin_broadcast_start,
    admin_broadcast_process,
    admin_reset_db_confirm,
    admin_reset_db_execute,
    ADMIN_ADD_TOKENS,
    ADMIN_BROADCAST
)

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

async def main_menu_callback(update: Update, context):
    """Return to main menu"""
    query = update.callback_query
    await query.answer()
    
    text = "🏠 <b>Main Menu</b>\n\nChoose an option:"
    
    await query.edit_message_text(
        text,
        reply_markup=get_main_menu(query.from_user.id),
        parse_mode='HTML'
    )

async def error_handler(update: Update, context):
    """Handle errors"""
    logger.error(f"Update {update} caused error {context.error}")
    
    try:
        if update.effective_message:
            await update.effective_message.reply_text(
                "❌ An error occurred. Please try again or contact support."
            )
    except:
        pass

def main():
    """Start the bot"""
    # Initialize database
    db = Database()
    logger.info("Database initialized")
    
    # Create application
    app = Application.builder().token(BOT_TOKEN).build()
    
    # Campaign conversation handler
    campaign_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(create_campaign_callback, pattern='^create_campaign$')],
        states={
            CAMPAIGN_MEMBERS: [
                CallbackQueryHandler(campaign_members_selected, pattern='^campaign_members_'),
                CallbackQueryHandler(cancel_campaign, pattern='^main_menu$')
            ],
            CAMPAIGN_CHANNEL: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, campaign_channel_received)
            ]
        },
        fallbacks=[CallbackQueryHandler(cancel_campaign, pattern='^main_menu$')],
        allow_reentry=True
    )
    
    # Deposit conversation handler
    deposit_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(deposit_callback, pattern='^deposit$')],
        states={
            DEPOSIT_AMOUNT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, deposit_amount_received),
                CallbackQueryHandler(cancel_deposit, pattern='^main_menu$')
            ],
            DEPOSIT_METHOD: [
                CallbackQueryHandler(deposit_method_selected, pattern='^deposit_method_'),
                CallbackQueryHandler(cancel_deposit, pattern='^main_menu$')
            ],
            DEPOSIT_PROOF: [
                MessageHandler(
                    (filters.TEXT | filters.PHOTO) & ~filters.COMMAND, 
                    deposit_proof_received
                )
            ]
        },
        fallbacks=[CallbackQueryHandler(cancel_deposit, pattern='^main_menu$')],
        allow_reentry=True
    )
    
    # Admin add tokens handler
    admin_add_tokens_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(admin_add_tokens_start, pattern='^admin_add_tokens$')],
        states={
            ADMIN_ADD_TOKENS: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, admin_add_tokens_process)
            ]
        },
        fallbacks=[],
        allow_reentry=True
    )
    
    # Admin broadcast handler
    admin_broadcast_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(admin_broadcast_start, pattern='^admin_broadcast$')],
        states={
            ADMIN_BROADCAST: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, admin_broadcast_process)
            ]
        },
        fallbacks=[],
        allow_reentry=True
    )
    
    # Add handlers
    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(campaign_handler)
    app.add_handler(deposit_handler)
    app.add_handler(admin_add_tokens_handler)
    app.add_handler(admin_broadcast_handler)
    
    # Callback query handlers
    app.add_handler(CallbackQueryHandler(main_menu_callback, pattern='^main_menu$'))
    app.add_handler(CallbackQueryHandler(balance_callback, pattern='^balance$'))
    app.add_handler(CallbackQueryHandler(transactions_callback, pattern='^transactions$'))
    app.add_handler(CallbackQueryHandler(my_campaigns_callback, pattern='^my_campaigns$'))
    app.add_handler(CallbackQueryHandler(referral_callback, pattern='^referral$'))
    
    # Admin handlers
    app.add_handler(CallbackQueryHandler(admin_panel_callback, pattern='^admin_panel$'))
    app.add_handler(CallbackQueryHandler(admin_stats_callback, pattern='^admin_stats$'))
    app.add_handler(CallbackQueryHandler(admin_deposits_callback, pattern='^admin_deposits$'))
    app.add_handler(CallbackQueryHandler(admin_approve_deposit, pattern='^admin_approve_'))
    app.add_handler(CallbackQueryHandler(admin_reject_deposit, pattern='^admin_reject_'))
    app.add_handler(CallbackQueryHandler(admin_reset_db_confirm, pattern='^admin_reset_db$'))
    app.add_handler(CallbackQueryHandler(admin_reset_db_execute, pattern='^admin_reset_confirmed$'))
    
    # Error handler
    app.add_error_handler(error_handler)
    
    # Start bot
    logger.info("Bot started successfully!")
    logger.info(f"Admin ID: {ADMIN_ID}")
    
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
