# Telegram Promotion Bot

A production-ready Telegram bot for managing promotion campaigns with virtual token economy.

## 🌟 Features

- 💰 Token-based wallet system
- 🚀 Campaign creation and management
- 💳 Multi-method deposit system (UPI/Crypto)
- 👥 Referral program with rewards
- ⚙️ Full-featured admin panel
- 📊 Transaction tracking
- 🔒 Security & anti-fraud measures

## 📋 Requirements

- Python 3.10+
- Telegram Bot Token
- Your Telegram User ID (for admin access)

## 🚀 Quick Start

### 1. Get Bot Token

1. Open Telegram and search for [@BotFather](https://t.me/BotFather)
2. Send `/newbot` command
3. Follow the instructions to create your bot
4. Save the token you receive

### 2. Get Your User ID

1. Search for [@userinfobot](https://t.me/userinfobot) on Telegram
2. Send `/start` to the bot
3. Copy your User ID

### 3. Installation

```bash
# Clone or extract the project
cd telegram-promotion-bot

# Install dependencies
pip install -r requirements.txt

# Configure environment variables
# Edit the .env file and add your credentials
```

### 4. Configure .env File

Open `.env` file and replace the placeholder values:

```env
BOT_TOKEN=your_actual_bot_token_here
ADMIN_ID=your_actual_telegram_user_id_here
```

### 5. Run the Bot

```bash
python main.py
```

You should see:
```
INFO - Database initialized
INFO - Bot started successfully!
INFO - Admin ID: YOUR_ID
```

## 📁 Project Structure

```
telegram-promotion-bot/
├── main.py                 # Main bot application
├── database.py            # Database operations
├── config.py              # Configuration settings
├── requirements.txt       # Python dependencies
├── .env                   # Environment variables (SECRET)
├── .gitignore            # Git ignore rules
├── README.md             # This file
└── handlers/             # Bot handlers
    ├── __init__.py
    ├── start.py          # Start command & registration
    ├── menu.py           # Menu keyboards
    ├── wallet.py         # Balance & transactions
    ├── campaign.py       # Campaign management
    ├── deposit.py        # Deposit system
    ├── referral.py       # Referral program
    └── admin.py          # Admin panel
```

## 💰 Platform Economics

- **Member Cost**: 100 tokens per member (internal)
- **Member Price**: 115 tokens per member (user pays)
- **Platform Fee**: 15 tokens per member (profit)
- **Minimum Campaign**: 5 members
- **Referral Bonus**: 50 tokens per successful referral

## 🎮 User Features

### Main Menu Buttons

1. **💰 Balance** - Check token balance
2. **🚀 Create Promotion** - Start new campaign
3. **📊 My Campaigns** - View campaign history
4. **💳 Deposit Tokens** - Add tokens to wallet
5. **👥 Referral** - Get referral link & stats
6. **📜 Transactions** - View transaction history

### Campaign Creation Flow

1. Click "Create Promotion"
2. Select number of members (5-1000)
3. System calculates cost (members × 115 tokens)
4. Enter channel/group link
5. Confirm and pay
6. Campaign goes live!

### Deposit System

1. Click "Deposit Tokens"
2. Enter amount (min 100 tokens)
3. Choose payment method (UPI/Crypto)
4. Submit payment proof
5. Wait for admin approval
6. Tokens added automatically

### Referral System

1. Click "Referral" button
2. Copy your unique link
3. Share with friends
4. Earn 50 tokens per referral
5. Track earnings in real-time

## ⚙️ Admin Features

Admin panel is automatically visible to the user with ID matching `ADMIN_ID` in `.env`

### Admin Panel Options

1. **💰 Add Tokens** - Credit tokens to any user
   - Format: `user_id amount`
   - Example: `123456789 1000`

2. **✅ Approve Deposits** - Review pending deposits
   - View all pending requests
   - Approve or reject with one click
   - Users get instant notification

3. **📊 Statistics** - View platform metrics
   - Total users
   - Total campaigns
   - Platform revenue

4. **📢 Broadcast** - Send message to all users
   - Compose message
   - Sends to entire user base
   - Shows success/fail count

5. **⚠️ Reset Database** - Clear all data
   - Use with extreme caution
   - Requires confirmation
   - Deletes everything

## 🔒 Security Features

- ✅ Environment variable protection
- ✅ SQL injection prevention
- ✅ Anti-double-click protection
- ✅ Input validation
- ✅ Admin-only access controls
- ✅ Transaction logging
- ✅ Error handling

## 🌐 Deployment

### Deploy on Railway

1. Create account on [Railway.app](https://railway.app)
2. Click "New Project" → "Deploy from GitHub"
3. Connect your repository
4. Add environment variables:
   - `BOT_TOKEN`
   - `ADMIN_ID`
5. Click "Deploy"

### Deploy on Render

1. Create account on [Render.com](https://render.com)
2. Click "New" → "Web Service"
3. Connect repository
4. Configure:
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `python main.py`
5. Add environment variables
6. Click "Create Web Service"

### Deploy on Heroku

```bash
# Install Heroku CLI first
heroku login
heroku create your-bot-name
heroku config:set BOT_TOKEN=your_token_here
heroku config:set ADMIN_ID=your_id_here
git push heroku main
```

### Deploy on VPS (Linux)

```bash
# Install Python 3.10+
sudo apt update
sudo apt install python3 python3-pip

# Clone project
git clone your-repo-url
cd telegram-promotion-bot

# Install dependencies
pip3 install -r requirements.txt

# Configure .env file
nano .env
# Add your BOT_TOKEN and ADMIN_ID

# Run with nohup (keeps running after logout)
nohup python3 main.py &

# Or use screen
screen -S telegram-bot
python3 main.py
# Press Ctrl+A then D to detach
```

## 🗄️ Database

The bot uses SQLite database (`bot_database.db`) with the following tables:

- **users** - User accounts and balances
- **campaigns** - Promotion campaigns
- **transactions** - All token movements
- **deposits** - Deposit requests
- **referrals** - Referral tracking

Database is created automatically on first run.

## 🐛 Troubleshooting

### Bot doesn't start
- Check if `BOT_TOKEN` in `.env` is correct
- Verify `ADMIN_ID` is a valid number
- Make sure dependencies are installed

### Commands don't work
- Ensure bot is running (`python main.py`)
- Check bot permissions in your Telegram group
- Review logs for error messages

### Admin panel not visible
- Verify your Telegram User ID matches `ADMIN_ID` in `.env`
- Restart the bot after changing `.env`
- Send `/start` to the bot again

### Database errors
- Delete `bot_database.db` and restart (WARNING: loses all data)
- Check file permissions
- Ensure SQLite is installed

## 📝 Customization

### Change Token Prices

Edit `config.py`:

```python
MEMBER_COST = 100      # Change base cost
MEMBER_PRICE = 115     # Change user price
PLATFORM_FEE = 15      # Change platform fee
MIN_CAMPAIGN_SIZE = 5  # Change minimum
REFERRAL_BONUS = 50    # Change referral reward
```

### Add Payment Methods

Edit `handlers/deposit.py` in the `deposit_method_selected` function to add new payment options.

### Customize Messages

All bot messages are in the handler files. Edit them to match your brand.

## 📞 Support

For issues or questions:
1. Check this README
2. Review error logs
3. Create an issue on GitHub

## 📄 License

MIT License - Free to use and modify

## ⚠️ Important Notes

- Never share your `.env` file or bot token
- Keep regular backups of `bot_database.db`
- Monitor admin panel for suspicious activity
- Update payment details in deposit handlers
- Test thoroughly before launching

## 🎉 You're Ready!

Start your bot and test all features. The referral system will help you grow organically!

**Need help?** Create an issue or check the documentation.

---

Made with ❤️ for the Telegram community
