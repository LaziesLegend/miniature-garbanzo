from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from database import Database
from handlers.menu import get_back_button, get_main_menu
from config import MEMBER_PRICE, PLATFORM_FEE, MIN_CAMPAIGN_SIZE
import logging

logger = logging.getLogger(__name__)

# Conversation states
CAMPAIGN_MEMBERS, CAMPAIGN_CHANNEL = range(2)

# Anti-double-click protection
creating_campaign = set()

async def create_campaign_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start campaign creation process"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    
    # Anti-double-click check
    if user_id in creating_campaign:
        await query.answer("⚠️ Campaign creation in progress...", show_alert=True)
        return CAMPAIGN_MEMBERS
    
    creating_campaign.add(user_id)
    
    # Member selection buttons
    keyboard = []
    member_options = [5, 10, 25, 50, 100, 250, 500, 1000]
    
    row = []
    for i, members in enumerate(member_options):
        cost = members * MEMBER_PRICE
        row.append(InlineKeyboardButton(
            f"{members} ({cost} tokens)",
            callback_data=f"campaign_members_{members}"
        ))
        if (i + 1) % 2 == 0:
            keyboard.append(row)
            row = []
    
    if row:
        keyboard.append(row)
    
    keyboard.append([InlineKeyboardButton("🔙 Cancel", callback_data="main_menu")])
    
    text = f"""
🚀 <b>Create Promotion Campaign</b>

Select the number of members you want:

💰 <b>Price:</b> {MEMBER_PRICE} tokens per member
📊 <b>Minimum:</b> {MIN_CAMPAIGN_SIZE} members

Choose package:
"""
    
    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )
    
    return CAMPAIGN_MEMBERS

async def campaign_members_selected(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle member count selection"""
    query = update.callback_query
    await query.answer()
    
    # Extract member count from callback data
    members = int(query.data.split('_')[-1])
    
    # Store in user data
    context.user_data['campaign_members'] = members
    context.user_data['campaign_cost'] = members * MEMBER_PRICE
    context.user_data['campaign_fee'] = members * PLATFORM_FEE
    
    text = f"""
📝 <b>Campaign Details</b>

Members: {members}
Total Cost: {members * MEMBER_PRICE} tokens

Now send me your channel/group link:
(Example: @yourchannel or https://t.me/yourchannel)
"""
    
    await query.edit_message_text(text, parse_mode='HTML')
    
    return CAMPAIGN_CHANNEL

async def campaign_channel_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle channel link and create campaign"""
    user_id = update.effective_user.id
    channel_link = update.message.text.strip()
    
    db = Database()
    
    # Get campaign details from user data
    members = context.user_data.get('campaign_members')
    total_cost = context.user_data.get('campaign_cost')
    platform_fee = context.user_data.get('campaign_fee')
    
    if not members or not total_cost:
        await update.message.reply_text(
            "❌ Session expired. Please start again.",
            reply_markup=get_back_button()
        )
        creating_campaign.discard(user_id)
        return ConversationHandler.END
    
    # Check balance
    balance = db.get_user_balance(user_id)
    
    if balance < total_cost:
        text = f"""
❌ <b>Insufficient Balance</b>

Required: {total_cost} tokens
Your Balance: {balance} tokens
Needed: {total_cost - balance} tokens

Please deposit tokens first!
"""
        await update.message.reply_text(
            text,
            reply_markup=get_back_button(),
            parse_mode='HTML'
        )
        creating_campaign.discard(user_id)
        return ConversationHandler.END
    
    # Deduct tokens
    db.update_user_tokens(user_id, -total_cost)
    
    # Create campaign
    campaign_id = db.create_campaign(
        user_id, 
        channel_link, 
        members, 
        total_cost, 
        platform_fee
    )
    
    # Add transaction
    db.add_transaction(
        user_id,
        'campaign',
        total_cost,
        f'Campaign #{campaign_id} - {members} members'
    )
    
    # Success message
    text = f"""
✅ <b>Campaign Created Successfully!</b>

Campaign ID: #{campaign_id}
Channel: {channel_link}
Members: {members}
Cost: {total_cost} tokens

Status: <b>Active</b>

Your campaign is now live! Members will be delivered soon.
Track progress in "My Campaigns" section.

New Balance: {balance - total_cost} tokens
"""
    
    await update.message.reply_text(
        text,
        reply_markup=get_main_menu(user_id),
        parse_mode='HTML'
    )
    
    creating_campaign.discard(user_id)
    
    # Clear user data
    context.user_data.clear()
    
    return ConversationHandler.END

async def my_campaigns_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user's campaigns"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    db = Database()
    
    campaigns = db.get_user_campaigns(user_id)
    
    if not campaigns:
        text = "📊 <b>My Campaigns</b>\n\nYou haven't created any campaigns yet."
    else:
        text = "📊 <b>My Campaigns</b>\n\n"
        
        for camp in campaigns[:10]:  # Show last 10
            status_emoji = {
                'active': '🟢',
                'completed': '✅',
                'pending': '🟡',
                'cancelled': '❌'
            }.get(camp['status'], '⚪')
            
            text += f"{status_emoji} <b>Campaign #{camp['id']}</b>\n"
            text += f"Channel: {camp['channel_link']}\n"
            text += f"Members: {camp['delivered_members']}/{camp['target_members']}\n"
            text += f"Status: {camp['status'].capitalize()}\n"
            text += f"Created: {camp['created_at'][:10]}\n\n"
    
    await query.edit_message_text(
        text,
        reply_markup=get_back_button(),
        parse_mode='HTML'
    )

async def cancel_campaign(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancel campaign creation"""
    query = update.callback_query
    user_id = query.from_user.id
    
    creating_campaign.discard(user_id)
    context.user_data.clear()
    
    return ConversationHandler.END
