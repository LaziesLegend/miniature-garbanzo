from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from database import Database
from handlers.menu import get_back_button
from config import ADMIN_ID
import logging

logger = logging.getLogger(__name__)

# Conversation states
DEPOSIT_AMOUNT, DEPOSIT_METHOD, DEPOSIT_PROOF = range(3)

# Anti-duplicate submission
depositing_users = set()

async def deposit_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start deposit process"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    
    # Anti-duplicate check
    if user_id in depositing_users:
        await query.answer("⚠️ Deposit in progress...", show_alert=True)
        return DEPOSIT_AMOUNT
    
    depositing_users.add(user_id)
    
    text = """
💳 <b>Deposit Tokens</b>

Enter the amount of tokens you want to deposit:

<i>Minimum: 100 tokens</i>
"""
    
    keyboard = [[InlineKeyboardButton("🔙 Cancel", callback_data="main_menu")]]
    
    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )
    
    return DEPOSIT_AMOUNT

async def deposit_amount_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle deposit amount"""
    user_id = update.effective_user.id
    
    try:
        amount = int(update.message.text.strip())
        
        if amount < 100:
            await update.message.reply_text(
                "❌ Minimum deposit is 100 tokens. Please try again:"
            )
            return DEPOSIT_AMOUNT
        
        context.user_data['deposit_amount'] = amount
        
        # Method selection
        keyboard = [
            [InlineKeyboardButton("💳 UPI", callback_data="deposit_method_upi")],
            [InlineKeyboardButton("₿ Crypto", callback_data="deposit_method_crypto")],
            [InlineKeyboardButton("🔙 Cancel", callback_data="main_menu")]
        ]
        
        text = f"""
💳 <b>Deposit {amount} Tokens</b>

Select payment method:
"""
        
        await update.message.reply_text(
            text,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='HTML'
        )
        
        return DEPOSIT_METHOD
        
    except ValueError:
        await update.message.reply_text(
            "❌ Invalid amount. Please enter a number:"
        )
        return DEPOSIT_AMOUNT

async def deposit_method_selected(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle payment method selection"""
    query = update.callback_query
    await query.answer()
    
    method = query.data.split('_')[-1].upper()
    context.user_data['deposit_method'] = method
    
    amount = context.user_data.get('deposit_amount', 0)
    
    if method == 'UPI':
        payment_info = """
<b>UPI Payment Details:</b>

UPI ID: <code>payment@upi</code>
Name: Promotion Bot

Send payment and upload screenshot.
"""
    else:  # Crypto
        payment_info = """
<b>Crypto Payment Details:</b>

USDT (TRC20): <code>TRxxxxxxxxxxxxxxxxxxx</code>

Send payment and provide transaction hash.
"""
    
    text = f"""
💳 <b>Deposit {amount} Tokens</b>
Method: {method}

{payment_info}

After payment, send your transaction proof (screenshot or TX hash):
"""
    
    await query.edit_message_text(text, parse_mode='HTML')
    
    return DEPOSIT_PROOF

async def deposit_proof_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle deposit proof submission"""
    user_id = update.effective_user.id
    db = Database()
    
    amount = context.user_data.get('deposit_amount')
    method = context.user_data.get('deposit_method')
    
    # Get proof (text or photo)
    if update.message.photo:
        tx_hash = "Photo submitted"
    else:
        tx_hash = update.message.text.strip()
    
    # Create deposit request
    deposit_id = db.create_deposit(user_id, method, amount, tx_hash)
    
    text = f"""
✅ <b>Deposit Request Submitted</b>

Deposit ID: #{deposit_id}
Amount: {amount} tokens
Method: {method}
Status: Pending Review

Your deposit will be reviewed by admin.
You'll be notified once it's approved!
"""
    
    await update.message.reply_text(
        text,
        reply_markup=get_back_button(),
        parse_mode='HTML'
    )
    
    # Notify admin
    try:
        await context.bot.send_message(
            chat_id=ADMIN_ID,
            text=f"""
🔔 <b>New Deposit Request</b>

Deposit ID: #{deposit_id}
User ID: {user_id}
Amount: {amount} tokens
Method: {method}
Proof: {tx_hash}

Use Admin Panel to approve/reject.
""",
            parse_mode='HTML'
        )
    except Exception as e:
        logger.error(f"Failed to notify admin: {e}")
    
    depositing_users.discard(user_id)
    context.user_data.clear()
    
    return ConversationHandler.END

async def cancel_deposit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancel deposit process"""
    query = update.callback_query
    user_id = query.from_user.id
    
    depositing_users.discard(user_id)
    context.user_data.clear()
    
    return ConversationHandler.END
