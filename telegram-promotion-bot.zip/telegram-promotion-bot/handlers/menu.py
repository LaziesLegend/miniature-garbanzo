from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from config import ADMIN_ID

def get_main_menu(user_id: int) -> InlineKeyboardMarkup:
    """Generate main menu keyboard"""
    keyboard = [
        [
            InlineKeyboardButton("💰 Balance", callback_data="balance"),
            InlineKeyboardButton("🚀 Create Promotion", callback_data="create_campaign")
        ],
        [
            InlineKeyboardButton("📊 My Campaigns", callback_data="my_campaigns"),
            InlineKeyboardButton("💳 Deposit Tokens", callback_data="deposit")
        ],
        [
            InlineKeyboardButton("👥 Referral", callback_data="referral"),
            InlineKeyboardButton("📜 Transactions", callback_data="transactions")
        ]
    ]
    
    # Add admin panel button for admin
    if user_id == ADMIN_ID:
        keyboard.append([InlineKeyboardButton("⚙️ Admin Panel", callback_data="admin_panel")])
    
    return InlineKeyboardMarkup(keyboard)

def get_back_button() -> InlineKeyboardMarkup:
    """Generate back to menu button"""
    keyboard = [[InlineKeyboardButton("🔙 Back to Menu", callback_data="main_menu")]]
    return InlineKeyboardMarkup(keyboard)
