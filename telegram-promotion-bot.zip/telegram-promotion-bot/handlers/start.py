from telegram import Update
from telegram.ext import ContextTypes
from database import Database
from handlers.menu import get_main_menu
from config import REFERRAL_BONUS
import logging

logger = logging.getLogger(__name__)

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command with referral tracking"""
    user = update.effective_user
    db = Database()
    
    # Check for referral code
    referrer_id = None
    if context.args and len(context.args) > 0:
        try:
            referrer_id = int(context.args[0])
            # Prevent self-referral
            if referrer_id == user.id:
                referrer_id = None
        except ValueError:
            logger.warning(f"Invalid referral code: {context.args[0]}")
    
    # Check if user already exists
    existing_user = db.get_user(user.id)
    
    if not existing_user:
        # New user registration
        success = db.add_user(user.id, user.username, referrer_id)
        
        if success and referrer_id:
            # Process referral bonus
            referrer = db.get_user(referrer_id)
            if referrer:
                db.update_user_tokens(referrer_id, REFERRAL_BONUS)
                db.add_referral(referrer_id, user.id, REFERRAL_BONUS)
                db.add_transaction(
                    referrer_id, 
                    'bonus', 
                    REFERRAL_BONUS, 
                    f'Referral bonus for user {user.id}'
                )
                
                # Notify referrer
                try:
                    await context.bot.send_message(
                        chat_id=referrer_id,
                        text=f"🎉 New referral! You earned {REFERRAL_BONUS} tokens!"
                    )
                except Exception as e:
                    logger.error(f"Failed to notify referrer: {e}")
    
    # Welcome message
    welcome_text = f"""
👋 <b>Welcome to Promotion Bot!</b>

Hello {user.first_name}! 

This bot helps you promote your Telegram channels and groups.

💡 <b>How it works:</b>
• Deposit tokens to your wallet
• Create promotion campaigns
• Get real members to your channel
• Track your campaign progress

💰 <b>Pricing:</b>
• 115 tokens per member
• Minimum 5 members per campaign

🎁 <b>Referral Program:</b>
Earn {REFERRAL_BONUS} tokens for each friend you refer!

Choose an option below to get started:
"""
    
    await update.message.reply_text(
        welcome_text,
        reply_markup=get_main_menu(user.id),
        parse_mode='HTML'
    )
