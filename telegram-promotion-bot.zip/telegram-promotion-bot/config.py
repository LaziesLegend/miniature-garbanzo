import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Bot Configuration
BOT_TOKEN = os.getenv('BOT_TOKEN')
ADMIN_ID = int(os.getenv('ADMIN_ID', 0))

# Platform Economics
MEMBER_COST = 100  # Cost per member in tokens
MEMBER_PRICE = 115  # Price advertiser pays per member
PLATFORM_FEE = 15  # Platform fee per member (115 - 100)
MIN_CAMPAIGN_SIZE = 5  # Minimum members per campaign

# Referral System
REFERRAL_BONUS = 50  # Tokens given for successful referral

# Validation
if not BOT_TOKEN:
    raise ValueError("BOT_TOKEN not found in environment variables")
if not ADMIN_ID:
    raise ValueError("ADMIN_ID not found in environment variables")
