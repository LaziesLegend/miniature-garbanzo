
from telegram import Update,InlineKeyboardMarkup,InlineKeyboardButton
from telegram.ext import Application,CommandHandler,CallbackQueryHandler,ContextTypes
from dotenv import load_dotenv
import os
from database import DB

load_dotenv()
db=DB()

async def start(u:Update,c:ContextTypes.DEFAULT_TYPE):
 db.add(u.effective_user.id)
 kb=[[InlineKeyboardButton("💸 Earn",callback_data="earn")],
     [InlineKeyboardButton("👥 Refer",callback_data="ref")],
     [InlineKeyboardButton("💼 Wallet",callback_data="wallet")]]
 await u.message.reply_photo(open("assets/logo.png","rb"),
 caption="🔥 PR‑GRAM Advanced Bot
Earn • Refer • Withdraw",
 reply_markup=InlineKeyboardMarkup(kb))

async def cb(u:Update,c:ContextTypes.DEFAULT_TYPE):
 q=u.callback_query;await q.answer()
 if q.data=="earn":
  db.addc(q.from_user.id,10)
  await q.edit_message_caption("✅ Task Completed
+10 Coins")
 if q.data=="wallet":
  await q.edit_message_caption(f"💰 Balance: {db.coins(q.from_user.id)}")
 if q.data=="ref":
  await q.edit_message_caption(f"👥 Invite Link:\nhttps://t.me/{c.bot.username}?start={q.from_user.id}")

app=Application.builder().token(os.getenv("BOT_TOKEN")).build()
app.add_handler(CommandHandler("start",start))
app.add_handler(CallbackQueryHandler(cb))
app.run_polling()
