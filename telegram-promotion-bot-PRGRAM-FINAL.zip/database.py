
import sqlite3
class DB:
 def __init__(self):
  self.c=sqlite3.connect("db.sqlite")
  self.c.execute("CREATE TABLE IF NOT EXISTS users(id INT PRIMARY KEY, coins INT DEFAULT 0)")
 def add(self,uid):
  self.c.execute("INSERT OR IGNORE INTO users(id) VALUES(?)",(uid,));self.c.commit()
 def coins(self,uid):
  r=self.c.execute("SELECT coins FROM users WHERE id=?",(uid,)).fetchone();return r[0] if r else 0
 def addc(self,uid,n):
  self.c.execute("UPDATE users SET coins=coins+? WHERE id=?",(n,uid));self.c.commit()
