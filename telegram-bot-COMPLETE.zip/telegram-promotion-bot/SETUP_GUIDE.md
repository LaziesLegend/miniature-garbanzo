# 🚀 Complete Setup Guide

This guide will walk you through setting up your Telegram Promotion Bot with all features.

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [Bot Configuration](#bot-configuration)
3. [Crypto Wallet Setup](#crypto-wallet-setup)
4. [Bot Logo Setup](#bot-logo-setup)
5. [Testing Your Bot](#testing-your-bot)
6. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### What You Need:

✅ Telegram account  
✅ Python 3.10 or higher installed  
✅ Crypto wallets (for accepting deposits)  
✅ Bot logo image (optional)  

---

## Bot Configuration

### Step 1: Create Your Bot

1. Open Telegram and search for [@BotFather](https://t.me/BotFather)
2. Send `/newbot` command
3. Choose a name for your bot (e.g., "My Promotion Bot")
4. Choose a username (must end in 'bot', e.g., "mypromotion_bot")
5. **Copy the token** you receive - it looks like:
   ```
   1234567890:ABCdefGHIjklMNOpqrsTUVwxyz
   ```

### Step 2: Get Your User ID

1. Search for [@userinfobot](https://t.me/userinfobot) on Telegram
2. Send `/start` to the bot
3. **Copy your User ID** - it's a number like `123456789`

### Step 3: Configure .env File

Open the `.env` file and add your credentials:

```env
BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz
ADMIN_ID=123456789
```

**Replace the values with your actual token and ID!**

---

## Crypto Wallet Setup

### Why You Need Crypto Wallets

Your bot accepts deposits in multiple cryptocurrencies. You need wallet addresses to receive payments.

### Supported Cryptocurrencies:

1. **USDT (Tether)** - TRC20 & ERC20 networks
2. **Bitcoin (BTC)**
3. **Binance Coin (BNB)** - BEP20 network

### How to Get Wallet Addresses:

#### Option 1: Trust Wallet (Recommended for Beginners)

1. Download **Trust Wallet** app
2. Create new wallet and save recovery phrase
3. Get addresses:
   - Tap "Receive" on each coin
   - Copy the address

#### Option 2: Binance Exchange

1. Create account on [Binance.com](https://binance.com)
2. Go to "Wallet" → "Fiat and Spot"
3. For each coin:
   - Click "Deposit"
   - Select network (TRC20 for USDT, BEP20 for BNB)
   - Copy the deposit address

#### Option 3: Multiple Wallets

- **USDT TRC20**: TronLink wallet
- **USDT ERC20**: MetaMask wallet
- **BTC**: Electrum or any Bitcoin wallet
- **BNB**: Trust Wallet or MetaMask (BSC network)

### Update config.py

Open `config.py` and add your wallet addresses:

```python
# Crypto Wallet Addresses (UPDATE THESE!)
USDT_TRC20_ADDRESS = "TYourActualTronAddressHere"
USDT_ERC20_ADDRESS = "0xYourActualEthereumAddressHere"
BTC_ADDRESS = "bc1YourActualBitcoinAddressHere"
BNB_ADDRESS = "0xYourActualBSCAddressHere"
```

### Example (DO NOT USE THESE):

```python
USDT_TRC20_ADDRESS = "TMuA6YqfCeX8EhbfYEg5y7S4DqzSJireY9"
USDT_ERC20_ADDRESS = "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb"
BTC_ADDRESS = "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh"
BNB_ADDRESS = "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb"
```

⚠️ **Important:**
- NEVER share your wallet's private keys or seed phrases
- Only share public wallet addresses
- Test with small amounts first
- Keep backup of recovery phrases

---

## Bot Logo Setup

### Why Add a Logo?

A professional logo makes your bot look trustworthy and branded.

### Option A: Upload to Imgur (Easiest)

1. Go to [imgur.com](https://imgur.com)
2. Click "New post"
3. Upload your logo image
4. After upload, **right-click** the image
5. Select "Copy image address"
6. You'll get a URL like: `https://i.imgur.com/abc123.png`

### Option B: Upload to Telegraph

1. Go to [telegra.ph](https://telegra.ph)
2. Click anywhere to start editing
3. Click the image icon
4. Upload your logo
5. Right-click image → Copy image URL

### Option C: Use Telegram CDN

1. Send your logo to any Telegram bot or chat
2. Forward it to [@FileToLinkBot](https://t.me/FileToLinkBot)
3. Copy the direct link provided

### Update config.py

```python
# Bot Branding
BOT_NAME = "My Promotion Bot"  # Change to your bot name
BOT_LOGO_URL = "https://i.imgur.com/your-actual-logo.png"
```

### Logo Recommendations:

- **Size**: 512x512px or 1024x1024px
- **Format**: PNG with transparent background
- **File size**: Under 500KB
- **Design**: Simple, clear, professional

### No Logo?

If you don't have a logo, the bot will work fine without it:

```python
BOT_LOGO_URL = "https://i.imgur.com/your-logo.png"  # Leave as is
```

---

## Testing Your Bot

### Start the Bot

```bash
python main.py
```

You should see:
```
INFO - Database initialized
INFO - Bot started successfully!
INFO - Admin ID: 123456789
```

### Test Checklist:

#### ✅ Basic Functions

1. **Start Command**
   - Send `/start` to your bot
   - Check if welcome message appears
   - Verify logo displays (if configured)
   - Verify keyboard buttons appear

2. **Balance**
   - Click "💰 Balance" button
   - Should show 0 tokens initially

3. **Referral System**
   - Click "👥 Referral"
   - Copy your referral link
   - Open in incognito/private browser
   - Click the link
   - Verify new user is registered

#### ✅ Deposit System

1. Click "💳 Deposit Tokens"
2. Enter amount (e.g., 100)
3. Select each payment method:
   - UPI
   - USDT → TRC20
   - USDT → ERC20
   - Bitcoin
   - BNB
4. Verify wallet addresses are correct

#### ✅ Admin Panel

1. Click "⚙️ Admin Panel" (only visible to admin)
2. Check statistics
3. Test "Add Tokens":
   - Format: `your_user_id 100`
   - Verify tokens added
4. Check pending deposits

#### ✅ Campaign Creation

1. Click "🚀 Create Promotion"
2. Select member count
3. Enter channel link
4. Verify cost calculation
5. (Will fail if balance is 0 - this is correct)

---

## Troubleshooting

### Bot Won't Start

**Error: "BOT_TOKEN not found"**
- Solution: Check `.env` file has correct token
- Make sure no extra spaces

**Error: "ADMIN_ID not found"**
- Solution: Add your user ID to `.env`
- Must be a number, not username

### Logo Not Showing

- Check if URL is accessible in browser
- Make sure URL starts with `https://`
- Try uploading to different service
- Check bot logs for errors

### Crypto Addresses Not Working

- Verify addresses are correct format
- TRC20 starts with 'T'
- ERC20/BNB starts with '0x'
- BTC starts with 'bc1' or '1' or '3'
- Test by sending small amount to yourself

### Keyboard Buttons Not Appearing

- Send `/start` again
- Restart the bot
- Check if using correct Telegram client

### Permission Denied Error

```bash
pip install -r requirements.txt --user
```

---

## Advanced Configuration

### Change Token Prices

Edit `config.py`:

```python
MEMBER_COST = 100      # Cost per member
MEMBER_PRICE = 115     # User pays this
PLATFORM_FEE = 15      # Your profit
REFERRAL_BONUS = 50    # Referral reward
```

### Change Minimum Deposit

Edit `handlers/deposit.py`:

```python
if amount < 100:  # Change 100 to your minimum
```

### Add More Payment Methods

Add buttons in `handlers/deposit.py` → `deposit_amount_received` function

---

## Security Checklist

✅ Never share your `.env` file  
✅ Never commit `.env` to Git  
✅ Keep bot token secret  
✅ Use strong wallet passwords  
✅ Enable 2FA on crypto exchanges  
✅ Backup wallet recovery phrases  
✅ Test with small amounts first  
✅ Monitor admin panel regularly  

---

## Getting Help

If you encounter issues:

1. Check error logs in terminal
2. Verify all configuration values
3. Test each feature individually
4. Check README.md for common solutions

---

## Next Steps

1. ✅ Configure all settings
2. ✅ Test thoroughly
3. ✅ Add real crypto addresses
4. ✅ Upload professional logo
5. ✅ Deploy to cloud (Railway, Render, etc.)
6. 🚀 Start promoting your bot!

---

**Congratulations! Your bot is ready to use! 🎉**
