from telegram import Update
from telegram.ext import ContextTypes
from database import Database
from handlers.menu import get_back_button
from config import REFERRAL_BONUS
import logging

logger = logging.getLogger(__name__)

async def referral_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show referral information"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    db = Database()
    
    # Generate referral link
    bot_username = context.bot.username
    referral_link = f"https://t.me/{bot_username}?start={user_id}"
    
    # Get referral stats
    referral_count = db.get_referral_count(user_id)
    total_earned = referral_count * REFERRAL_BONUS
    
    text = f"""
👥 <b>Referral Program</b>

Invite friends and earn {REFERRAL_BONUS} tokens for each referral!

<b>Your Stats:</b>
• Total Referrals: {referral_count}
• Tokens Earned: {total_earned}

<b>Your Referral Link:</b>
<code>{referral_link}</code>

<i>Tap to copy the link and share with friends!</i>

💡 <b>How it works:</b>
1. Share your referral link
2. Friend joins using your link
3. You get {REFERRAL_BONUS} tokens instantly!
"""
    
    await query.edit_message_text(
        text,
        reply_markup=get_back_button(),
        parse_mode='HTML'
    )
