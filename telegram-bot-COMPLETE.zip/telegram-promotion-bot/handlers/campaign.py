from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from database import Database
from handlers.menu import get_back_button, get_main_menu
from config import (MEMBER_PRICE, PLATFORM_FEE, MIN_CAMPAIGN_SIZE, 
                   CUSTOM_CAMPAIGN_TAX, CUSTOM_CAMPAIGN_MIN_BID, SUPPORT_CONTACT)
import logging

logger = logging.getLogger(__name__)

# Conversation states
(CAMPAIGN_TYPE, CAMPAIGN_MEMBERS, CAMPAIGN_CHANNEL, CAMPAIGN_REWARD, 
 CAMPAIGN_BOOST, CUSTOM_INSTRUCTIONS, CUSTOM_BET) = range(7)

# Anti-double-click protection
creating_campaign = set()

async def create_campaign_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start campaign creation"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    
    if user_id in creating_campaign:
        await query.answer("⚠️ Campaign in progress...", show_alert=True)
        return CAMPAIGN_TYPE
    
    creating_campaign.add(user_id)
    
    keyboard = [
        [InlineKeyboardButton("📢 Channel Join", callback_data="camp_type_channel")],
        [InlineKeyboardButton("🤖 Bot Start", callback_data="camp_type_bot")],
        [InlineKeyboardButton("✏️ Custom Task", callback_data="camp_type_custom")],
        [InlineKeyboardButton("🔙 Cancel", callback_data="main_menu")]
    ]
    
    text = f"""
🚀 <b>Create Campaign</b>

📢 <b>Channel Join</b> - Users join your channel
🤖 <b>Bot Start</b> - Users start your bot  
✏️ <b>Custom Task</b> - Custom instructions

💡 Help: {SUPPORT_CONTACT}
"""
    
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='HTML')
    return CAMPAIGN_TYPE

async def campaign_type_selected(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle type selection"""
    query = update.callback_query
    await query.answer()
    
    camp_type = query.data.split('_')[-1]
    context.user_data['campaign_type'] = camp_type
    
    if camp_type == 'custom':
        text = f"""
✏️ <b>Custom Task</b>

Set reward per completion:
Min: {CUSTOM_CAMPAIGN_MIN_BID} tokens
Fee: {CUSTOM_CAMPAIGN_TAX}%

Enter amount:
"""
        await query.edit_message_text(text, parse_mode='HTML')
        return CUSTOM_BET
    else:
        keyboard = []
        options = [5, 10, 25, 50, 100, 250, 500]
        
        row = []
        for i, m in enumerate(options):
            cost = m * MEMBER_PRICE
            row.append(InlineKeyboardButton(f"{m} ({cost})", callback_data=f"camp_mem_{m}"))
            if (i + 1) % 2 == 0:
                keyboard.append(row)
                row = []
        
        if row:
            keyboard.append(row)
        
        keyboard.append([InlineKeyboardButton("🔙 Cancel", callback_data="main_menu")])
        
        text = f"Select members:\n\n{MEMBER_PRICE} tokens/member"
        await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='HTML')
        return CAMPAIGN_MEMBERS

async def custom_bet_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle custom bet"""
    try:
        amount = int(update.message.text.strip())
        
        if amount < CUSTOM_CAMPAIGN_MIN_BID:
            await update.message.reply_text(f"❌ Min {CUSTOM_CAMPAIGN_MIN_BID}. Try again:")
            return CUSTOM_BET
        
        context.user_data['custom_reward'] = amount
        
        keyboard = []
        for tasks in [5, 10, 20, 50]:
            total = tasks * amount + int(tasks * amount * CUSTOM_CAMPAIGN_TAX / 100)
            keyboard.append([InlineKeyboardButton(f"{tasks} ({total})", callback_data=f"camp_mem_{tasks}")])
        
        keyboard.append([InlineKeyboardButton("🔙 Cancel", callback_data="main_menu")])
        
        await update.message.reply_text(
            f"Reward: {amount}\nSelect tasks:",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return CAMPAIGN_MEMBERS
    except:
        await update.message.reply_text("❌ Enter number:")
        return CUSTOM_BET

async def campaign_members_selected(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle member selection"""
    query = update.callback_query
    await query.answer()
    
    members = int(query.data.split('_')[-1])
    context.user_data['campaign_members'] = members
    
    camp_type = context.user_data.get('campaign_type', 'channel')
    
    if camp_type == 'custom':
        custom_reward = context.user_data.get('custom_reward', 500)
        fee_per_task = int(custom_reward * CUSTOM_CAMPAIGN_TAX / 100)
        total_cost = members * (custom_reward + fee_per_task)
        
        context.user_data['campaign_cost'] = total_cost
        context.user_data['campaign_fee'] = members * fee_per_task
        context.user_data['reward_per_user'] = custom_reward
        
        text = f"Tasks: {members}\nReward: {custom_reward}\n\nEnter instructions:"
        await query.edit_message_text(text, parse_mode='HTML')
        return CUSTOM_INSTRUCTIONS
    else:
        total_cost = members * MEMBER_PRICE
        context.user_data['campaign_cost'] = total_cost
        context.user_data['campaign_fee'] = members * PLATFORM_FEE
        context.user_data['reward_per_user'] = 100
        
        text = f"Send your {'channel' if camp_type == 'channel' else 'bot'} link:"
        await query.edit_message_text(text, parse_mode='HTML')
        return CAMPAIGN_CHANNEL

async def custom_instructions_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle instructions"""
    context.user_data['custom_instructions'] = update.message.text.strip()
    return await ask_boost(update, context)

async def campaign_channel_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle channel link"""
    context.user_data['channel_link'] = update.message.text.strip()
    return await ask_boost(update, context)

async def ask_boost(update, context):
    """Ask about boost"""
    keyboard = [
        [InlineKeyboardButton("✅ Boost", callback_data="boost_yes")],
        [InlineKeyboardButton("⏭ Skip", callback_data="boost_no")]
    ]
    
    msg = update.message if hasattr(update, 'message') else update.callback_query.message
    await msg.reply_text("🚀 Boost campaign?\n\nHigher boost = Top position", 
                        reply_markup=InlineKeyboardMarkup(keyboard))
    return CAMPAIGN_BOOST

async def boost_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle boost choice"""
    query = update.callback_query
    await query.answer()
    
    if query.data == 'boost_yes':
        await query.edit_message_text("Enter boost amount:")
        return CAMPAIGN_REWARD
    else:
        context.user_data['boost_amount'] = 0
        return await finalize_campaign(update, context)

async def boost_amount_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle boost amount"""
    try:
        boost = int(update.message.text.strip())
        if boost < 0:
            await update.message.reply_text("❌ Must be ≥ 0:")
            return CAMPAIGN_REWARD
        
        context.user_data['boost_amount'] = boost
        return await finalize_campaign(update, context)
    except:
        await update.message.reply_text("❌ Enter number:")
        return CAMPAIGN_REWARD

async def finalize_campaign(update, context):
    """Create campaign"""
    user_id = update.effective_user.id if hasattr(update, 'effective_user') else update.callback_query.from_user.id
    db = Database()
    
    camp_type = context.user_data.get('campaign_type', 'channel')
    members = context.user_data.get('campaign_members')
    total_cost = context.user_data.get('campaign_cost')
    platform_fee = context.user_data.get('campaign_fee')
    channel_link = context.user_data.get('channel_link', 'custom')
    reward = context.user_data.get('reward_per_user', 100)
    boost = context.user_data.get('boost_amount', 0)
    instructions = context.user_data.get('custom_instructions')
    
    total = total_cost + boost
    balance = db.get_user_balance(user_id)
    
    if balance < total:
        msg = update.message if hasattr(update, 'message') else update.callback_query.message
        await msg.reply_text(f"❌ Need {total}, have {balance}", reply_markup=get_back_button())
        creating_campaign.discard(user_id)
        return ConversationHandler.END
    
    db.update_user_tokens(user_id, -total)
    campaign_id = db.create_campaign(user_id, camp_type, channel_link, members, 
                                     total_cost, platform_fee, reward, boost, instructions)
    db.add_transaction(user_id, 'campaign', total, f'Campaign #{campaign_id}')
    
    text = f"""
✅ <b>Campaign #{campaign_id} Created!</b>

Type: {camp_type.capitalize()}
Target: {members}
Reward: {reward} tokens/user
Cost: {total_cost}
Boost: {boost}
<b>Total: {total} tokens</b>

Balance: {balance - total}
"""
    
    msg = update.message if hasattr(update, 'message') else update.callback_query.message
    await msg.reply_text(text, reply_markup=get_main_menu(user_id), parse_mode='HTML')
    
    creating_campaign.discard(user_id)
    context.user_data.clear()
    return ConversationHandler.END

async def my_campaigns_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show campaigns"""
    query = update.callback_query
    await query.answer()
    
    db = Database()
    campaigns = db.get_user_campaigns(query.from_user.id)
    
    if not campaigns:
        text = "📊 No campaigns yet"
    else:
        text = "📊 <b>My Campaigns</b>\n\n"
        for c in campaigns[:10]:
            status = {'active': '🟢', 'completed': '✅'}.get(c['status'], '⚪')
            text += f"{status} #{c['id']} | {c['delivered_members']}/{c['target_members']}\n"
    
    await query.edit_message_text(text, reply_markup=get_back_button(), parse_mode='HTML')

async def cancel_campaign(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancel"""
    query = update.callback_query
    creating_campaign.discard(query.from_user.id)
    context.user_data.clear()
    return ConversationHandler.END
