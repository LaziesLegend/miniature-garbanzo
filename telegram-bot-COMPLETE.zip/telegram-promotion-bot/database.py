import sqlite3
import logging
from datetime import datetime
from typing import Optional, List, Dict, Any

logger = logging.getLogger(__name__)

class Database:
    def __init__(self, db_name: str = "bot_database.db"):
        self.db_name = db_name
        self.init_database()
    
    def get_connection(self):
        """Get database connection"""
        return sqlite3.connect(self.db_name)
    
    def init_database(self):
        """Initialize all database tables"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Users table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                tokens INTEGER DEFAULT 0,
                referred_by INTEGER,
                join_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Campaigns table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS campaigns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                campaign_type TEXT DEFAULT 'channel',
                channel_link TEXT,
                target_members INTEGER,
                delivered_members INTEGER DEFAULT 0,
                total_cost INTEGER,
                platform_fee INTEGER,
                reward_per_user INTEGER DEFAULT 100,
                boost_amount INTEGER DEFAULT 0,
                status TEXT DEFAULT 'pending',
                custom_instructions TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        # Custom campaign submissions
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS custom_submissions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                campaign_id INTEGER,
                user_id INTEGER,
                screenshot_file_id TEXT,
                status TEXT DEFAULT 'pending',
                submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (campaign_id) REFERENCES campaigns(id),
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        # Transactions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                type TEXT,
                amount INTEGER,
                description TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        # Deposits table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS deposits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                method TEXT,
                amount INTEGER,
                status TEXT DEFAULT 'pending',
                tx_hash TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        # Referrals table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS referrals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                referrer_id INTEGER,
                referred_user_id INTEGER,
                bonus_given INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (referrer_id) REFERENCES users(user_id),
                FOREIGN KEY (referred_user_id) REFERENCES users(user_id)
            )
        ''')
        
        # User tasks (for earning by joining channels)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                campaign_id INTEGER,
                channel_link TEXT,
                joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                verified BOOLEAN DEFAULT 0,
                reward_given BOOLEAN DEFAULT 0,
                left_early BOOLEAN DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES users(user_id),
                FOREIGN KEY (campaign_id) REFERENCES campaigns(id)
            )
        ''')
        
        # Daily bonuses tracking
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS daily_bonuses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                claimed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                amount INTEGER,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        # Gamble history
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS gamble_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                bet_amount INTEGER,
                won BOOLEAN,
                winnings INTEGER,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        # Suspended users
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS suspended_users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                reason TEXT,
                suspended_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        conn.commit()
        conn.close()
        logger.info("Database initialized successfully")
    
    # ==================== USER OPERATIONS ====================
    
    def add_user(self, user_id: int, username: str = None, referred_by: int = None) -> bool:
        """Add new user to database"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute(
                'INSERT OR IGNORE INTO users (user_id, username, referred_by) VALUES (?, ?, ?)',
                (user_id, username, referred_by)
            )
            conn.commit()
            success = cursor.rowcount > 0
            conn.close()
            return success
        except Exception as e:
            logger.error(f"Error adding user: {e}")
            return False
    
    def get_user(self, user_id: int) -> Optional[Dict[str, Any]]:
        """Get user information"""
        try:
            conn = self.get_connection()
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
            row = cursor.fetchone()
            conn.close()
            return dict(row) if row else None
        except Exception as e:
            logger.error(f"Error getting user: {e}")
            return None
    
    def update_user_tokens(self, user_id: int, amount: int) -> bool:
        """Update user token balance"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute(
                'UPDATE users SET tokens = tokens + ? WHERE user_id = ?',
                (amount, user_id)
            )
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error updating tokens: {e}")
            return False
    
    def get_user_balance(self, user_id: int) -> int:
        """Get user token balance"""
        user = self.get_user(user_id)
        return user['tokens'] if user else 0
    
    # ==================== CAMPAIGN OPERATIONS ====================
    
    def create_campaign(self, user_id: int, campaign_type: str, channel_link: str, 
                       target_members: int, total_cost: int, platform_fee: int,
                       reward_per_user: int = 100, boost_amount: int = 0,
                       custom_instructions: str = None) -> Optional[int]:
        """Create new campaign"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO campaigns (user_id, campaign_type, channel_link, target_members, 
                                     total_cost, platform_fee, reward_per_user, boost_amount, 
                                     custom_instructions, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
            ''', (user_id, campaign_type, channel_link, target_members, total_cost, 
                  platform_fee, reward_per_user, boost_amount, custom_instructions))
            campaign_id = cursor.lastrowid
            conn.commit()
            conn.close()
            return campaign_id
        except Exception as e:
            logger.error(f"Error creating campaign: {e}")
            return None
    
    def get_user_campaigns(self, user_id: int) -> List[Dict[str, Any]]:
        """Get all campaigns for a user"""
        try:
            conn = self.get_connection()
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute(
                'SELECT * FROM campaigns WHERE user_id = ? ORDER BY created_at DESC',
                (user_id,)
            )
            rows = cursor.fetchall()
            conn.close()
            return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Error getting campaigns: {e}")
            return []
    
    def get_campaign(self, campaign_id: int) -> Optional[Dict[str, Any]]:
        """Get campaign by ID"""
        try:
            conn = self.get_connection()
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM campaigns WHERE id = ?', (campaign_id,))
            row = cursor.fetchone()
            conn.close()
            return dict(row) if row else None
        except Exception as e:
            logger.error(f"Error getting campaign: {e}")
            return None
    
    def update_campaign_status(self, campaign_id: int, status: str) -> bool:
        """Update campaign status"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute(
                'UPDATE campaigns SET status = ? WHERE id = ?',
                (status, campaign_id)
            )
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error updating campaign: {e}")
            return False
    
    # ==================== TRANSACTION OPERATIONS ====================
    
    def add_transaction(self, user_id: int, trans_type: str, amount: int, description: str) -> bool:
        """Add transaction record"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO transactions (user_id, type, amount, description)
                VALUES (?, ?, ?, ?)
            ''', (user_id, trans_type, amount, description))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error adding transaction: {e}")
            return False
    
    def get_user_transactions(self, user_id: int, limit: int = 10) -> List[Dict[str, Any]]:
        """Get user transaction history"""
        try:
            conn = self.get_connection()
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM transactions WHERE user_id = ? 
                ORDER BY timestamp DESC LIMIT ?
            ''', (user_id, limit))
            rows = cursor.fetchall()
            conn.close()
            return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Error getting transactions: {e}")
            return []
    
    # ==================== DEPOSIT OPERATIONS ====================
    
    def create_deposit(self, user_id: int, method: str, amount: int, tx_hash: str = None) -> Optional[int]:
        """Create deposit request"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO deposits (user_id, method, amount, tx_hash, status)
                VALUES (?, ?, ?, ?, 'pending')
            ''', (user_id, method, amount, tx_hash))
            deposit_id = cursor.lastrowid
            conn.commit()
            conn.close()
            return deposit_id
        except Exception as e:
            logger.error(f"Error creating deposit: {e}")
            return None
    
    def get_pending_deposits(self) -> List[Dict[str, Any]]:
        """Get all pending deposits"""
        try:
            conn = self.get_connection()
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute(
                'SELECT * FROM deposits WHERE status = "pending" ORDER BY created_at DESC'
            )
            rows = cursor.fetchall()
            conn.close()
            return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Error getting pending deposits: {e}")
            return []
    
    def update_deposit_status(self, deposit_id: int, status: str) -> bool:
        """Update deposit status"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute(
                'UPDATE deposits SET status = ? WHERE id = ?',
                (status, deposit_id)
            )
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error updating deposit: {e}")
            return False
    
    def get_deposit(self, deposit_id: int) -> Optional[Dict[str, Any]]:
        """Get deposit by ID"""
        try:
            conn = self.get_connection()
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM deposits WHERE id = ?', (deposit_id,))
            row = cursor.fetchone()
            conn.close()
            return dict(row) if row else None
        except Exception as e:
            logger.error(f"Error getting deposit: {e}")
            return None
    
    # ==================== REFERRAL OPERATIONS ====================
    
    def add_referral(self, referrer_id: int, referred_user_id: int, bonus: int) -> bool:
        """Record referral"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO referrals (referrer_id, referred_user_id, bonus_given)
                VALUES (?, ?, ?)
            ''', (referrer_id, referred_user_id, bonus))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error adding referral: {e}")
            return False
    
    def get_referral_count(self, user_id: int) -> int:
        """Get number of referrals"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute(
                'SELECT COUNT(*) FROM referrals WHERE referrer_id = ?',
                (user_id,)
            )
            count = cursor.fetchone()[0]
            conn.close()
            return count
        except Exception as e:
            logger.error(f"Error getting referral count: {e}")
            return 0
    
    # ==================== EARNING SYSTEM ====================
    
    def add_user_task(self, user_id: int, campaign_id: int, channel_link: str) -> Optional[int]:
        """Record user joining a task"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO user_tasks (user_id, campaign_id, channel_link)
                VALUES (?, ?, ?)
            ''', (user_id, campaign_id, channel_link))
            task_id = cursor.lastrowid
            conn.commit()
            conn.close()
            return task_id
        except Exception as e:
            logger.error(f"Error adding user task: {e}")
            return None
    
    def verify_user_task(self, task_id: int) -> bool:
        """Mark task as verified"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute(
                'UPDATE user_tasks SET verified = 1 WHERE id = ?',
                (task_id,)
            )
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error verifying task: {e}")
            return False
    
    def mark_task_rewarded(self, task_id: int) -> bool:
        """Mark reward as given"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute(
                'UPDATE user_tasks SET reward_given = 1 WHERE id = ?',
                (task_id,)
            )
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error marking reward: {e}")
            return False
    
    def get_user_active_tasks(self, user_id: int) -> List[Dict[str, Any]]:
        """Get user's active tasks (need to stay for 3 days)"""
        try:
            conn = self.get_connection()
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM user_tasks 
                WHERE user_id = ? AND verified = 1 AND left_early = 0
                ORDER BY joined_at DESC
            ''', (user_id,))
            rows = cursor.fetchall()
            conn.close()
            return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Error getting active tasks: {e}")
            return []
    
    def get_available_earning_campaigns(self, exclude_user_id: int = None) -> List[Dict[str, Any]]:
        """Get active campaigns that users can join to earn (sorted by boost amount)"""
        try:
            conn = self.get_connection()
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            if exclude_user_id:
                cursor.execute('''
                    SELECT * FROM campaigns 
                    WHERE status = 'active' 
                    AND delivered_members < target_members
                    AND user_id != ?
                    ORDER BY boost_amount DESC, created_at DESC
                ''', (exclude_user_id,))
            else:
                cursor.execute('''
                    SELECT * FROM campaigns 
                    WHERE status = 'active' AND delivered_members < target_members
                    ORDER BY boost_amount DESC, created_at DESC
                ''')
            
            rows = cursor.fetchall()
            conn.close()
            return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Error getting earning campaigns: {e}")
            return []
    
    def check_user_already_joined(self, user_id: int, campaign_id: int) -> bool:
        """Check if user already joined this campaign"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                SELECT COUNT(*) FROM user_tasks 
                WHERE user_id = ? AND campaign_id = ?
            ''', (user_id, campaign_id))
            count = cursor.fetchone()[0]
            conn.close()
            return count > 0
        except Exception as e:
            logger.error(f"Error checking join status: {e}")
            return False
    
    def increment_campaign_members(self, campaign_id: int) -> bool:
        """Increment delivered members count"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE campaigns 
                SET delivered_members = delivered_members + 1 
                WHERE id = ?
            ''', (campaign_id,))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error incrementing members: {e}")
            return False
    
    def mark_task_left_early(self, task_id: int) -> bool:
        """Mark that user left channel early"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute(
                'UPDATE user_tasks SET left_early = 1 WHERE id = ?',
                (task_id,)
            )
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error marking left early: {e}")
            return False
    
    # ==================== DAILY BONUS ====================
    
    def check_daily_bonus_claimed(self, user_id: int) -> bool:
        """Check if user claimed daily bonus today"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                SELECT COUNT(*) FROM daily_bonuses 
                WHERE user_id = ? AND DATE(claimed_at) = DATE('now')
            ''', (user_id,))
            count = cursor.fetchone()[0]
            conn.close()
            return count > 0
        except Exception as e:
            logger.error(f"Error checking daily bonus: {e}")
            return False
    
    def claim_daily_bonus(self, user_id: int, amount: int) -> bool:
        """Record daily bonus claim"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO daily_bonuses (user_id, amount)
                VALUES (?, ?)
            ''', (user_id, amount))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error claiming daily bonus: {e}")
            return False
    
    # ==================== GAMBLE SYSTEM ====================
    
    def add_gamble_record(self, user_id: int, bet_amount: int, won: bool, winnings: int) -> bool:
        """Record gamble attempt"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO gamble_history (user_id, bet_amount, won, winnings)
                VALUES (?, ?, ?, ?)
            ''', (user_id, bet_amount, won, winnings))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error adding gamble record: {e}")
            return False
    
    def get_user_gamble_history(self, user_id: int, limit: int = 10) -> List[Dict[str, Any]]:
        """Get user's gamble history"""
        try:
            conn = self.get_connection()
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM gamble_history 
                WHERE user_id = ? 
                ORDER BY timestamp DESC LIMIT ?
            ''', (user_id, limit))
            rows = cursor.fetchall()
            conn.close()
            return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Error getting gamble history: {e}")
            return []
    
    # ==================== SUSPENSION SYSTEM ====================
    
    def suspend_user(self, user_id: int, reason: str) -> bool:
        """Suspend user account"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO suspended_users (user_id, reason)
                VALUES (?, ?)
            ''', (user_id, reason))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error suspending user: {e}")
            return False
    
    def is_user_suspended(self, user_id: int) -> bool:
        """Check if user is suspended"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute(
                'SELECT COUNT(*) FROM suspended_users WHERE user_id = ?',
                (user_id,)
            )
            count = cursor.fetchone()[0]
            conn.close()
            return count > 0
        except Exception as e:
            logger.error(f"Error checking suspension: {e}")
            return False
    
    # ==================== CUSTOM CAMPAIGNS ====================
    
    def add_custom_submission(self, campaign_id: int, user_id: int, screenshot_file_id: str) -> Optional[int]:
        """Add custom campaign submission"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO custom_submissions (campaign_id, user_id, screenshot_file_id)
                VALUES (?, ?, ?)
            ''', (campaign_id, user_id, screenshot_file_id))
            submission_id = cursor.lastrowid
            conn.commit()
            conn.close()
            return submission_id
        except Exception as e:
            logger.error(f"Error adding custom submission: {e}")
            return None
    
    def get_pending_submissions(self, campaign_id: int) -> List[Dict[str, Any]]:
        """Get pending submissions for a campaign"""
        try:
            conn = self.get_connection()
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM custom_submissions 
                WHERE campaign_id = ? AND status = 'pending'
                ORDER BY submitted_at ASC
            ''', (campaign_id,))
            rows = cursor.fetchall()
            conn.close()
            return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Error getting submissions: {e}")
            return []
    
    def approve_submission(self, submission_id: int) -> bool:
        """Approve custom submission"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute(
                'UPDATE custom_submissions SET status = ? WHERE id = ?',
                ('approved', submission_id)
            )
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error approving submission: {e}")
            return False
    
    def get_submission(self, submission_id: int) -> Optional[Dict[str, Any]]:
        """Get submission by ID"""
        try:
            conn = self.get_connection()
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM custom_submissions WHERE id = ?', (submission_id,))
            row = cursor.fetchone()
            conn.close()
            return dict(row) if row else None
        except Exception as e:
            logger.error(f"Error getting submission: {e}")
            return None
    
    # ==================== ADMIN OPERATIONS ====================
    
    def get_total_users(self) -> int:
        """Get total user count"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT COUNT(*) FROM users')
            count = cursor.fetchone()[0]
            conn.close()
            return count
        except Exception as e:
            logger.error(f"Error getting user count: {e}")
            return 0
    
    def get_total_campaigns(self) -> int:
        """Get total campaign count"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT COUNT(*) FROM campaigns')
            count = cursor.fetchone()[0]
            conn.close()
            return count
        except Exception as e:
            logger.error(f"Error getting campaign count: {e}")
            return 0
    
    def get_total_revenue(self) -> int:
        """Get total platform revenue from fees"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT SUM(platform_fee) FROM campaigns WHERE status != "cancelled"')
            total = cursor.fetchone()[0]
            conn.close()
            return total if total else 0
        except Exception as e:
            logger.error(f"Error getting revenue: {e}")
            return 0
    
    def delete_user(self, user_id: int) -> bool:
        """Delete user and related data"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('DELETE FROM users WHERE user_id = ?', (user_id,))
            cursor.execute('DELETE FROM campaigns WHERE user_id = ?', (user_id,))
            cursor.execute('DELETE FROM transactions WHERE user_id = ?', (user_id,))
            cursor.execute('DELETE FROM deposits WHERE user_id = ?', (user_id,))
            cursor.execute('DELETE FROM referrals WHERE referrer_id = ? OR referred_user_id = ?', 
                          (user_id, user_id))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error deleting user: {e}")
            return False
    
    def reset_database(self) -> bool:
        """Reset entire database (DANGEROUS)"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('DELETE FROM users')
            cursor.execute('DELETE FROM campaigns')
            cursor.execute('DELETE FROM transactions')
            cursor.execute('DELETE FROM deposits')
            cursor.execute('DELETE FROM referrals')
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error resetting database: {e}")
            return False
