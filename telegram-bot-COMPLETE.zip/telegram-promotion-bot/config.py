import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Bot Configuration
BOT_TOKEN = os.getenv('BOT_TOKEN')
ADMIN_ID = int(os.getenv('ADMIN_ID', 0))

# Platform Economics
MEMBER_COST = 100  # Cost per member in tokens
MEMBER_PRICE = 115  # Price advertiser pays per member
PLATFORM_FEE = 15  # Platform fee per member (115 - 100)
MIN_CAMPAIGN_SIZE = 5  # Minimum members per campaign

# Referral System
REFERRAL_BONUS = 50  # Tokens given for successful referral

# Earning System
JOIN_REWARD = 100  # Tokens for joining a channel/group
DAILY_BONUS = 100  # Daily login bonus
MINIMUM_STAY_DAYS = 3  # Minimum days user must stay in channel
PENALTY_PERCENTAGE = 90  # Percentage of balance deducted for leaving early

# Gambling Game
GAMBLE_WIN_MULTIPLIER = 3  # User gets 3x their bet if they win
GAMBLE_WIN_CHANCE = 10  # 10% chance of winning (user doesn't know)

# Crypto Wallet Addresses (UPDATE THESE WITH YOUR ACTUAL ADDRESSES)
USDT_TRC20_ADDRESS = "TYourUSDTAddressHere123456789"
USDT_ERC20_ADDRESS = "0xYourUSDTERC20AddressHere"
BTC_ADDRESS = "bc1YourBitcoinAddressHere"
BNB_ADDRESS = "0xYourBNBAddressHere"

# Bot Branding
BOT_NAME = "Promotion Bot"
BOT_LOGO_URL = "https://i.imgur.com/your-logo.png"  # Upload your logo to imgur or use Telegraph
SUPPORT_CONTACT = "@holabrooo"  # Support contact

# Custom Campaign
CUSTOM_CAMPAIGN_TAX = 15  # 15% tax on custom campaigns
CUSTOM_CAMPAIGN_MIN_BID = 500  # Minimum bid for custom campaign

# Validation
if not BOT_TOKEN:
    raise ValueError("BOT_TOKEN not found in environment variables")
if not ADMIN_ID:
    raise ValueError("ADMIN_ID not found in environment variables")
