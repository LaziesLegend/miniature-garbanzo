#!/bin/bash

# Telegram Premium Exchange Bot PRO - Quick Start Script
# Version 4.0.0

clear
echo "╔════════════════════════════════════════════════╗"
echo "║   🤖 TELEGRAM PREMIUM EXCHANGE BOT PRO        ║"
echo "║   Version: 4.0.0 ULTRA                         ║"
echo "║   Quick Setup & Launch Script                  ║"
echo "╚════════════════════════════════════════════════╝"
echo ""

# Check Python version
echo "📋 Checking Python installation..."
if command -v python3 &>/dev/null; then
    PYTHON_CMD=python3
elif command -v python &>/dev/null; then
    PYTHON_CMD=python
else
    echo "❌ Python not found! Please install Python 3.8 or higher."
    exit 1
fi

PYTHON_VERSION=$($PYTHON_CMD --version 2>&1 | awk '{print $2}')
echo "✅ Found Python $PYTHON_VERSION"
echo ""

# Install dependencies
echo "📦 Installing dependencies..."
$PYTHON_CMD -m pip install -q --upgrade pip 2>/dev/null
$PYTHON_CMD -m pip install -q -r requirements.txt 2>/dev/null

if [ $? -eq 0 ]; then
    echo "✅ Dependencies installed successfully"
else
    echo "⚠️  Installing dependencies without pip cache..."
    $PYTHON_CMD -m pip install --no-cache-dir python-telegram-bot==21.0 pillow==10.4.0
fi

echo ""
echo "╔════════════════════════════════════════════════╗"
echo "║   🎨 Bot Configuration                         ║"
echo "╚════════════════════════════════════════════════╝"
echo "Bot Token: 8438773973:AAHzZUXMjUw6whaZI9pG7wr3IWGj30xiFww"
echo "Admin ID: 8301300209"
echo "Database: bot_premium_pro.db"
echo ""

# Check if logo exists, if not generate it
if [ ! -f "bot_logo.png" ]; then
    echo "🎨 Generating bot logo..."
    $PYTHON_CMD generate_logo.py
    echo ""
fi

echo "╔════════════════════════════════════════════════╗"
echo "║   ✨ FEATURES ENABLED                         ║"
echo "╚════════════════════════════════════════════════╝"
echo "✅ Multi-Level Referral System (3 levels)"
echo "✅ Advanced Campaign System (4 types)"
echo "✅ Achievement System (20+ achievements)"
echo "✅ Daily Rewards & Streak Bonuses"
echo "✅ Token Shop with Power-ups"
echo "✅ Leaderboard System"
echo "✅ Trust Score & Anti-Cheat"
echo "✅ Happy Hours & Weekend Bonuses"
echo "✅ VIP Membership System"
echo "✅ Professional UI with Logo"
echo ""

echo "╔════════════════════════════════════════════════╗"
echo "║   🚀 LAUNCHING BOT...                         ║"
echo "╚════════════════════════════════════════════════╝"
echo ""
echo "Bot is starting..."
echo "Press Ctrl+C to stop the bot"
echo ""
echo "════════════════════════════════════════════════"
echo ""

# Run the bot
$PYTHON_CMD main.py
