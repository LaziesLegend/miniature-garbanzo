#!/bin/bash

echo "🤖 Telegram Premium Exchange Bot PRO v4.0.0 ULTRA"
echo "=================================================="
echo ""

# Install dependencies
echo "📦 Installing dependencies..."
pip install -q python-telegram-bot==21.0 pillow==10.4.0 2>/dev/null || pip install python-telegram-bot==21.0 pillow==10.4.0

echo "✅ Dependencies ready!"
echo ""
echo "🚀 Starting bot..."
echo ""

# Run bot
python3 main.py
