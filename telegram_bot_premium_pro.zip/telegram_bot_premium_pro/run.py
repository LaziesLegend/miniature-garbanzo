#!/usr/bin/env python3
"""
🤖 TELEGRAM PREMIUM EXCHANGE BOT PRO - LAUNCHER
Version 4.0.0 ULTRA
"""

import sys
import subprocess

def ensure_dependencies():
    """Ensure all dependencies are installed"""
    try:
        import telegram
    except ImportError:
        print("📦 Installing required packages...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "python-telegram-bot==21.0", "pillow==10.4.0"])
        print("✅ Dependencies installed!")

if __name__ == "__main__":
    ensure_dependencies()
    
    print("""
╔════════════════════════════════════════════════════════════╗
║   🤖 TELEGRAM PREMIUM EXCHANGE BOT PRO v4.0.0 ULTRA       ║
║                                                            ║
║   Starting bot...                                          ║
╚════════════════════════════════════════════════════════════╝
    """)
    
    try:
        from main import main
        main()
    except KeyboardInterrupt:
        print("\n\n👋 Bot stopped by user")
        sys.exit(0)
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)
