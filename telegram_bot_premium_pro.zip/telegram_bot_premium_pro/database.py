"""
🗄️ PREMIUM DATABASE LAYER - Complete Production Database
Advanced Schema with All Features
Version: 4.0.0
"""

import sqlite3
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
import json
import logging

logger = logging.getLogger(__name__)

class Database:
    def __init__(self, db_name: str = "bot_premium_pro.db"):
        self.db_name = db_name
        self.init_database()
        logger.info(f"✅ Database initialized: {db_name}")
    
    def get_connection(self):
        """Get database connection with row factory"""
        conn = sqlite3.connect(self.db_name)
        conn.row_factory = sqlite3.Row
        return conn
    
    def init_database(self):
        """Initialize all database tables"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # USERS TABLE
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                tokens INTEGER DEFAULT 0,
                level INTEGER DEFAULT 1,
                trust_score INTEGER DEFAULT 100,
                total_joins INTEGER DEFAULT 0,
                total_earned INTEGER DEFAULT 0,
                total_spent INTEGER DEFAULT 0,
                total_referrals INTEGER DEFAULT 0,
                referred_by INTEGER,
                join_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_daily_claim TIMESTAMP,
                daily_streak INTEGER DEFAULT 0,
                is_banned INTEGER DEFAULT 0,
                ban_reason TEXT,
                ban_until TIMESTAMP,
                is_vip INTEGER DEFAULT 0,
                vip_until TIMESTAMP,
                priority_boost_until TIMESTAMP,
                double_rewards_until TIMESTAMP,
                language TEXT DEFAULT 'en',
                notifications_enabled INTEGER DEFAULT 1
            )
        """)
        
        # CAMPAIGNS TABLE
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS campaigns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                channel_link TEXT NOT NULL,
                channel_username TEXT,
                channel_title TEXT,
                target_members INTEGER NOT NULL,
                delivered_members INTEGER DEFAULT 0,
                pending_members INTEGER DEFAULT 0,
                verified_members INTEGER DEFAULT 0,
                join_reward INTEGER NOT NULL,
                advertiser_rate INTEGER NOT NULL,
                platform_fee INTEGER NOT NULL,
                total_cost INTEGER NOT NULL,
                status TEXT DEFAULT 'active',
                campaign_type TEXT DEFAULT 'standard',
                priority INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                started_at TIMESTAMP,
                completed_at TIMESTAMP,
                cancelled_at TIMESTAMP,
                cancel_reason TEXT,
                auto_refill INTEGER DEFAULT 0,
                refill_threshold INTEGER DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        
        # CAMPAIGN JOINS TABLE
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS campaign_joins (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                campaign_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                verified INTEGER DEFAULT 0,
                verification_attempts INTEGER DEFAULT 0,
                reward_multiplier REAL DEFAULT 1.0,
                tokens_earned INTEGER DEFAULT 0,
                joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                verified_at TIMESTAMP,
                left_channel INTEGER DEFAULT 0,
                left_at TIMESTAMP,
                quality_score INTEGER DEFAULT 0,
                FOREIGN KEY (campaign_id) REFERENCES campaigns(id),
                FOREIGN KEY (user_id) REFERENCES users(user_id),
                UNIQUE(campaign_id, user_id)
            )
        """)
        
        # TRANSACTIONS TABLE
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                type TEXT NOT NULL,
                amount INTEGER NOT NULL,
                description TEXT,
                related_id INTEGER,
                related_type TEXT,
                balance_before INTEGER,
                balance_after INTEGER,
                metadata TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        
        # DEPOSITS TABLE
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS deposits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                method TEXT NOT NULL,
                amount INTEGER NOT NULL,
                bonus_amount INTEGER DEFAULT 0,
                total_credited INTEGER,
                tier TEXT,
                status TEXT DEFAULT 'pending',
                tx_hash TEXT,
                payment_proof_file_id TEXT,
                payment_details TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                processed_at TIMESTAMP,
                approved_by INTEGER,
                reject_reason TEXT,
                notes TEXT,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        
        # WITHDRAWALS TABLE
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS withdrawals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                method TEXT NOT NULL,
                amount INTEGER NOT NULL,
                fee_amount INTEGER NOT NULL,
                net_amount INTEGER NOT NULL,
                payment_details TEXT NOT NULL,
                status TEXT DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                processed_at TIMESTAMP,
                processed_by INTEGER,
                tx_reference TEXT,
                reject_reason TEXT,
                notes TEXT,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        
        # REFERRALS TABLE
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS referrals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                referrer_id INTEGER NOT NULL,
                referred_user_id INTEGER NOT NULL,
                level INTEGER DEFAULT 1,
                signup_bonus_given INTEGER DEFAULT 0,
                task_bonus_given INTEGER DEFAULT 0,
                total_bonus_earned INTEGER DEFAULT 0,
                first_task_completed INTEGER DEFAULT 0,
                is_active INTEGER DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (referrer_id) REFERENCES users(user_id),
                FOREIGN KEY (referred_user_id) REFERENCES users(user_id),
                UNIQUE(referrer_id, referred_user_id)
            )
        """)
        
        # ACHIEVEMENTS TABLE
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS achievements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                achievement_id TEXT NOT NULL,
                claimed INTEGER DEFAULT 0,
                claimed_at TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id),
                UNIQUE(user_id, achievement_id)
            )
        """)
        
        # DAILY TASKS TABLE
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS daily_tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                task_id TEXT NOT NULL,
                progress INTEGER DEFAULT 0,
                completed INTEGER DEFAULT 0,
                claimed INTEGER DEFAULT 0,
                date TEXT NOT NULL,
                completed_at TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id),
                UNIQUE(user_id, task_id, date)
            )
        """)
        
        # SHOP PURCHASES TABLE
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS shop_purchases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                item_id TEXT NOT NULL,
                cost INTEGER NOT NULL,
                purchased_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP,
                active INTEGER DEFAULT 1,
                metadata TEXT,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        
        conn.commit()
        conn.close()
        logger.info("✅ All database tables created successfully")
    
    # ===== USER OPERATIONS =====
    
    def create_user(self, user_id: int, username: str, first_name: str, 
                   last_name: str = None, referred_by: int = None, 
                   signup_bonus: int = 0) -> bool:
        """Create new user"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO users (
                    user_id, username, first_name, last_name, 
                    tokens, referred_by
                ) VALUES (?, ?, ?, ?, ?, ?)
            """, (user_id, username, first_name, last_name, signup_bonus, referred_by))
            
            if signup_bonus > 0:
                cursor.execute("""
                    INSERT INTO transactions (
                        user_id, type, amount, description, 
                        balance_before, balance_after
                    ) VALUES (?, 'bonus', ?, 'Welcome signup bonus', 0, ?)
                """, (user_id, signup_bonus, signup_bonus))
            
            conn.commit()
            conn.close()
            
            logger.info(f"✅ Created user {user_id} ({username})")
            return True
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error creating user: {e}")
            return False
    
    def get_user(self, user_id: int) -> Optional[Dict]:
        """Get user by ID"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
            row = cursor.fetchone()
            conn.close()
            
            return dict(row) if row else None
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error getting user: {e}")
            return None
    
    def update_user_activity(self, user_id: int):
        """Update user's last active timestamp"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                UPDATE users 
                SET last_active = CURRENT_TIMESTAMP 
                WHERE user_id = ?
            """, (user_id,))
            
            conn.commit()
            conn.close()
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error updating activity: {e}")
    
    def update_user_level(self, user_id: int, new_level: int) -> bool:
        """Update user's level"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                UPDATE users SET level = ? WHERE user_id = ?
            """, (new_level, user_id))
            
            conn.commit()
            conn.close()
            
            logger.info(f"✅ Updated user {user_id} to level {new_level}")
            return True
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error updating level: {e}")
            return False
    
    def update_user_tokens(self, user_id: int, amount: int, 
                          tx_type: str, description: str,
                          related_id: int = None) -> bool:
        """Update user tokens and log transaction"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            # Get current balance
            cursor.execute("SELECT tokens FROM users WHERE user_id = ?", (user_id,))
            row = cursor.fetchone()
            if not row:
                return False
            
            current_balance = row[0]
            new_balance = current_balance + amount
            
            # Prevent negative balance
            if new_balance < 0:
                logger.warning(f"⚠️ Insufficient balance for user {user_id}")
                return False
            
            # Update balance
            cursor.execute("""
                UPDATE users 
                SET tokens = tokens + ?,
                    total_earned = total_earned + CASE WHEN ? > 0 THEN ? ELSE 0 END,
                    total_spent = total_spent + CASE WHEN ? < 0 THEN ABS(?) ELSE 0 END
                WHERE user_id = ?
            """, (amount, amount, amount, amount, amount, user_id))
            
            # Log transaction
            cursor.execute("""
                INSERT INTO transactions (
                    user_id, type, amount, description, related_id,
                    balance_before, balance_after
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (user_id, tx_type, amount, description, related_id,
                  current_balance, new_balance))
            
            conn.commit()
            conn.close()
            
            logger.info(f"✅ Updated tokens for user {user_id}: {amount:+d}")
            return True
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error updating tokens: {e}")
            return False
    
    def update_trust_score(self, user_id: int, change: int, reason: str) -> bool:
        """Update user's trust score"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                UPDATE users 
                SET trust_score = MAX(10, MIN(200, trust_score + ?))
                WHERE user_id = ?
            """, (change, user_id))
            
            conn.commit()
            conn.close()
            
            logger.info(f"✅ Updated trust score for {user_id}: {change:+d} ({reason})")
            return True
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error updating trust score: {e}")
            return False
    
    # ===== CAMPAIGN OPERATIONS =====
    
    def create_campaign(self, user_id: int, channel_link: str, 
                       target_members: int, join_reward: int,
                       advertiser_rate: int, platform_fee: int,
                       total_cost: int, campaign_type: str = 'standard',
                       priority: int = 0) -> Optional[int]:
        """Create new campaign"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO campaigns (
                    user_id, channel_link, target_members,
                    join_reward, advertiser_rate, platform_fee,
                    total_cost, campaign_type, priority,
                    started_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            """, (user_id, channel_link, target_members, join_reward,
                  advertiser_rate, platform_fee, total_cost, 
                  campaign_type, priority))
            
            campaign_id = cursor.lastrowid
            
            conn.commit()
            conn.close()
            
            logger.info(f"✅ Created campaign {campaign_id} for user {user_id}")
            return campaign_id
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error creating campaign: {e}")
            return None
    
    def get_active_campaigns(self, limit: int = 10, 
                            exclude_user: int = None) -> List[Dict]:
        """Get active campaigns"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            query = """
                SELECT * FROM campaigns 
                WHERE status = 'active' 
                AND delivered_members < target_members
            """
            params = []
            
            if exclude_user:
                query += " AND user_id != ?"
                params.append(exclude_user)
            
            query += " ORDER BY priority DESC, created_at ASC LIMIT ?"
            params.append(limit)
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            conn.close()
            
            return [dict(row) for row in rows]
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error getting campaigns: {e}")
            return []
    
    def get_user_campaigns(self, user_id: int) -> List[Dict]:
        """Get user's campaigns"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT * FROM campaigns 
                WHERE user_id = ? 
                ORDER BY created_at DESC
            """, (user_id,))
            
            rows = cursor.fetchall()
            conn.close()
            
            return [dict(row) for row in rows]
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error getting user campaigns: {e}")
            return []
    
    def user_joined_campaign(self, campaign_id: int, user_id: int) -> bool:
        """Check if user already joined campaign"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT id FROM campaign_joins 
                WHERE campaign_id = ? AND user_id = ?
            """, (campaign_id, user_id))
            
            result = cursor.fetchone() is not None
            conn.close()
            
            return result
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error checking join: {e}")
            return False
    
    def add_campaign_join(self, campaign_id: int, user_id: int, 
                         reward_multiplier: float = 1.0) -> bool:
        """Add campaign join record"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO campaign_joins (
                    campaign_id, user_id, reward_multiplier
                ) VALUES (?, ?, ?)
            """, (campaign_id, user_id, reward_multiplier))
            
            # Update campaign pending count
            cursor.execute("""
                UPDATE campaigns 
                SET pending_members = pending_members + 1
                WHERE id = ?
            """, (campaign_id,))
            
            conn.commit()
            conn.close()
            
            logger.info(f"✅ User {user_id} joined campaign {campaign_id}")
            return True
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error adding join: {e}")
            return False
    
    def verify_campaign_join(self, campaign_id: int, user_id: int, 
                            tokens_earned: int) -> bool:
        """Verify campaign join and credit tokens"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            # Update join record
            cursor.execute("""
                UPDATE campaign_joins 
                SET verified = 1, 
                    verified_at = CURRENT_TIMESTAMP,
                    tokens_earned = ?
                WHERE campaign_id = ? AND user_id = ?
            """, (tokens_earned, campaign_id, user_id))
            
            # Update campaign counts
            cursor.execute("""
                UPDATE campaigns 
                SET pending_members = pending_members - 1,
                    verified_members = verified_members + 1,
                    delivered_members = delivered_members + 1
                WHERE id = ?
            """, (campaign_id,))
            
            # Update user stats
            cursor.execute("""
                UPDATE users 
                SET total_joins = total_joins + 1
                WHERE user_id = ?
            """, (user_id,))
            
            # Check if campaign is complete
            cursor.execute("""
                SELECT delivered_members, target_members 
                FROM campaigns WHERE id = ?
            """, (campaign_id,))
            
            row = cursor.fetchone()
            if row and row[0] >= row[1]:
                cursor.execute("""
                    UPDATE campaigns 
                    SET status = 'completed',
                        completed_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                """, (campaign_id,))
            
            conn.commit()
            conn.close()
            
            logger.info(f"✅ Verified join for user {user_id} in campaign {campaign_id}")
            return True
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error verifying join: {e}")
            return False
    
    # ===== LEADERBOARD & STATS =====
    
    def get_leaderboard(self, limit: int = 10, 
                       metric: str = 'total_earned') -> List[Dict]:
        """Get top users leaderboard"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            valid_metrics = ['total_earned', 'total_joins', 'level', 'total_referrals']
            if metric not in valid_metrics:
                metric = 'total_earned'
            
            cursor.execute(f"""
                SELECT user_id, username, first_name, {metric}, level, trust_score
                FROM users 
                WHERE is_banned = 0
                ORDER BY {metric} DESC, level DESC
                LIMIT ?
            """, (limit,))
            
            rows = cursor.fetchall()
            conn.close()
            
            return [dict(row) for row in rows]
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error getting leaderboard: {e}")
            return []
    
    def get_system_stats(self) -> Dict[str, Any]:
        """Get system-wide statistics"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            stats = {}
            
            # User stats
            cursor.execute("SELECT COUNT(*) FROM users")
            stats['total_users'] = cursor.fetchone()[0]
            
            cursor.execute("""
                SELECT COUNT(*) FROM users 
                WHERE last_active >= datetime('now', '-24 hours')
            """)
            stats['active_users_24h'] = cursor.fetchone()[0]
            
            # Campaign stats
            cursor.execute("SELECT COUNT(*) FROM campaigns")
            stats['total_campaigns'] = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM campaigns WHERE status = 'active'")
            stats['active_campaigns'] = cursor.fetchone()[0]
            
            # Token stats
            cursor.execute("SELECT SUM(tokens) FROM users")
            result = cursor.fetchone()[0]
            stats['tokens_in_circulation'] = result if result else 0
            
            # Platform profit
            cursor.execute("""
                SELECT SUM(platform_fee) FROM campaigns 
                WHERE status IN ('active', 'completed')
            """)
            result = cursor.fetchone()[0]
            stats['platform_profit'] = result if result else 0
            
            conn.close()
            
            return stats
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error getting system stats: {e}")
            return {}
    
    # ===== ACHIEVEMENT & TASK OPERATIONS =====
    
    def unlock_achievement(self, user_id: int, achievement_id: str) -> bool:
        """Unlock achievement for user"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT OR IGNORE INTO achievements (user_id, achievement_id)
                VALUES (?, ?)
            """, (user_id, achievement_id))
            
            affected = cursor.rowcount
            conn.commit()
            conn.close()
            
            if affected > 0:
                logger.info(f"✅ Unlocked achievement {achievement_id} for user {user_id}")
            
            return affected > 0
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error unlocking achievement: {e}")
            return False
    
    def has_achievement(self, user_id: int, achievement_id: str) -> bool:
        """Check if user has achievement"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT claimed FROM achievements 
                WHERE user_id = ? AND achievement_id = ?
            """, (user_id, achievement_id))
            
            row = cursor.fetchone()
            conn.close()
            
            return row is not None
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error checking achievement: {e}")
            return False
    
    def claim_achievement(self, user_id: int, achievement_id: str) -> bool:
        """Claim achievement reward"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                UPDATE achievements 
                SET claimed = 1, claimed_at = CURRENT_TIMESTAMP
                WHERE user_id = ? AND achievement_id = ? AND claimed = 0
            """, (user_id, achievement_id))
            
            affected = cursor.rowcount
            conn.commit()
            conn.close()
            
            return affected > 0
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error claiming achievement: {e}")
            return False
    
    def get_user_achievements(self, user_id: int) -> List[Dict]:
        """Get user's achievements"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT * FROM achievements 
                WHERE user_id = ?
                ORDER BY claimed_at DESC
            """, (user_id,))
            
            rows = cursor.fetchall()
            conn.close()
            
            return [dict(row) for row in rows]
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error getting achievements: {e}")
            return []

# Initialize logger
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
