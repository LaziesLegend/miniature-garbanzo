#!/usr/bin/env python3
"""
Auto-installer for Telegram Premium Exchange Bot PRO
"""
import subprocess
import sys

def install_dependencies():
    """Install required packages"""
    print("📦 Installing dependencies...")
    packages = [
        "python-telegram-bot==21.0",
        "pillow==10.4.0"
    ]
    
    for package in packages:
        try:
            __import__(package.split('==')[0].replace('-', '_'))
            print(f"✅ {package} already installed")
        except ImportError:
            print(f"📥 Installing {package}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", package])
            print(f"✅ {package} installed")

if __name__ == "__main__":
    try:
        install_dependencies()
        print("\n✅ All dependencies installed!")
        print("📝 Now run: python main.py")
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)
