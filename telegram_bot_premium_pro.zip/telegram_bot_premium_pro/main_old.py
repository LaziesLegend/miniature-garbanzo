"""
🤖 TELEGRAM PREMIUM EXCHANGE BOT PRO - ENHANCED
Complete Feature-Rich Bot with ADMIN PANEL, DEPOSITS, & USER IDs
Version: 4.1.0 PRO - Production Ready
"""

import logging
import asyncio
import random
from datetime import datetime, timedelta
from typing import Optional

try:
    from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
    from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
    from telegram.constants import ParseMode
except ImportError:
    print("📦 Installing required packages...")
    import subprocess
    import sys
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "python-telegram-bot==21.0"])
    from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
    from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
    from telegram.constants import ParseMode

from database import Database
from config import *

# Setup logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Initialize database
db = Database(DATABASE_NAME)

# ========================
# 🎯 UTILITY FUNCTIONS
# ========================

def is_admin(user_id: int) -> bool:
    """Check if user is admin"""
    return user_id in ADMIN_IDS

async def get_or_create_user(update: Update) -> dict:
    """Get user or create if new with referral tracking"""
    user = update.effective_user
    
    existing = db.get_user(user.id)
    if existing:
        db.update_user_activity(user.id)
        return existing
    
    # Handle referral
    referrer_id = None
    if update.message and update.message.text.startswith('/start'):
        args = update.message.text.split()
        if len(args) > 1 and args[1].startswith('REF'):
            try:
                referrer_id = int(args[1][3:])
                if referrer_id == user.id:
                    referrer_id = None
            except (IndexError, ValueError):
                pass
    
    # Create new user
    db.create_user(
        user_id=user.id,
        username=user.username or "Unknown",
        first_name=user.first_name or "User",
        last_name=user.last_name,
        referred_by=referrer_id,
        signup_bonus=SIGNUP_BONUS
    )
    
    # Process referral bonus
    if referrer_id:
        process_referral_bonus(referrer_id, user.id)
    
    return db.get_user(user.id)

def process_referral_bonus(referrer_id: int, referred_id: int):
    """Process multi-level referral bonuses"""
    try:
        # Level 1 bonus
        db.update_user_tokens(
            referrer_id, 
            REFERRAL_BONUS_L1, 
            'referral', 
            f'Level 1 referral bonus from user {referred_id}'
        )
        
        # Level 2 bonus
        referrer = db.get_user(referrer_id)
        if referrer and referrer['referred_by']:
            db.update_user_tokens(
                referrer['referred_by'],
                REFERRAL_BONUS_L2,
                'referral',
                f'Level 2 referral bonus from user {referred_id}'
            )
            
            # Level 3 bonus
            referrer_l2 = db.get_user(referrer['referred_by'])
            if referrer_l2 and referrer_l2['referred_by']:
                db.update_user_tokens(
                    referrer_l2['referred_by'],
                    REFERRAL_BONUS_L3,
                    'referral',
                    f'Level 3 referral bonus from user {referred_id}'
                )
        
        # Update referral count
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE users SET total_referrals = total_referrals + 1
            WHERE user_id = ?
        """, (referrer_id,))
        conn.commit()
        conn.close()
        
    except Exception as e:
        logger.error(f"Error processing referral: {e}")

def get_main_keyboard() -> ReplyKeyboardMarkup:
    """Get main menu keyboard"""
    keyboard = [
        [KeyboardButton("💼 My Wallet"), KeyboardButton("🚀 Earn Tokens")],
        [KeyboardButton("📊 My Campaigns"), KeyboardButton("➕ Create Campaign")],
        [KeyboardButton("👥 Referrals"), KeyboardButton("🏆 Achievements")],
        [KeyboardButton("🎁 Daily Bonus"), KeyboardButton("📈 Leaderboard")],
        [KeyboardButton("💳 Deposit"), KeyboardButton("💸 Withdraw")],
        [KeyboardButton("🏪 Shop"), KeyboardButton("ℹ️ Help")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

# ========================
# 🏠 START & MAIN MENU
# ========================

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start command handler"""
    user_data = await get_or_create_user(update)
    user = update.effective_user
    
    welcome_msg = f"""
🎉 <b>Welcome to Premium Exchange Bot!</b>

👤 <b>Your Profile:</b>
User ID: <code>{user_data['user_id']}</code>
💼 Balance: {user_data['tokens']:,} tokens
💎 Level: {LEVELS[user_data['level']]['name']}

💰 <b>Earn Tokens Multiple Ways:</b>
• Join campaigns: {JOIN_REWARD} tokens
• Refer friends: {REFERRAL_BONUS_L1} tokens
• Daily login: {DAILY_LOGIN_BONUS} tokens
• Achievements: Up to 10,000 tokens

👇 <b>Choose an option:</b>
"""
    
    try:
        with open('bot_logo.png', 'rb') as logo:
            await update.message.reply_photo(
                photo=logo,
                caption=welcome_msg,
                parse_mode=ParseMode.HTML,
                reply_markup=get_main_keyboard()
            )
    except:
        await update.message.reply_text(
            welcome_msg,
            parse_mode=ParseMode.HTML,
            reply_markup=get_main_keyboard()
        )

async def menu_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle menu button presses"""
    text = update.message.text
    user_data = await get_or_create_user(update)
    
    if text == "💼 My Wallet":
        await wallet_command(update, context)
    elif text == "🚀 Earn Tokens":
        await earn_command(update, context)
    elif text == "📊 My Campaigns":
        await my_campaigns_command(update, context)
    elif text == "➕ Create Campaign":
        await create_campaign_start(update, context)
    elif text == "👥 Referrals":
        await referral_command(update, context)
    elif text == "🏆 Achievements":
        await achievements_command(update, context)
    elif text == "🎁 Daily Bonus":
        await daily_bonus_command(update, context)
    elif text == "📈 Leaderboard":
        await leaderboard_command(update, context)
    elif text == "💳 Deposit":
        await deposit_start(update, context)
    elif text == "💸 Withdraw":
        await withdraw_start(update, context)
    elif text == "🏪 Shop":
        await shop_command(update, context)
    elif text == "ℹ️ Help":
        await help_command(update, context)

# ========================
# 💼 WALLET & BALANCE
# ========================

async def wallet_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show wallet information"""
    user_data = await get_or_create_user(update)
    level_data = LEVELS[user_data['level']]
    
    next_level = user_data['level'] + 1
    next_level_joins = LEVELS[next_level]['joins'] if next_level in LEVELS else None
    
    wallet_text = f"""
💼 <b>YOUR WALLET</b>

👤 <b>User ID:</b> <code>{user_data['user_id']}</code>
💰 <b>Balance:</b> {user_data['tokens']:,} tokens
{level_data['name']} <b>Level {user_data['level']}</b>

📊 <b>Statistics:</b>
• Total Earned: {user_data['total_earned']:,} tokens
• Total Spent: {user_data['total_spent']:,} tokens
• Total Joins: {user_data['total_joins']:,}
• Total Referrals: {user_data['total_referrals']:,}

⭐ <b>Trust Score:</b> {user_data['trust_score']}/200
🎯 <b>Reward Multiplier:</b> {level_data['reward_multiplier']}x

"""
    
    if next_level_joins:
        progress = user_data['total_joins']
        remaining = next_level_joins - progress
        wallet_text += f"📈 <b>Next Level:</b> {remaining:,} more joins needed\n"
    
    keyboard = [
        [
            InlineKeyboardButton("💳 Deposit", callback_data="deposit_menu"),
            InlineKeyboardButton("💸 Withdraw", callback_data="withdraw_menu")
        ],
        [
            InlineKeyboardButton("📊 Transactions", callback_data="transactions"),
            InlineKeyboardButton("🏠 Home", callback_data="home")
        ]
    ]
    
    await update.message.reply_text(
        wallet_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ========================
# 💳 DEPOSIT SYSTEM
# ========================

async def deposit_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start deposit process"""
    user_data = await get_or_create_user(update)
    
    deposit_text = """
💳 <b>DEPOSIT TOKENS</b>

💰 <b>Deposit Packages:</b>

🥉 Bronze: 1,000 tokens (+50 bonus)
🥈 Silver: 5,000 tokens (+500 bonus)
🥇 Gold: 15,000 tokens (+2,250 bonus)
💎 Platinum: 50,000 tokens (+12,500 bonus)

👇 <b>Enter amount to deposit (numbers only):</b>

Or select a package above:
"""
    
    keyboard = [
        [InlineKeyboardButton("🥉 Bronze (1K)", callback_data="deposit_1000")],
        [InlineKeyboardButton("🥈 Silver (5K)", callback_data="deposit_5000")],
        [InlineKeyboardButton("🥇 Gold (15K)", callback_data="deposit_15000")],
        [InlineKeyboardButton("💎 Platinum (50K)", callback_data="deposit_50000")],
        [InlineKeyboardButton("🏠 Home", callback_data="home")]
    ]
    
    msg = await update.message.reply_text(
        deposit_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    
    context.user_data['deposit_msg_id'] = msg.message_id
    context.user_data['awaiting'] = 'deposit_amount'

async def handle_deposit_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle deposit selection"""
    query = update.callback_query
    await query.answer()
    
    user_data = await get_or_create_user(update)
    
    if query.data.startswith('deposit_'):
        amount = int(query.data.split('_')[1])
        context.user_data['deposit_amount'] = amount
        
        # Calculate bonus
        bonus = int(amount * 0.05)  # 5% default bonus
        for tier, data in DEPOSIT_TIERS.items():
            if amount >= data['min']:
                bonus = int(amount * (data['bonus_percent'] / 100))
        
        total = amount + bonus
        
        deposit_text = f"""
💳 <b>DEPOSIT CONFIRMATION</b>

Amount: {amount:,} tokens
💰 Bonus: +{bonus:,} tokens
✅ Total: {total:,} tokens

📱 <b>Choose Payment Method:</b>
"""
        
        keyboard = [
            [InlineKeyboardButton("📱 UPI", callback_data="deposit_method_upi")],
            [InlineKeyboardButton("₿ Crypto", callback_data="deposit_method_crypto")],
            [InlineKeyboardButton("💳 PayPal", callback_data="deposit_method_paypal")],
            [InlineKeyboardButton("📲 Paytm", callback_data="deposit_method_paytm")],
            [InlineKeyboardButton("⬅️ Back", callback_data="deposit_back")]
        ]
        
        await query.edit_message_text(
            deposit_text,
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

async def handle_deposit_method(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle payment method selection"""
    query = update.callback_query
    await query.answer()
    
    user_data = await get_or_create_user(update)
    method = query.data.split('_')[2].upper()
    context.user_data['deposit_method'] = method
    context.user_data['awaiting'] = 'deposit_screenshot'
    
    amount = context.user_data.get('deposit_amount', 0)
    
    method_info = DEPOSIT_METHODS.get(method, {})
    
    deposit_text = f"""
💳 <b>DEPOSIT VIA {method}</b>

Amount: {amount:,} tokens

📤 <b>Instructions:</b>

1️⃣ Send payment using details below
2️⃣ Take screenshot of payment
3️⃣ Send screenshot here
4️⃣ Admin will verify and credit

📞 <b>Payment Details:</b>
{method_info.get('payment_info', f'{method} details here')}

👇 <b>Send screenshot of payment proof:</b>
"""
    
    keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="deposit_method_back")]]
    
    await query.edit_message_text(
        deposit_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def handle_deposit_screenshot(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle deposit screenshot submission"""
    user_data = await get_or_create_user(update)
    
    if not update.message.photo:
        await update.message.reply_text("❌ Please send an image!")
        return
    
    amount = context.user_data.get('deposit_amount', 0)
    method = context.user_data.get('deposit_method', 'UNKNOWN')
    
    # Get photo file ID
    photo = update.message.photo[-1]
    file_id = photo.file_id
    
    # Calculate bonus
    bonus = int(amount * 0.05)
    for tier, data in DEPOSIT_TIERS.items():
        if amount >= data['min']:
            bonus = int(amount * (data['bonus_percent'] / 100))
    
    total = amount + bonus
    
    # Store deposit request in database (placeholder - add to database.py)
    
    confirmation_text = f"""
✅ <b>DEPOSIT SUBMITTED!</b>

Amount: {amount:,} tokens
Bonus: +{bonus:,} tokens
Total: {total:,} tokens

Method: {method}
Status: ⏳ Pending Admin Approval

👤 Your User ID: <code>{user_data['user_id']}</code>

Admin will verify and credit your account within 24 hours.

📞 If not credited, contact admin @holabrooo
"""
    
    # Send to admin
    admin_msg = f"""
💳 <b>NEW DEPOSIT REQUEST</b>

👤 User: {user_data['first_name']} (@{user_data['username']})
User ID: {user_data['user_id']}

Amount: {amount:,} tokens
Bonus: +{bonus:,} tokens
Total: {total:,} tokens

Method: {method}

Screenshot: [Attached]

👉 Reply with /approve_{user_data['user_id']}_{amount} to approve
"""
    
    try:
        # Send message to admin
        for admin_id in ADMIN_IDS:
            await context.bot.send_photo(
                chat_id=admin_id,
                photo=file_id,
                caption=admin_msg,
                parse_mode=ParseMode.HTML
            )
    except Exception as e:
        logger.error(f"Error sending to admin: {e}")
    
    keyboard = [
        [InlineKeyboardButton("💳 Deposit Again", callback_data="deposit_menu")],
        [InlineKeyboardButton("🏠 Home", callback_data="home")]
    ]
    
    await update.message.reply_text(
        confirmation_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    
    context.user_data.clear()

# ========================
# 💸 WITHDRAW SYSTEM
# ========================

async def withdraw_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start withdrawal process"""
    user_data = await get_or_create_user(update)
    
    if user_data['tokens'] < MIN_WITHDRAWAL:
        await update.message.reply_text(
            f"❌ Minimum withdrawal: {MIN_WITHDRAWAL:,} tokens\n"
            f"Your balance: {user_data['tokens']:,} tokens",
            reply_markup=get_main_keyboard()
        )
        return
    
    withdraw_text = f"""
💸 <b>WITHDRAW TOKENS</b>

💰 <b>Your Balance:</b> {user_data['tokens']:,} tokens
💳 <b>Min Withdrawal:</b> {MIN_WITHDRAWAL:,} tokens
🎁 <b>Withdrawal Fee:</b> {WITHDRAWAL_FEE_PERCENT}%

👇 <b>Enter amount (numbers only):</b>

Or select quick amount:
"""
    
    keyboard = [
        [InlineKeyboardButton(f"💸 {MIN_WITHDRAWAL:,}", callback_data=f"withdraw_{MIN_WITHDRAWAL}")],
        [InlineKeyboardButton(f"💸 {MIN_WITHDRAWAL*2:,}", callback_data=f"withdraw_{MIN_WITHDRAWAL*2}")],
        [InlineKeyboardButton(f"💸 {MIN_WITHDRAWAL*5:,}", callback_data=f"withdraw_{MIN_WITHDRAWAL*5}")],
        [InlineKeyboardButton("🏠 Home", callback_data="home")]
    ]
    
    msg = await update.message.reply_text(
        withdraw_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    
    context.user_data['withdraw_msg_id'] = msg.message_id
    context.user_data['awaiting'] = 'withdraw_amount'

async def handle_withdraw_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle withdrawal selection"""
    query = update.callback_query
    await query.answer()
    
    user_data = await get_or_create_user(update)
    
    if query.data.startswith('withdraw_'):
        amount = int(query.data.split('_')[1])
        
        if amount > user_data['tokens']:
            await query.answer("❌ Insufficient balance!", show_alert=True)
            return
        
        if amount < MIN_WITHDRAWAL:
            await query.answer(f"❌ Minimum: {MIN_WITHDRAWAL:,}", show_alert=True)
            return
        
        context.user_data['withdraw_amount'] = amount
        
        # Calculate fee
        fee = int(amount * (WITHDRAWAL_FEE_PERCENT / 100))
        if user_data['is_vip']:
            fee = int(amount * (VIP_WITHDRAWAL_FEE / 100))
        
        net = amount - fee
        
        withdraw_text = f"""
💸 <b>WITHDRAWAL CONFIRMATION</b>

Amount: {amount:,} tokens
🔴 Fee: -{fee:,} tokens ({WITHDRAWAL_FEE_PERCENT}%)
✅ You'll Receive: {net:,} tokens

📱 <b>Choose Withdrawal Method:</b>
"""
        
        keyboard = [
            [InlineKeyboardButton("📱 UPI", callback_data="withdraw_method_upi")],
            [InlineKeyboardButton("💳 PayPal", callback_data="withdraw_method_paypal")],
            [InlineKeyboardButton("📲 Paytm", callback_data="withdraw_method_paytm")],
            [InlineKeyboardButton("💰 Bank Transfer", callback_data="withdraw_method_bank")],
            [InlineKeyboardButton("⬅️ Back", callback_data="withdraw_back")]
        ]
        
        await query.edit_message_text(
            withdraw_text,
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

async def handle_withdraw_method(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle withdrawal method selection"""
    query = update.callback_query
    await query.answer()
    
    user_data = await get_or_create_user(update)
    method = query.data.split('_')[2].upper()
    context.user_data['withdraw_method'] = method
    context.user_data['awaiting'] = 'withdraw_details'
    
    amount = context.user_data.get('withdraw_amount', 0)
    fee = int(amount * (WITHDRAWAL_FEE_PERCENT / 100))
    net = amount - fee
    
    withdraw_text = f"""
💸 <b>WITHDRAWAL VIA {method}</b>

Amount: {amount:,} tokens
Net Amount: {net:,} tokens

👇 <b>Enter your {method} details:</b>

For UPI: UPI ID (user@bank)
For PayPal: PayPal email
For Bank: Account number
For Paytm: Paytm number
"""
    
    keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="withdraw_method_back")]]
    
    await query.edit_message_text(
        withdraw_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def handle_withdraw_details(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle withdrawal details submission"""
    user_data = await get_or_create_user(update)
    
    details = update.message.text
    method = context.user_data.get('withdraw_method', 'UNKNOWN')
    amount = context.user_data.get('withdraw_amount', 0)
    
    if not details:
        await update.message.reply_text("❌ Please enter withdrawal details!")
        return
    
    # Calculate fee and net
    fee = int(amount * (WITHDRAWAL_FEE_PERCENT / 100))
    net = amount - fee
    
    # Deduct tokens
    if db.update_user_tokens(user_data['user_id'], -amount, 'withdrawal_request', f'Withdrawal request: {method} {net} tokens'):
        
        confirmation_text = f"""
✅ <b>WITHDRAWAL SUBMITTED!</b>

Amount: {amount:,} tokens
Fee: -{fee:,} tokens
You'll Receive: {net:,} tokens

Method: {method}
Status: ⏳ Processing (24-48 hours)

👤 Your User ID: <code>{user_data['user_id']}</code>

📞 Contact admin @holabrooo if not received
"""
        
        # Send to admin
        admin_msg = f"""
💸 <b>WITHDRAWAL REQUEST</b>

👤 User: {user_data['first_name']} (@{user_data['username']})
User ID: {user_data['user_id']}

Amount: {amount:,} tokens
Net: {net:,} tokens
Fee: {fee:,} tokens

Method: {method}
Details: {details}

Status: Pending Processing
"""
        
        try:
            for admin_id in ADMIN_IDS:
                await context.bot.send_message(
                    chat_id=admin_id,
                    text=admin_msg,
                    parse_mode=ParseMode.HTML
                )
        except Exception as e:
            logger.error(f"Error sending to admin: {e}")
        
        keyboard = [
            [InlineKeyboardButton("💸 Withdraw Again", callback_data="withdraw_menu")],
            [InlineKeyboardButton("🏠 Home", callback_data="home")]
        ]
        
        await update.message.reply_text(
            confirmation_text,
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        
        context.user_data.clear()
    else:
        await update.message.reply_text(
            "❌ Withdrawal failed. Please try again.",
            reply_markup=get_main_keyboard()
        )

# ========================
# 👑 ADMIN PANEL
# ========================

async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show admin control panel"""
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("❌ Admin only!")
        return
    
    stats = db.get_system_stats()
    
    admin_text = f"""
👑 <b>ADMIN CONTROL PANEL</b>

📊 <b>System Stats:</b>
👥 Users: {stats.get('total_users', 0):,}
🟢 Active: {stats.get('active_users_24h', 0):,}
📢 Campaigns: {stats.get('total_campaigns', 0):,}
💰 Profit: {stats.get('platform_profit', 0):,}
💎 Tokens: {stats.get('tokens_in_circulation', 0):,}
"""
    
    keyboard = [
        [InlineKeyboardButton("💳 Deposits", callback_data="admin_deposits")],
        [InlineKeyboardButton("💸 Withdrawals", callback_data="admin_withdrawals")],
        [InlineKeyboardButton("🔧 Customize", callback_data="admin_customize")],
        [InlineKeyboardButton("📢 Announce", callback_data="admin_announce")],
        [InlineKeyboardButton("👥 Users", callback_data="admin_users")],
        [InlineKeyboardButton("🚫 Ban User", callback_data="admin_ban")]
    ]
    
    await update.message.reply_text(
        admin_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ========================
# 🚀 EARN TOKENS
# ========================

async def earn_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show available earning opportunities"""
    user_data = await get_or_create_user(update)
    level_data = LEVELS[user_data['level']]
    
    campaigns = db.get_active_campaigns(limit=5, exclude_user=user_data['user_id'])
    
    if not campaigns:
        await update.message.reply_text(
            "🔍 <b>No Active Campaigns</b>\n\n"
            "No campaigns available right now.\n"
            "Check back soon!",
            parse_mode=ParseMode.HTML,
            reply_markup=get_main_keyboard()
        )
        return
    
    earn_text = f"""
🚀 <b>EARN TOKENS</b>

Your Earning Rate: <b>{level_data['reward_multiplier']}x</b>
Base Reward: <b>{JOIN_REWARD} tokens</b>
Your Reward: <b>{int(JOIN_REWARD * level_data['reward_multiplier'])} tokens</b>

📢 <b>Available Campaigns ({len(campaigns)}):</b>

"""
    
    keyboard = []
    for i, campaign in enumerate(campaigns, 1):
        reward = int(campaign['join_reward'] * level_data['reward_multiplier'])
        progress = campaign['delivered_members']
        target = campaign['target_members']
        campaign_type = CAMPAIGN_TYPES.get(campaign['campaign_type'], {}).get('name', 'Standard')
        
        earn_text += f"{i}. {campaign_type}\n"
        earn_text += f"   Reward: {reward} tokens | Progress: {progress}/{target}\n\n"
        
        if not db.user_joined_campaign(campaign['id'], user_data['user_id']):
            keyboard.append([
                InlineKeyboardButton(
                    f"🎯 Join #{i}",
                    callback_data=f"join_campaign_{campaign['id']}"
                )
            ])
    
    keyboard.append([InlineKeyboardButton("🏠 Home", callback_data="home")])
    
    await update.message.reply_text(
        earn_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ========================
# 📊 MY CAMPAIGNS
# ========================

async def my_campaigns_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user's campaigns"""
    user_data = await get_or_create_user(update)
    campaigns = db.get_user_campaigns(user_data['user_id'])
    
    if not campaigns:
        await update.message.reply_text(
            "📊 <b>MY CAMPAIGNS</b>\n\n"
            "You haven't created any campaigns yet.\n"
            "Use ➕ Create Campaign to start!",
            parse_mode=ParseMode.HTML,
            reply_markup=get_main_keyboard()
        )
        return
    
    campaign_text = f"📊 <b>MY CAMPAIGNS</b>\n\nTotal: {len(campaigns)}\n\n"
    
    keyboard = []
    for campaign in campaigns[:10]:
        status_emoji = "✅" if campaign['status'] == 'completed' else "🔄" if campaign['status'] == 'active' else "❌"
        progress = campaign['delivered_members']
        target = campaign['target_members']
        percentage = int((progress / target) * 100) if target > 0 else 0
        
        campaign_text += f"{status_emoji} <b>Campaign #{campaign['id']}</b>\n"
        campaign_text += f"Channel: {campaign['channel_link']}\n"
        campaign_text += f"Progress: {progress}/{target} ({percentage}%)\n\n"
        
        keyboard.append([
            InlineKeyboardButton(
                f"View #{campaign['id']} - {percentage}%",
                callback_data=f"view_campaign_{campaign['id']}"
            )
        ])
    
    keyboard.append([InlineKeyboardButton("🏠 Home", callback_data="home")])
    
    await update.message.reply_text(
        campaign_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ========================
# ➕ CREATE CAMPAIGN
# ========================

async def create_campaign_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start campaign creation"""
    user_data = await get_or_create_user(update)
    level_data = LEVELS[user_data['level']]
    
    create_text = f"""
➕ <b>CREATE CAMPAIGN</b>

Promote your channel and get real members!

💰 <b>Your Cost:</b> {ADVERTISER_COST} tokens/member
📊 <b>Member Reward:</b> {JOIN_REWARD} tokens
🏢 <b>Platform Fee:</b> {PLATFORM_FEE} tokens

🎯 <b>Campaign Types:</b>

"""
    
    keyboard = []
    for type_id, type_data in CAMPAIGN_TYPES.items():
        cost = int(ADVERTISER_COST * type_data['cost_multiplier'])
        create_text += f"{type_data['name']}\n"
        create_text += f"Cost: {cost} tokens/member | Priority: {type_data['priority']}\n"
        if 'features' in type_data:
            create_text += f"Features: {', '.join(type_data['features'])}\n"
        create_text += "\n"
        
        keyboard.append([
            InlineKeyboardButton(
                f"{type_data['name']}",
                callback_data=f"campaign_type_{type_id}"
            )
        ])
    
    create_text += f"\n💼 <b>Your Balance:</b> {user_data['tokens']:,} tokens"
    keyboard.append([InlineKeyboardButton("🏠 Home", callback_data="home")])
    
    await update.message.reply_text(
        create_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ========================
# 👥 REFERRAL SYSTEM
# ========================

async def referral_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show referral information"""
    user_data = await get_or_create_user(update)
    bot_username = (await context.bot.get_me()).username
    referral_link = f"https://t.me/{bot_username}?start=REF{user_data['user_id']}"
    
    referral_text = f"""
👥 <b>REFERRAL PROGRAM</b>

👤 <b>Your User ID:</b> <code>{user_data['user_id']}</code>

Invite friends and earn rewards!

🎁 <b>Referral Bonuses:</b>
• Level 1: {REFERRAL_BONUS_L1} tokens per referral
• Level 2: {REFERRAL_BONUS_L2} tokens
• Level 3: {REFERRAL_BONUS_L3} tokens

📊 <b>Your Stats:</b>
• Total Referrals: {user_data['total_referrals']}
• Estimated Earnings: {user_data['total_referrals'] * REFERRAL_BONUS_L1:,} tokens

🔗 <b>Your Referral Link:</b>
<code>{referral_link}</code>

Tap to copy and share!
"""
    
    keyboard = [
        [InlineKeyboardButton("📤 Share", url=f"https://t.me/share/url?url={referral_link}")],
        [InlineKeyboardButton("📋 Copy Link", callback_data="copy_referral")],
        [InlineKeyboardButton("🏠 Home", callback_data="home")]
    ]
    
    await update.message.reply_text(
        referral_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ========================
# 🏆 ACHIEVEMENTS
# ========================

async def achievements_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show achievements"""
    user_data = await get_or_create_user(update)
    user_achievements = db.get_user_achievements(user_data['user_id'])
    unlocked_ids = {a['achievement_id'] for a in user_achievements}
    
    total_rewards = sum(ACHIEVEMENTS[a['achievement_id']]['reward'] 
                       for a in user_achievements if a['claimed'])
    
    ach_text = f"""
🏆 <b>ACHIEVEMENTS</b>

Unlocked: {len(unlocked_ids)}/{len(ACHIEVEMENTS)}
Total Rewards: {total_rewards:,} tokens

"""
    
    keyboard = []
    count = 0
    for ach_id, ach_data in list(ACHIEVEMENTS.items())[:15]:
        is_unlocked = ach_id in unlocked_ids
        status = "✅" if is_unlocked else "🔒"
        
        ach_text += f"{status} {ach_data['icon']} <b>{ach_data['name']}</b>\n"
        ach_text += f"   {ach_data['description']}\n"
        ach_text += f"   Reward: {ach_data['reward']} tokens\n\n"
        count += 1
    
    if count < len(ACHIEVEMENTS):
        ach_text += f"\n... and {len(ACHIEVEMENTS) - count} more achievements!"
    
    keyboard.append([InlineKeyboardButton("🏠 Home", callback_data="home")])
    
    await update.message.reply_text(
        ach_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ========================
# 🎁 DAILY BONUS
# ========================

async def daily_bonus_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle daily bonus claim"""
    user_data = await get_or_create_user(update)
    
    last_claim = user_data['last_daily_claim']
    if last_claim:
        last_claim_date = datetime.fromisoformat(last_claim).date()
        today = datetime.now().date()
        
        if last_claim_date == today:
            next_claim = datetime.combine(today + timedelta(days=1), datetime.min.time())
            hours_left = int((next_claim - datetime.now()).total_seconds() / 3600)
            
            await update.message.reply_text(
                f"⏰ <b>Already Claimed!</b>\n\n"
                f"Come back in {hours_left} hours.\n"
                f"Streak: {user_data['daily_streak']} days 🔥",
                parse_mode=ParseMode.HTML,
                reply_markup=get_main_keyboard()
            )
            return
        
        yesterday = today - timedelta(days=1)
        if last_claim_date == yesterday:
            new_streak = user_data['daily_streak'] + 1
        else:
            new_streak = 1
    else:
        new_streak = 1
    
    base_bonus = DAILY_LOGIN_BONUS
    streak_multiplier = 1.0
    
    for days, multiplier in sorted(DAILY_STREAK_MULTIPLIER.items(), reverse=True):
        if new_streak >= days:
            streak_multiplier = multiplier
            break
    
    total_bonus = int(base_bonus * streak_multiplier)
    
    db.update_user_tokens(
        user_data['user_id'],
        total_bonus,
        'daily_bonus',
        f'Daily bonus (Streak: {new_streak})'
    )
    
    conn = db.get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE users 
        SET daily_streak = ?,
            last_daily_claim = CURRENT_TIMESTAMP
        WHERE user_id = ?
    """, (new_streak, user_data['user_id']))
    conn.commit()
    conn.close()
    
    bonus_text = f"""
🎁 <b>DAILY BONUS CLAIMED!</b>

💰 <b>Bonus:</b> {total_bonus:,} tokens
🔥 <b>Streak:</b> {new_streak} days

"""
    
    if streak_multiplier > 1.0:
        bonus_text += f"🌟 <b>Multiplier:</b> {streak_multiplier}x!\n\n"
    
    bonus_text += f"💼 <b>New Balance:</b> {db.get_user(user_data['user_id'])['tokens']:,} tokens"
    
    keyboard = [
        [InlineKeyboardButton("🏠 Home", callback_data="home")]
    ]
    
    await update.message.reply_text(
        bonus_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ========================
# 📈 LEADERBOARD
# ========================

async def leaderboard_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show leaderboard"""
    user_data = await get_or_create_user(update)
    
    leaderboard_text = "📈 <b>TOP EARNERS</b>\n\n"
    
    leaders = db.get_leaderboard(limit=LEADERBOARD_TOP_N, metric='total_earned')
    
    medals = ["🥇", "🥈", "🥉"]
    for i, leader in enumerate(leaders):
        medal = medals[i] if i < 3 else f"{i+1}."
        level_data = LEVELS.get(leader['level'], LEVELS[1])
        
        name = leader['first_name']
        if leader['username']:
            name = f"@{leader['username']}"
        
        leaderboard_text += f"{medal} <b>{name}</b>\n"
        leaderboard_text += f"   💰 {leader['total_earned']:,} tokens | {level_data['name']}\n\n"
    
    keyboard = [
        [InlineKeyboardButton("🏠 Home", callback_data="home")]
    ]
    
    await update.message.reply_text(
        leaderboard_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ========================
# 🏪 SHOP
# ========================

async def shop_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show shop items"""
    user_data = await get_or_create_user(update)
    
    shop_text = f"""
🏪 <b>TOKEN SHOP</b>

💼 <b>Balance:</b> {user_data['tokens']:,} tokens

🛍️ <b>Items:</b>

"""
    
    keyboard = []
    for item_id, item_data in SHOP_ITEMS.items():
        shop_text += f"{item_data['name']}\n"
        shop_text += f"{item_data['description']}\n"
        shop_text += f"Cost: {item_data['cost']:,} tokens\n\n"
        
        keyboard.append([
            InlineKeyboardButton(
                f"Buy {item_data['name']} - {item_data['cost']:,}",
                callback_data=f"buy_{item_id}"
            )
        ])
    
    keyboard.append([InlineKeyboardButton("🏠 Home", callback_data="home")])
    
    await update.message.reply_text(
        shop_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ========================
# ℹ️ HELP
# ========================

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show help information"""
    user_data = await get_or_create_user(update)
    
    help_text = f"""
ℹ️ <b>BOT HELP & GUIDE</b>

👤 <b>Your User ID:</b> <code>{user_data['user_id']}</code>

<b>How to Earn:</b>
1. Join campaigns in 🚀 Earn
2. Verify your join
3. Get tokens!

<b>Create Campaigns:</b>
1. Use ➕ Create Campaign
2. Choose campaign type
3. Set members count
4. Pay with tokens

<b>Deposit Tokens:</b>
1. Click 💳 Deposit
2. Choose amount
3. Select payment method
4. Send screenshot
5. Admin approves

<b>Withdraw Tokens:</b>
1. Click 💸 Withdraw
2. Enter amount
3. Choose method
4. Enter details
5. Tokens sent in 24-48h

<b>Commands:</b>
/start - Main menu
/help - This help
/admin - Admin panel (admin only)

📞 <b>Contact Admin:</b>
@holabrooo
"""
    
    keyboard = [
        [InlineKeyboardButton("🏠 Home", callback_data="home")]
    ]
    
    await update.message.reply_text(help_text, parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup(keyboard))

# ========================
# 📞 CALLBACK HANDLERS
# ========================

async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle all callback queries"""
    query = update.callback_query
    data = query.data
    user_data = await get_or_create_user(update)
    
    try:
        if data == "home":
            await query.message.delete()
            await start_command(update, context)
        
        elif data == "deposit_menu":
            await query.message.delete()
            await deposit_start(update, context)
        
        elif data.startswith("deposit_"):
            await handle_deposit_callback(update, context)
        
        elif data.startswith("deposit_method_"):
            await handle_deposit_method(update, context)
        
        elif data == "withdraw_menu":
            await query.message.delete()
            await withdraw_start(update, context)
        
        elif data.startswith("withdraw_"):
            await handle_withdraw_callback(update, context)
        
        elif data.startswith("withdraw_method_"):
            await handle_withdraw_method(update, context)
        
        else:
            await query.answer("Feature loading...")
    
    except Exception as e:
        logger.error(f"Callback error: {e}")
        await query.answer("An error occurred!")

# ========================
# 🚀 MAIN APPLICATION
# ========================

def main():
    """Start the bot"""
    print("""
╔════════════════════════════════════════════════════════════╗
║   🤖 PREMIUM EXCHANGE BOT PRO v4.1.0                      ║
║   WITH ADMIN PANEL, DEPOSITS & USER IDs                   ║
║   Starting...                                              ║
╚════════════════════════════════════════════════════════════╝
    """)
    
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Command handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("admin", admin_panel))
    
    # Message handlers
    application.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND,
        lambda u, c: (handle_deposit_screenshot(u, c) if c.user_data.get('awaiting') == 'deposit_screenshot' 
                      else handle_withdraw_details(u, c) if c.user_data.get('awaiting') == 'withdraw_details'
                      else menu_handler(u, c))
    ))
    
    # Photo handler for screenshots
    application.add_handler(MessageHandler(filters.PHOTO, handle_deposit_screenshot))
    
    # Callback handler
    application.add_handler(CallbackQueryHandler(callback_handler))
    
    logger.info("🚀 Bot started successfully!")
    print("✅ Bot is running! Press Ctrl+C to stop.")
    
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
