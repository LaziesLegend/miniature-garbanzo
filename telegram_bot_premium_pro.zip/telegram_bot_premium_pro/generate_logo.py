"""
Logo Generator for Premium Telegram Bot
Creates professional bot logo
"""

from PIL import Image, ImageDraw, ImageFont
import os

def create_bot_logo():
    """Create a professional bot logo"""
    # Create image with gradient background
    width, height = 512, 512
    img = Image.new('RGB', (width, height), color='white')
    draw = ImageDraw.Draw(img)
    
    # Create gradient background (purple to blue)
    for y in range(height):
        r = int(88 + (66 - 88) * y / height)
        g = int(101 + (135 - 101) * y / height)
        b = int(242 + (245 - 242) * y / height)
        draw.rectangle([(0, y), (width, y+1)], fill=(r, g, b))
    
    # Draw circular background
    circle_center = (width // 2, height // 2)
    circle_radius = 180
    draw.ellipse(
        [(circle_center[0] - circle_radius, circle_center[1] - circle_radius),
         (circle_center[0] + circle_radius, circle_center[1] + circle_radius)],
        fill=(255, 255, 255, 230),
        outline=(66, 135, 245),
        width=8
    )
    
    # Draw robot icon (simplified)
    # Head
    head_rect = [190, 160, 322, 280]
    draw.rounded_rectangle(head_rect, radius=20, fill=(66, 135, 245))
    
    # Eyes
    draw.ellipse([215, 195, 245, 225], fill=(255, 255, 255))
    draw.ellipse([267, 195, 297, 225], fill=(255, 255, 255))
    draw.ellipse([223, 203, 237, 217], fill=(88, 101, 242))
    draw.ellipse([275, 203, 289, 217], fill=(88, 101, 242))
    
    # Antenna
    draw.line([(256, 160), (256, 130)], fill=(66, 135, 245), width=6)
    draw.ellipse([246, 120, 266, 140], fill=(255, 215, 0))
    
    # Mouth
    draw.arc([225, 235, 287, 265], 0, 180, fill=(255, 255, 255), width=4)
    
    # Body
    body_rect = [200, 280, 312, 380]
    draw.rounded_rectangle(body_rect, radius=15, fill=(66, 135, 245))
    
    # Arms
    draw.rounded_rectangle([170, 290, 200, 340], radius=8, fill=(88, 101, 242))
    draw.rounded_rectangle([312, 290, 342, 340], radius=8, fill=(88, 101, 242))
    
    # Coins/tokens decoration
    for i, pos in enumerate([(130, 350), (370, 180), (140, 200), (360, 380)]):
        size = 30
        draw.ellipse([pos[0], pos[1], pos[0]+size, pos[1]+size], 
                    fill=(255, 215, 0), outline=(218, 165, 32), width=3)
        draw.text((pos[0]+8, pos[1]+5), "💰", fill=(255, 255, 255))
    
    # Save logo
    img.save('bot_logo.png', 'PNG', quality=95)
    print("✅ Logo created: bot_logo.png")
    
    # Create smaller icon version
    icon = img.resize((128, 128), Image.Resampling.LANCZOS)
    icon.save('bot_icon.png', 'PNG', quality=95)
    print("✅ Icon created: bot_icon.png")

if __name__ == "__main__":
    create_bot_logo()
