"""
🚀 TELEGRAM PREMIUM EXCHANGE BOT PRO - PRODUCTION CONFIGURATION
Advanced Feature-Rich Configuration with PR Gram Features
Version: 4.0.0 ULTRA
"""

import os
from typing import Final
from datetime import datetime

# ========================
# 🤖 BOT CONFIGURATION
# ========================
BOT_TOKEN: Final = "8438773973:AAHzZUXMjUw6whaZI9pG7wr3IWGj30xiFww"
ADMIN_IDS: Final = [8301300209]  # Your admin ID
BOT_USERNAME: Final = "@YourBotUsername"  # Will be auto-fetched

# ========================
# 💰 ADVANCED TOKEN ECONOMY
# ========================
JOIN_REWARD: Final = 90  # Tokens user earns per join
ADVERTISER_COST: Final = 115  # Tokens advertiser pays per member
PLATFORM_FEE: Final = ADVERTISER_COST - JOIN_REWARD  # Auto-calculated: 25 tokens

MIN_CAMPAIGN_MEMBERS: Final = 5
MAX_CAMPAIGN_MEMBERS: Final = 50000
DEFAULT_CAMPAIGN_PRIORITY: Final = 0

# ========================
# 👥 MULTI-LEVEL REFERRAL SYSTEM
# ========================
REFERRAL_BONUS_L1: Final = 20  # Level 1 referral bonus
REFERRAL_BONUS_L2: Final = 8   # Level 2 referral bonus  
REFERRAL_BONUS_L3: Final = 3   # Level 3 referral bonus
SIGNUP_BONUS: Final = 150      # Welcome bonus for new users
REFERRAL_TASK_BONUS: Final = 10 # Bonus when referral completes first task

# ========================
# 🎁 DAILY REWARDS & STREAKS
# ========================
DAILY_LOGIN_BONUS: Final = 15
DAILY_STREAK_MULTIPLIER: Final = {
    3: 1.2,   # 3-day streak: 1.2x bonus
    7: 1.5,   # 7-day streak: 1.5x bonus
    14: 2.0,  # 14-day streak: 2x bonus
    30: 3.0,  # 30-day streak: 3x bonus
    60: 4.0,  # 60-day streak: 4x bonus
    90: 5.0   # 90-day streak: 5x bonus
}

# ========================
# 💳 MULTI-METHOD DEPOSIT SYSTEM
# ========================
DEPOSIT_METHODS = {
    "UPI": {
        "enabled": True,
        "bonus_percent": 5,
        "payment_info": "UPI ID: merchant@upi",
        "min_amount": 100,
        "icon": "📱"
    },
    "CRYPTO": {
        "enabled": True,
        "bonus_percent": 12,
        "wallets": {
            "BTC": "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh",
            "ETH": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb",
            "USDT_TRC20": "TRC20_Address_Here",
            "USDT_ERC20": "ERC20_Address_Here"
        },
        "min_amount": 500,
        "icon": "₿"
    },
    "PAYPAL": {
        "enabled": True,
        "bonus_percent": 3,
        "email": "merchant@paypal.com",
        "min_amount": 200,
        "icon": "💳"
    },
    "PAYTM": {
        "enabled": True,
        "bonus_percent": 5,
        "phone": "+91XXXXXXXXXX",
        "min_amount": 100,
        "icon": "📲"
    }
}

DEPOSIT_TIERS = {
    "BRONZE": {"min": 1000, "bonus_percent": 5, "badge": "🥉"},
    "SILVER": {"min": 5000, "bonus_percent": 10, "badge": "🥈"},
    "GOLD": {"min": 15000, "bonus_percent": 15, "badge": "🥇"},
    "PLATINUM": {"min": 50000, "bonus_percent": 25, "badge": "💎"},
    "DIAMOND": {"min": 100000, "bonus_percent": 35, "badge": "👑"}
}

# ========================
# 🎮 ADVANCED LEVEL SYSTEM
# ========================
LEVELS = {
    1: {"joins": 0, "name": "🆕 Newbie", "reward_multiplier": 1.0, "max_campaigns": 3, "priority_boost": 0},
    2: {"joins": 30, "name": "🥉 Bronze", "reward_multiplier": 1.05, "max_campaigns": 5, "priority_boost": 1},
    3: {"joins": 100, "name": "🥈 Silver", "reward_multiplier": 1.10, "max_campaigns": 10, "priority_boost": 2},
    4: {"joins": 250, "name": "🥇 Gold", "reward_multiplier": 1.15, "max_campaigns": 20, "priority_boost": 3},
    5: {"joins": 500, "name": "💎 Platinum", "reward_multiplier": 1.22, "max_campaigns": 50, "priority_boost": 5},
    6: {"joins": 1000, "name": "👑 Diamond", "reward_multiplier": 1.28, "max_campaigns": 100, "priority_boost": 8},
    7: {"joins": 2500, "name": "🌟 Master", "reward_multiplier": 1.35, "max_campaigns": 200, "priority_boost": 12},
    8: {"joins": 5000, "name": "🔥 Legend", "reward_multiplier": 1.45, "max_campaigns": 500, "priority_boost": 20},
    9: {"joins": 10000, "name": "⚡ Elite", "reward_multiplier": 1.55, "max_campaigns": 1000, "priority_boost": 30},
    10: {"joins": 25000, "name": "👾 Ultimate", "reward_multiplier": 2.0, "max_campaigns": 9999, "priority_boost": 50}
}

# ========================
# 🛡️ ADVANCED ANTI-CHEAT SYSTEM
# ========================
INITIAL_TRUST_SCORE: Final = 100
MIN_TRUST_SCORE: Final = 10
MAX_TRUST_SCORE: Final = 200

TRUST_PENALTIES = {
    "fake_join": -20,
    "leave_after_join": -10,
    "spam_report": -25,
    "multiple_violations": -30,
    "bot_behavior": -60,
    "task_skip": -5
}

TRUST_REWARDS = {
    "successful_join": 2,
    "campaign_complete": 6,
    "perfect_week": 8,
    "perfect_month": 15,
    "top_contributor": 20,
    "helpful_member": 10
}

# Rate limiting
MAX_DAILY_JOINS: Final = 150
MAX_HOURLY_JOINS: Final = 25
JOIN_COOLDOWN_SECONDS: Final = 25
VERIFY_TIMEOUT_SECONDS: Final = 300
MAX_VERIFICATION_ATTEMPTS: Final = 3

# ========================
# 💸 WITHDRAWAL SYSTEM
# ========================
WITHDRAWAL_ENABLED: Final = True
MIN_WITHDRAWAL: Final = 1000
MAX_WITHDRAWAL: Final = 100000
WITHDRAWAL_FEE_PERCENT: Final = 5
VIP_WITHDRAWAL_FEE: Final = 2
DAILY_WITHDRAWAL_LIMIT: Final = 500000
WITHDRAWAL_METHODS = ["UPI", "PAYPAL", "CRYPTO", "PAYTM", "BANK_TRANSFER"]
WITHDRAWAL_PROCESSING_TIME: Final = "12-24 hours"

# ========================
# 🏆 COMPREHENSIVE ACHIEVEMENT SYSTEM
# ========================
ACHIEVEMENTS = {
    "first_join": {"name": "First Steps", "description": "Complete your first join", "reward": 50, "icon": "🎯"},
    "join_10": {"name": "Getting Started", "description": "Complete 10 joins", "reward": 100, "icon": "🚀"},
    "join_50": {"name": "Active Member", "description": "Complete 50 joins", "reward": 300, "icon": "⭐"},
    "join_100": {"name": "Dedicated Worker", "description": "Complete 100 joins", "reward": 600, "icon": "💪"},
    "join_500": {"name": "Power User", "description": "Complete 500 joins", "reward": 2000, "icon": "🔥"},
    "join_1000": {"name": "Elite Member", "description": "Complete 1000 joins", "reward": 5000, "icon": "👑"},
    
    "referral_1": {"name": "Recruiter", "description": "Refer 1 user", "reward": 80, "icon": "👥"},
    "referral_5": {"name": "Influencer", "description": "Refer 5 users", "reward": 250, "icon": "📣"},
    "referral_10": {"name": "Referral Master", "description": "Refer 10 users", "reward": 600, "icon": "🌟"},
    "referral_50": {"name": "Network Leader", "description": "Refer 50 users", "reward": 3000, "icon": "👑"},
    
    "campaign_1": {"name": "Advertiser", "description": "Create your first campaign", "reward": 100, "icon": "📢"},
    "campaign_10": {"name": "Pro Advertiser", "description": "Create 10 campaigns", "reward": 500, "icon": "🎯"},
    
    "streak_7": {"name": "Weekly Champion", "description": "7-day login streak", "reward": 200, "icon": "📅"},
    "streak_30": {"name": "Loyal Member", "description": "30-day login streak", "reward": 1000, "icon": "💎"},
    "streak_90": {"name": "Dedicated Soul", "description": "90-day login streak", "reward": 5000, "icon": "🏆"},
    
    "earn_5k": {"name": "Token Collector", "description": "Earn 5,000 tokens", "reward": 500, "icon": "💰"},
    "earn_10k": {"name": "Top Earner", "description": "Earn 10,000 tokens", "reward": 2000, "icon": "🌟"},
    "earn_50k": {"name": "Wealth Builder", "description": "Earn 50,000 tokens", "reward": 8000, "icon": "💎"},
    
    "trust_150": {"name": "Trusted Member", "description": "Reach 150 trust score", "reward": 1000, "icon": "🛡️"},
    "level_5": {"name": "Platinum Achiever", "description": "Reach Level 5", "reward": 1500, "icon": "⭐"},
    "level_10": {"name": "Ultimate Master", "description": "Reach Level 10", "reward": 10000, "icon": "👾"}
}

# ========================
# 🎁 TIME-BASED BONUS EVENTS
# ========================
HAPPY_HOURS = {
    "enabled": True,
    "hours": [10, 14, 18, 22],  # 10 AM, 2 PM, 6 PM, 10 PM
    "multiplier": 1.6,
    "duration_minutes": 60
}

WEEKEND_BONUS = {
    "enabled": True,
    "multiplier": 1.3
}

SPECIAL_DAYS = {
    "new_year": {"multiplier": 2.0, "date": "01-01"},
    "christmas": {"multiplier": 1.8, "date": "12-25"},
    "independence": {"multiplier": 1.5, "date": "08-15"}
}

# ========================
# 🎮 DAILY TASKS SYSTEM
# ========================
DAILY_TASKS = {
    "join_3": {"target": 3, "reward": 80, "description": "Join 3 campaigns", "icon": "🎯"},
    "join_5": {"target": 5, "reward": 150, "description": "Join 5 campaigns", "icon": "🚀"},
    "join_10": {"target": 10, "reward": 350, "description": "Join 10 campaigns", "icon": "⭐"},
    "refer_1": {"target": 1, "reward": 200, "description": "Refer 1 friend", "icon": "👥"},
    "create_campaign": {"target": 1, "reward": 250, "description": "Create a campaign", "icon": "📢"},
    "claim_daily": {"target": 1, "reward": 50, "description": "Claim daily reward", "icon": "🎁"}
}

# ========================
# 🏪 TOKEN SHOP
# ========================
SHOP_ITEMS = {
    "priority_boost_24h": {
        "name": "⚡ Priority Boost (24h)",
        "description": "Get tasks first for 24 hours",
        "cost": 500,
        "duration_hours": 24
    },
    "priority_boost_7d": {
        "name": "⚡ Priority Boost (7 days)",
        "description": "Get tasks first for 7 days",
        "cost": 2500,
        "duration_hours": 168
    },
    "trust_restore_20": {
        "name": "🛡️ Trust Restore +20",
        "description": "Restore 20 trust points",
        "cost": 800
    },
    "trust_restore_50": {
        "name": "🛡️ Trust Restore +50",
        "description": "Restore 50 trust points",
        "cost": 1800
    },
    "vip_7d": {
        "name": "👑 VIP Status (7 days)",
        "description": "Lower fees + priority + badge",
        "cost": 2000,
        "duration_days": 7
    },
    "vip_30d": {
        "name": "👑 VIP Status (30 days)",
        "description": "Lower fees + priority + badge",
        "cost": 6500,
        "duration_days": 30
    },
    "lucky_spin": {
        "name": "🎰 Lucky Spin",
        "description": "Win 100-10000 tokens",
        "cost": 150
    },
    "mega_spin": {
        "name": "🎰 Mega Spin",
        "description": "Win 500-50000 tokens",
        "cost": 1000
    },
    "double_rewards_24h": {
        "name": "💎 2x Rewards (24h)",
        "description": "Double all rewards for 24 hours",
        "cost": 3000,
        "duration_hours": 24
    }
}

# ========================
# 📊 LEADERBOARD & ANALYTICS
# ========================
LEADERBOARD_TOP_N: Final = 50
LEADERBOARD_CATEGORIES = ["earnings", "joins", "referrals", "campaigns", "trust_score"]
LEADERBOARD_REWARDS = {
    1: 5000,   # 1st place
    2: 3000,   # 2nd place
    3: 2000,   # 3rd place
    4: 1000,   # 4th-5th
    5: 1000,
    10: 500    # 6th-10th
}

# ========================
# 🎨 ENHANCED UI/UX
# ========================
ITEMS_PER_PAGE: Final = 6
ANIMATION_ENABLED: Final = True
EMOJI_ENABLED: Final = True

LOADING_MESSAGES = [
    "⚡ Processing your request...",
    "🚀 Loading data...",
    "💫 Please wait...",
    "🔄 Working on it...",
    "✨ Almost there...",
    "🎯 Preparing results..."
]

# ========================
# 🔔 ADVANCED NOTIFICATIONS
# ========================
NOTIFICATIONS = {
    "campaign_complete": True,
    "campaign_low_balance": True,
    "new_referral": True,
    "referral_milestone": True,
    "level_up": True,
    "achievement_unlock": True,
    "deposit_approved": True,
    "withdrawal_processed": True,
    "daily_reward_ready": True,
    "happy_hour_start": True,
    "trust_score_warning": True,
    "task_available": True
}

# ========================
# 🎯 CAMPAIGN TYPES
# ========================
CAMPAIGN_TYPES = {
    "standard": {
        "name": "📊 Standard Campaign",
        "cost_multiplier": 1.0,
        "priority": 0,
        "features": ["Normal delivery", "Standard support"]
    },
    "premium": {
        "name": "⭐ Premium Campaign",
        "cost_multiplier": 1.3,
        "priority": 10,
        "features": ["Verified members", "Faster delivery", "Priority support"]
    },
    "urgent": {
        "name": "🚀 Urgent Campaign",
        "cost_multiplier": 1.6,
        "priority": 25,
        "features": ["Top priority", "24h guarantee", "VIP support", "Quality members"]
    },
    "exclusive": {
        "name": "👑 Exclusive Campaign",
        "cost_multiplier": 2.0,
        "priority": 50,
        "features": ["Elite members only", "Instant delivery", "Premium support", "Retention guarantee"]
    }
}

# ========================
# 💬 ENHANCED MESSAGES
# ========================
WELCOME_MESSAGE = """
🎉 <b>Welcome to Premium Member Exchange Bot PRO!</b>

💰 <b>Earn Tokens Multiple Ways:</b>
• Join campaigns: {join_reward} tokens per join
• Refer friends: Up to {referral_bonus} tokens
• Daily login: {daily_bonus} tokens + streak bonuses
• Complete achievements: Up to 10,000 tokens
• Daily tasks: Extra bonuses
• Lucky spins: Win big rewards!

🚀 <b>Create Campaigns:</b>
• Promote your Telegram channels/groups
• Only {advertiser_cost} tokens per member
• 4 campaign types available
• Fast & reliable delivery
• Advanced analytics dashboard

🎁 <b>Your Welcome Package:</b>
✨ {signup_bonus} tokens bonus
💎 Level 1: Newbie
⭐ Trust Score: 100/100
🏆 VIP access ready to unlock

📈 <b>Pro Features:</b>
• Multi-level referral system
• Daily & weekly leaderboards
• Achievement system
• Token shop with power-ups
• Withdrawal system (Active)

👇 <b>Get Started:</b>
"""

LEVEL_UP_MESSAGE = """
🎊 <b>CONGRATULATIONS!</b> 🎊

You've leveled up to:
{level_icon} <b>{level_name}</b>

🎁 <b>Your New Benefits:</b>
✨ Reward Multiplier: <b>{multiplier}x</b>
📊 Max Campaigns: <b>{max_campaigns}</b>
⚡ Priority Boost: <b>+{priority}</b>
💰 Level-up Bonus: <b>{bonus} tokens</b>

Keep grinding to unlock even better rewards!
Next level at: <b>{next_level_joins} joins</b>
"""

ACHIEVEMENT_UNLOCKED = """
🏆 <b>ACHIEVEMENT UNLOCKED!</b> 🏆

{icon} <b>{name}</b>
{description}

💰 <b>Reward:</b> +{reward} tokens
📊 <b>Progress:</b> {completed}/{total} achievements

Keep going to unlock more rewards!
"""

# ========================
# 🗄️ DATABASE
# ========================
DATABASE_NAME: Final = "bot_premium_pro.db"
BACKUP_ENABLED: Final = True
BACKUP_INTERVAL_HOURS: Final = 6

# ========================
# 🔒 SECURITY
# ========================
REQUIRE_CHANNEL_VERIFICATION: Final = True
ANTI_SPAM_ENABLED: Final = True
MAX_REQUESTS_PER_MINUTE: Final = 40
BAN_DURATION_HOURS: Final = 48
AUTO_BAN_THRESHOLD: Final = 3

# ========================
# 🌍 FEATURES FLAGS
# ========================
FEATURES = {
    "wallet": True,
    "campaigns": True,
    "referrals": True,
    "deposits": True,
    "withdrawals": True,
    "achievements": True,
    "daily_rewards": True,
    "daily_tasks": True,
    "leaderboard": True,
    "shop": True,
    "statistics": True,
    "admin_panel": True,
    "multi_language": False,  # Future
    "social_features": True
}

# ========================
# 🎨 BRANDING
# ========================
BOT_NAME: Final = "Premium Exchange Bot PRO"
BOT_DESCRIPTION: Final = "Professional Telegram Member Exchange Platform with Advanced Features"
SUPPORT_USERNAME: Final = "@YourSupportBot"
WEBSITE_URL: Final = "https://yourwebsite.com"

# Version
VERSION: Final = "4.0.0"
RELEASE_DATE: Final = "2025-02-08"

print(f"""
╔════════════════════════════════════════════════╗
║   🤖 PREMIUM EXCHANGE BOT PRO                 ║
║   Version: {VERSION}                            ║
║   Release: {RELEASE_DATE}                      ║
║   Status: ✅ PRODUCTION READY                 ║
╚════════════════════════════════════════════════╝
""")
