"""
🤖 TELEGRAM PREMIUM EXCHANGE BOT PRO v4.4.0
WITH COMPLETE ADMIN PANEL & TOKEN MANAGEMENT
"""

import logging
import asyncio
from datetime import datetime, timedelta

try:
    from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
    from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes, ConversationHandler
    from telegram.constants import ParseMode
except ImportError:
    import subprocess, sys
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "python-telegram-bot==21.0"])
    from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
    from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes, ConversationHandler
    from telegram.constants import ParseMode

from database import Database
from config import *

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

db = Database(DATABASE_NAME)

# States
WAITING_DEPOSIT_AMOUNT = 1
WAITING_SCREENSHOT = 2
WAITING_USER_ID_FOR_TOKENS = 3
WAITING_TOKEN_AMOUNT = 4
WAITING_REASON = 5

def is_admin(user_id: int) -> bool:
    """Check if admin"""
    return user_id in ADMIN_IDS

def get_main_keyboard():
    """Main menu"""
    keyboard = [
        [KeyboardButton("💼 Wallet"), KeyboardButton("🚀 Earn")],
        [KeyboardButton("📊 Campaigns"), KeyboardButton("👥 Refer")],
        [KeyboardButton("🏆 Achievements"), KeyboardButton("💳 Deposit")],
        [KeyboardButton("🏪 Shop"), KeyboardButton("ℹ️ Help")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def get_admin_keyboard():
    """Admin menu"""
    keyboard = [
        [KeyboardButton("👥 All Users"), KeyboardButton("💰 Add Tokens")],
        [KeyboardButton("💳 Pending Deposits"), KeyboardButton("💸 Pending Withdrawals")],
        [KeyboardButton("🔧 Settings"), KeyboardButton("📊 Stats")],
        [KeyboardButton("🚫 Ban User"), KeyboardButton("🏠 Back")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

async def get_or_create_user(update: Update) -> dict:
    """Get or create user"""
    user = update.effective_user
    existing = db.get_user(user.id)
    if existing:
        return existing
    
    db.create_user(user.id, user.username or "Unknown", user.first_name or "User", user.last_name, signup_bonus=SIGNUP_BONUS)
    return db.get_user(user.id)

# ========================
# START & MAIN COMMANDS
# ========================

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start command"""
    user = await get_or_create_user(update)
    
    # Check if admin
    if is_admin(user['user_id']):
        msg = f"""
👑 <b>ADMIN PANEL</b>

🆔 Admin ID: <code>{user['user_id']}</code>

Welcome Admin! Choose an option:
"""
        await update.message.reply_text(msg, parse_mode=ParseMode.HTML, reply_markup=get_admin_keyboard())
        return
    
    # Regular user
    msg = f"""
🎉 <b>Welcome!</b>

🆔 Your ID: <code>{user['user_id']}</code>
💰 Balance: {user['tokens']:,} tokens
💎 Level: {LEVELS[user['level']]['name']}
⭐ Trust: {user['trust_score']}/200

👇 Choose an option:
"""
    
    try:
        with open('bot_logo.png', 'rb') as logo:
            await update.message.reply_photo(photo=logo, caption=msg, parse_mode=ParseMode.HTML, reply_markup=get_main_keyboard())
    except:
        await update.message.reply_text(msg, parse_mode=ParseMode.HTML, reply_markup=get_main_keyboard())

# ========================
# ADMIN PANEL FUNCTIONS
# ========================

async def admin_add_tokens(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Admin add tokens to user"""
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("❌ Admin only!", reply_markup=get_main_keyboard())
        return
    
    msg = """
💰 <b>ADD TOKENS TO USER</b>

Enter the User ID to add tokens:
(You can find user ID from their profile or deposit info)

Example: 123456789
"""
    
    await update.message.reply_text(msg, parse_mode=ParseMode.HTML)
    return WAITING_USER_ID_FOR_TOKENS

async def admin_handle_user_id(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle user ID input"""
    try:
        user_id = int(update.message.text)
        user = db.get_user(user_id)
        
        if not user:
            await update.message.reply_text("❌ User not found!")
            return WAITING_USER_ID_FOR_TOKENS
        
        context.user_data['target_user_id'] = user_id
        
        msg = f"""
👤 <b>USER FOUND</b>

Name: {user['first_name']}
Username: @{user['username']}
🆔 ID: <code>{user['user_id']}</code>
💰 Current Balance: {user['tokens']:,} tokens

Now enter the amount of tokens to ADD:
"""
        
        await update.message.reply_text(msg, parse_mode=ParseMode.HTML)
        return WAITING_TOKEN_AMOUNT
        
    except ValueError:
        await update.message.reply_text("❌ Please enter a valid user ID (numbers only)!", reply_markup=get_admin_keyboard())
        return WAITING_USER_ID_FOR_TOKENS

async def admin_handle_token_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle token amount input"""
    try:
        amount = int(update.message.text)
        
        if amount <= 0:
            await update.message.reply_text("❌ Amount must be positive!")
            return WAITING_TOKEN_AMOUNT
        
        context.user_data['token_amount'] = amount
        
        msg = f"""
📝 <b>ADD REASON (Optional)</b>

Enter the reason for adding {amount:,} tokens:

Examples:
• Deposit approved
• Promotion bonus
• Referral reward
• Manual correction
• Support compensation

Or type: skip
"""
        
        await update.message.reply_text(msg, parse_mode=ParseMode.HTML)
        return WAITING_REASON
        
    except ValueError:
        await update.message.reply_text("❌ Please enter a valid number!")
        return WAITING_TOKEN_AMOUNT

async def admin_handle_reason(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle reason and add tokens"""
    reason = update.message.text if update.message.text.lower() != "skip" else "Admin added tokens"
    
    user_id = context.user_data.get('target_user_id')
    amount = context.user_data.get('token_amount')
    admin_id = update.effective_user.id
    
    # Add tokens
    db.update_user_tokens(user_id, amount, 'admin_add', f'Admin {admin_id} added: {reason}')
    
    user = db.get_user(user_id)
    
    # Send notification to user
    try:
        await context.bot.send_message(
            chat_id=user_id,
            text=f"""
✅ <b>TOKENS ADDED!</b>

💰 Amount: +{amount:,} tokens
📝 Reason: {reason}
💵 New Balance: {user['tokens']:,} tokens

Thank you! 🎉
""",
            parse_mode=ParseMode.HTML
        )
    except:
        pass
    
    # Confirm to admin
    msg = f"""
✅ <b>TOKENS ADDED!</b>

👤 User: {user['first_name']} (@{user['username']})
🆔 ID: <code>{user_id}</code>
💰 Amount Added: {amount:,} tokens
📝 Reason: {reason}
💵 New Balance: {user['tokens']:,} tokens

Done!
"""
    
    await update.message.reply_text(msg, parse_mode=ParseMode.HTML, reply_markup=get_admin_keyboard())
    context.user_data.clear()
    return ConversationHandler.END

async def admin_pending_deposits(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show pending deposits"""
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("❌ Admin only!")
        return
    
    msg = """
💳 <b>PENDING DEPOSITS</b>

To view pending deposits:
1. Check your Telegram messages from @holabrooo
2. Screenshots are sent automatically
3. Each deposit shows:
   • User name & ID
   • Amount
   • Payment method
   • Screenshot

👉 To add tokens to user:
   Click "💰 Add Tokens" button
"""
    
    await update.message.reply_text(msg, parse_mode=ParseMode.HTML, reply_markup=get_admin_keyboard())

async def admin_pending_withdrawals(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show pending withdrawals"""
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("❌ Admin only!")
        return
    
    msg = """
💸 <b>PENDING WITHDRAWALS</b>

To view pending withdrawals:
1. Check your Telegram messages
2. Each request shows:
   • User name & ID
   • Amount
   • Withdrawal method
   • User details

👉 To process withdrawal:
   Add the amount to your wallet manually
   Then notify the user
"""
    
    await update.message.reply_text(msg, parse_mode=ParseMode.HTML, reply_markup=get_admin_keyboard())

async def admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show stats"""
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("❌ Admin only!")
        return
    
    stats = db.get_system_stats()
    
    msg = f"""
📊 <b>SYSTEM STATISTICS</b>

👥 Total Users: {stats.get('total_users', 0):,}
🟢 Active (24h): {stats.get('active_users_24h', 0):,}

📢 Total Campaigns: {stats.get('total_campaigns', 0):,}
🔄 Active Campaigns: {stats.get('active_campaigns', 0):,}

💰 Tokens in Circulation: {stats.get('tokens_in_circulation', 0):,}
💎 Platform Profit: {stats.get('platform_profit', 0):,}

⏰ Updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
    
    await update.message.reply_text(msg, parse_mode=ParseMode.HTML, reply_markup=get_admin_keyboard())

async def admin_all_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show all users"""
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("❌ Admin only!")
        return
    
    msg = """
👥 <b>ALL USERS</b>

To view all users and manage them:

1. 💰 Add Tokens
   Click button to add tokens to any user

2. 🚫 Ban User
   Click button to ban a user

3. 📊 Stats
   View total users and activity

4. 💳 Pending Deposits
   View deposits waiting for approval

👉 Use the buttons below!
"""
    
    await update.message.reply_text(msg, parse_mode=ParseMode.HTML, reply_markup=get_admin_keyboard())

async def admin_ban_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ban user"""
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("❌ Admin only!")
        return
    
    msg = """
🚫 <b>BAN USER</b>

To ban a user:
1. Get their User ID
2. Update trust score to 0
3. They won't be able to use bot

⚠️ Feature coming soon!

For now, set their trust score to 0 manually.
"""
    
    await update.message.reply_text(msg, parse_mode=ParseMode.HTML, reply_markup=get_admin_keyboard())

async def admin_back(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Back to main"""
    await start(update, context)

# ========================
# USER MENU BUTTONS
# ========================

async def wallet(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Wallet button"""
    user = await get_or_create_user(update)
    level = LEVELS[user['level']]
    
    msg = f"""
💼 <b>YOUR WALLET</b>

🆔 ID: <code>{user['user_id']}</code>
💰 Balance: {user['tokens']:,} tokens
💎 Level: {level['name']}
⭐ Trust: {user['trust_score']}/200

📊 Stats:
Earned: {user['total_earned']:,}
Referrals: {user['total_referrals']}
Joins: {user['total_joins']}
"""
    
    await update.message.reply_text(msg, parse_mode=ParseMode.HTML, reply_markup=get_main_keyboard())

async def refer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Refer button"""
    user = await get_or_create_user(update)
    bot_name = (await context.bot.get_me()).username
    link = f"https://t.me/{bot_name}?start=REF{user['user_id']}"
    
    msg = f"""
👥 <b>REFERRAL PROGRAM</b>

🆔 Your ID: <code>{user['user_id']}</code>

🎁 Earn:
• L1: {REFERRAL_BONUS_L1} tokens
• L2: {REFERRAL_BONUS_L2} tokens  
• L3: {REFERRAL_BONUS_L3} tokens

📊 Referrals: {user['total_referrals']}

🔗 Link: <code>{link}</code>

Share & earn!
"""
    
    await update.message.reply_text(msg, parse_mode=ParseMode.HTML, reply_markup=get_main_keyboard())

async def achievements(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Achievements button"""
    msg = """
🏆 <b>ACHIEVEMENTS</b>

Coming soon!

Keep earning to unlock amazing rewards.
"""
    
    await update.message.reply_text(msg, parse_mode=ParseMode.HTML, reply_markup=get_main_keyboard())

async def shop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Shop button"""
    msg = """
🏪 <b>SHOP</b>

Coming soon!

Buy power-ups with your tokens.
"""
    
    await update.message.reply_text(msg, parse_mode=ParseMode.HTML, reply_markup=get_main_keyboard())

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Help button"""
    user = await get_or_create_user(update)
    
    msg = f"""
ℹ️ <b>HELP</b>

🆔 Your ID: <code>{user['user_id']}</code>

💳 <b>DEPOSIT:</b>
Click 💳 Deposit → Choose amount → Select crypto → Send payment → Send screenshot

⚠️ <b>WARNINGS:</b>
🔴 Send to CORRECT address ONLY!
🔴 NO REFUNDS on wrong address!
🔴 Wrong screenshot = 7 DAYS BAN!
🔴 Must show Bot ID in screenshot!
🔴 Tokens added within 12 hours

📞 Admin: @Holabrooo
"""
    
    await update.message.reply_text(msg, parse_mode=ParseMode.HTML, reply_markup=get_main_keyboard())

async def earn(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Earn button"""
    msg = """
🚀 <b>EARN TOKENS</b>

Coming soon! Join campaigns to earn.
"""
    
    await update.message.reply_text(msg, parse_mode=ParseMode.HTML, reply_markup=get_main_keyboard())

async def campaigns(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Campaigns button"""
    msg = """
📊 <b>CAMPAIGNS</b>

Coming soon! Create and manage campaigns.
"""
    
    await update.message.reply_text(msg, parse_mode=ParseMode.HTML, reply_markup=get_main_keyboard())

# ========================
# DEPOSIT FLOW
# ========================

async def deposit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Deposit button"""
    msg = """
💳 <b>DEPOSIT TOKENS</b>

🎁 <b>Quick Packages:</b>

🥉 Bronze: 1,000 tokens (+50 bonus)
🥈 Silver: 5,000 tokens (+500 bonus)
🥇 Gold: 15,000 tokens (+2,250 bonus)
💎 Platinum: 50,000 tokens (+12,500 bonus)

👇 <b>Select a package:</b>
"""
    
    keyboard = [
        [InlineKeyboardButton("🥉 Bronze (1K)", callback_data="pkg_1000")],
        [InlineKeyboardButton("🥈 Silver (5K)", callback_data="pkg_5000")],
        [InlineKeyboardButton("🥇 Gold (15K)", callback_data="pkg_15000")],
        [InlineKeyboardButton("💎 Platinum (50K)", callback_data="pkg_50000")],
        [InlineKeyboardButton("💬 Custom Amount", callback_data="pkg_custom")]
    ]
    
    await update.message.reply_text(msg, parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup(keyboard))

async def deposit_package(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle package selection"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data == "pkg_custom":
        await query.edit_message_text("💬 <b>ENTER CUSTOM AMOUNT</b>\n\nJust type a number (minimum 100):", parse_mode=ParseMode.HTML)
        return WAITING_DEPOSIT_AMOUNT
    
    amount_map = {"pkg_1000": 1000, "pkg_5000": 5000, "pkg_15000": 15000, "pkg_50000": 50000}
    amount = amount_map.get(data)
    
    if not amount:
        await query.answer("Invalid option!", show_alert=True)
        return
    
    context.user_data['deposit_amt'] = amount
    await show_crypto_methods(query, amount)

async def show_crypto_methods(query, amount):
    """Show payment methods"""
    bonus = int(amount * 0.05) if amount < 5000 else int(amount * 0.1)
    total = amount + bonus
    
    msg = f"""
📱 <b>SELECT PAYMENT METHOD</b>

Amount: {amount:,} tokens
💰 Bonus: +{bonus:,} tokens
✅ Total: {total:,} tokens

👇 Choose method:
"""
    
    keyboard = [
        [InlineKeyboardButton("USDT TRC-20", callback_data="pay_usdt")],
        [InlineKeyboardButton("BNB", callback_data="pay_bnb")],
        [InlineKeyboardButton("LTC", callback_data="pay_ltc")],
        [InlineKeyboardButton("BTC", callback_data="pay_btc")],
        [InlineKeyboardButton("POLYGON", callback_data="pay_poly")]
    ]
    
    await query.edit_message_text(msg, parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup(keyboard))

async def payment_method(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle payment method"""
    query = update.callback_query
    await query.answer()
    
    methods = {
        "pay_usdt": ("USDT TRC-20", "TWLA98sVoMhpD7VPTx1W2vAufXcjzqFgMG"),
        "pay_bnb": ("BNB", "0x0a1e335c2c8ba6d0a024a8855724fce17c123ff8"),
        "pay_ltc": ("LTC", "ltc1qphv6tu44jpglcugvkf0dsdq53uzpc5k2dp4kgl"),
        "pay_btc": ("BTC", "bc1q3kggpk49dme8s7usp2k4yxhumpe3h00nekh8rr"),
        "pay_poly": ("POLYGON", "0x0a1e335c2c8ba6d0a024a8855724fce17c123ff8")
    }
    
    if query.data not in methods:
        await query.answer("Invalid method!", show_alert=True)
        return
    
    method_name, address = methods[query.data]
    amount = context.user_data.get('deposit_amt', 0)
    
    context.user_data['payment_method'] = method_name
    context.user_data['payment_addr'] = address
    
    msg = f"""
💳 <b>PAYMENT DETAILS</b>

Method: {method_name}
Amount: {amount:,} tokens

📮 <b>Send to this address:</b>
<code>{address}</code>

⚠️ <b>IMPORTANT:</b>
🔴 Send to CORRECT address ONLY!
🔴 NO REFUNDS on wrong address!
🔴 Wrong screenshot = 7 DAYS BAN!

📸 <b>NEXT:</b>
1. Send payment above
2. Take screenshot
3. Send it here
4. Must include your Bot ID!
(Your Bot ID visible in /start welcome)

👇 <b>Ready to send screenshot?</b>
"""
    
    keyboard = [[InlineKeyboardButton("📸 Send Screenshot", callback_data="send_ss")]]
    
    await query.edit_message_text(msg, parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup(keyboard))

async def send_screenshot_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Prompt for screenshot"""
    query = update.callback_query
    await query.answer()
    
    msg = """
📸 <b>SEND YOUR SCREENSHOT</b>

Please send the screenshot of your payment.

⚠️ Make sure:
✅ Your Bot ID is visible in profile
✅ Payment amount is clear
✅ Transaction ID visible
✅ No cropping of important parts

Waiting for your screenshot...
"""
    
    await query.edit_message_text(msg, parse_mode=ParseMode.HTML)
    return WAITING_SCREENSHOT

async def handle_custom_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle custom amount text"""
    text = update.message.text
    
    try:
        amount = int(text)
        if amount < 100:
            await update.message.reply_text("❌ Minimum: 100 tokens!")
            return WAITING_DEPOSIT_AMOUNT
        
        context.user_data['deposit_amt'] = amount
        
        bonus = int(amount * 0.05)
        total = amount + bonus
        
        msg = f"""
📱 <b>SELECT PAYMENT METHOD</b>

Amount: {amount:,} tokens
💰 Bonus: +{bonus:,} tokens
✅ Total: {total:,} tokens

👇 Choose method:
"""
        
        keyboard = [
            [InlineKeyboardButton("USDT TRC-20", callback_data="pay_usdt")],
            [InlineKeyboardButton("BNB", callback_data="pay_bnb")],
            [InlineKeyboardButton("LTC", callback_data="pay_ltc")],
            [InlineKeyboardButton("BTC", callback_data="pay_btc")],
            [InlineKeyboardButton("POLYGON", callback_data="pay_poly")]
        ]
        
        await update.message.reply_text(msg, parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup(keyboard))
        return ConversationHandler.END
        
    except ValueError:
        await update.message.reply_text("❌ Please enter a valid number!", reply_markup=get_main_keyboard())
        return WAITING_DEPOSIT_AMOUNT

async def handle_screenshot(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle screenshot photo"""
    user = await get_or_create_user(update)
    
    if not update.message.photo:
        await update.message.reply_text("❌ Please send a photo!", reply_markup=get_main_keyboard())
        return
    
    photo = update.message.photo[-1]
    file_id = photo.file_id
    
    amount = context.user_data.get('deposit_amt', 0)
    method = context.user_data.get('payment_method', 'N/A')
    
    # Send to admin
    admin_msg = f"""
💳 <b>NEW DEPOSIT REQUEST</b>

👤 User: {user['first_name']}
🆔 ID: <code>{user['user_id']}</code>
@{user['username']}

💰 Amount: {amount:,} tokens
📱 Method: {method}

Status: ⏳ PENDING

Admin: Use "💰 Add Tokens" button to approve!
"""
    
    try:
        for admin_id in ADMIN_IDS:
            await context.bot.send_photo(
                chat_id=admin_id,
                photo=file_id,
                caption=admin_msg,
                parse_mode=ParseMode.HTML
            )
    except Exception as e:
        logger.error(f"Error: {e}")
    
    confirmation = f"""
✅ <b>DEPOSIT SUBMITTED!</b>

Amount: {amount:,} tokens
Method: {method}
Status: ⏳ Pending Verification

⏱️ <b>Timeline:</b>
• Admin checks screenshot
• Verifies payment
• Adds tokens (within 12 hours)

⚠️ <b>Remember:</b>
🔴 Wrong screenshot = 7 DAYS BAN!
🔴 No refunds on wrong address!
📞 Contact @Holabrooo if issues

🆔 Your ID: <code>{user['user_id']}</code>

Thank you for your patience! ✨
"""
    
    await update.message.reply_text(confirmation, parse_mode=ParseMode.HTML, reply_markup=get_main_keyboard())
    context.user_data.clear()
    return ConversationHandler.END

async def handle_text_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle text messages"""
    text = update.message.text
    user = await get_or_create_user(update)
    
    # Check if admin
    if is_admin(user['user_id']):
        if text == "💰 Add Tokens":
            return await admin_add_tokens(update, context)
        elif text == "💳 Pending Deposits":
            return await admin_pending_deposits(update, context)
        elif text == "💸 Pending Withdrawals":
            return await admin_pending_withdrawals(update, context)
        elif text == "📊 Stats":
            return await admin_stats(update, context)
        elif text == "👥 All Users":
            return await admin_all_users(update, context)
        elif text == "🚫 Ban User":
            return await admin_ban_user(update, context)
        elif text == "🔧 Settings":
            await update.message.reply_text("🔧 Settings coming soon!", reply_markup=get_admin_keyboard())
            return
        elif text == "🏠 Back":
            return await start(update, context)
    
    # Regular user menu
    if text == "💼 Wallet":
        return await wallet(update, context)
    elif text == "🚀 Earn":
        return await earn(update, context)
    elif text == "📊 Campaigns":
        return await campaigns(update, context)
    elif text == "👥 Refer":
        return await refer(update, context)
    elif text == "🏆 Achievements":
        return await achievements(update, context)
    elif text == "💳 Deposit":
        return await deposit(update, context)
    elif text == "🏪 Shop":
        return await shop(update, context)
    elif text == "ℹ️ Help":
        return await help_cmd(update, context)

# ========================
# MAIN
# ========================

def main():
    """Start bot"""
    print("""
╔════════════════════════════════════════════════════════════╗
║   🤖 PREMIUM EXCHANGE BOT v4.4.0                         ║
║   WITH ADMIN PANEL & TOKEN MANAGEMENT                     ║
║   ALL BUTTONS WORKING                                     ║
║   Starting...                                              ║
╚════════════════════════════════════════════════════════════╝
    """)
    
    app = Application.builder().token(BOT_TOKEN).build()
    
    # Command handlers
    app.add_handler(CommandHandler("start", start))
    
    # Conversation for admin tokens
    admin_conv = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^💰 Add Tokens$"), admin_add_tokens)],
        states={
            WAITING_USER_ID_FOR_TOKENS: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_handle_user_id)],
            WAITING_TOKEN_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_handle_token_amount)],
            WAITING_REASON: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_handle_reason)],
        },
        fallbacks=[CommandHandler("start", start)],
    )
    
    # Conversation for deposit
    deposit_conv = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^💳 Deposit$"), deposit)],
        states={
            WAITING_DEPOSIT_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_custom_amount)],
            WAITING_SCREENSHOT: [MessageHandler(filters.PHOTO, handle_screenshot)],
        },
        fallbacks=[CommandHandler("start", start)],
    )
    
    # Add handlers
    app.add_handler(admin_conv)
    app.add_handler(deposit_conv)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text_message))
    app.add_handler(MessageHandler(filters.PHOTO, handle_screenshot))
    app.add_handler(CallbackQueryHandler(deposit_package, pattern="^pkg_"))
    app.add_handler(CallbackQueryHandler(payment_method, pattern="^pay_"))
    app.add_handler(CallbackQueryHandler(send_screenshot_prompt, pattern="^send_ss$"))
    
    print("✅ Bot running!")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
