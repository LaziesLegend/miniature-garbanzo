"""
🤖 TELEGRAM PREMIUM EXCHANGE BOT PRO
Complete Feature-Rich Bot with ALL PR Gram Features
Version: 4.0.0 ULTRA - Production Ready
"""

import logging
import asyncio
import random
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton, InputMediaPhoto
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
from telegram.error import TelegramError
from telegram.constants import ParseMode

from database import Database
from config import *

# Setup logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Initialize database
db = Database(DATABASE_NAME)

# ========================
# 🎯 UTILITY FUNCTIONS
# ========================

def is_admin(user_id: int) -> bool:
    """Check if user is admin"""
    return user_id in ADMIN_IDS

async def get_or_create_user(update: Update) -> dict:
    """Get user or create if new with referral tracking"""
    user = update.effective_user
    
    existing = db.get_user(user.id)
    if existing:
        db.update_user_activity(user.id)
        return existing
    
    # Handle referral
    referrer_id = None
    if update.message and update.message.text.startswith('/start'):
        args = update.message.text.split()
        if len(args) > 1 and args[1].startswith('REF'):
            try:
                referrer_id = int(args[1][3:])
                if referrer_id == user.id:
                    referrer_id = None
            except (IndexError, ValueError):
                pass
    
    # Create new user
    db.create_user(
        user_id=user.id,
        username=user.username or "Unknown",
        first_name=user.first_name or "User",
        last_name=user.last_name,
        referred_by=referrer_id,
        signup_bonus=SIGNUP_BONUS
    )
    
    # Process referral bonus
    if referrer_id:
        process_referral_bonus(referrer_id, user.id)
    
    return db.get_user(user.id)

def process_referral_bonus(referrer_id: int, referred_id: int):
    """Process multi-level referral bonuses"""
    try:
        # Level 1 bonus
        db.update_user_tokens(
            referrer_id, 
            REFERRAL_BONUS_L1, 
            'referral', 
            f'Level 1 referral bonus from user {referred_id}'
        )
        
        # Level 2 bonus
        referrer = db.get_user(referrer_id)
        if referrer and referrer['referred_by']:
            db.update_user_tokens(
                referrer['referred_by'],
                REFERRAL_BONUS_L2,
                'referral',
                f'Level 2 referral bonus from user {referred_id}'
            )
            
            # Level 3 bonus
            referrer_l2 = db.get_user(referrer['referred_by'])
            if referrer_l2 and referrer_l2['referred_by']:
                db.update_user_tokens(
                    referrer_l2['referred_by'],
                    REFERRAL_BONUS_L3,
                    'referral',
                    f'Level 3 referral bonus from user {referred_id}'
                )
        
        # Update referral count
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE users SET total_referrals = total_referrals + 1
            WHERE user_id = ?
        """, (referrer_id,))
        conn.commit()
        conn.close()
        
    except Exception as e:
        logger.error(f"Error processing referral: {e}")

def check_level_up(user_id: int) -> Optional[dict]:
    """Check if user should level up"""
    user = db.get_user(user_id)
    if not user:
        return None
    
    current_level = user['level']
    total_joins = user['total_joins']
    
    # Find new level
    new_level = current_level
    for level, data in sorted(LEVELS.items(), reverse=True):
        if total_joins >= data['joins'] and level > current_level:
            new_level = level
            break
    
    if new_level > current_level:
        db.update_user_level(user_id, new_level)
        level_data = LEVELS[new_level]
        
        # Give level-up bonus
        bonus = 100 * new_level
        db.update_user_tokens(
            user_id, bonus, 'bonus', 
            f'Level {new_level} achievement bonus'
        )
        
        return {
            'level': new_level,
            'level_data': level_data,
            'bonus': bonus
        }
    
    return None

async def check_and_unlock_achievement(user_id: int, achievement_type: str):
    """Check and unlock achievements"""
    user = db.get_user(user_id)
    if not user:
        return None
    
    achievement_map = {
        'first_join': ('first_join', lambda u: u['total_joins'] >= 1),
        'join_10': ('join_10', lambda u: u['total_joins'] >= 10),
        'join_50': ('join_50', lambda u: u['total_joins'] >= 50),
        'join_100': ('join_100', lambda u: u['total_joins'] >= 100),
        'join_500': ('join_500', lambda u: u['total_joins'] >= 500),
        'join_1000': ('join_1000', lambda u: u['total_joins'] >= 1000),
        'referral_1': ('referral_1', lambda u: u['total_referrals'] >= 1),
        'referral_5': ('referral_5', lambda u: u['total_referrals'] >= 5),
        'referral_10': ('referral_10', lambda u: u['total_referrals'] >= 10),
        'referral_50': ('referral_50', lambda u: u['total_referrals'] >= 50),
        'earn_5k': ('earn_5k', lambda u: u['total_earned'] >= 5000),
        'earn_10k': ('earn_10k', lambda u: u['total_earned'] >= 10000),
        'earn_50k': ('earn_50k', lambda u: u['total_earned'] >= 50000),
        'trust_150': ('trust_150', lambda u: u['trust_score'] >= 150),
        'level_5': ('level_5', lambda u: u['level'] >= 5),
        'level_10': ('level_10', lambda u: u['level'] >= 10),
    }
    
    if achievement_type in achievement_map:
        ach_id, condition = achievement_map[achievement_type]
        if condition(user) and not db.has_achievement(user_id, ach_id):
            if db.unlock_achievement(user_id, ach_id):
                achievement = ACHIEVEMENTS[ach_id]
                # Auto-claim achievement
                if db.claim_achievement(user_id, ach_id):
                    db.update_user_tokens(
                        user_id, achievement['reward'], 'achievement',
                        f"Achievement: {achievement['name']}"
                    )
                    return achievement
    
    return None

def get_main_keyboard() -> ReplyKeyboardMarkup:
    """Get main menu keyboard"""
    keyboard = [
        [KeyboardButton("💼 My Wallet"), KeyboardButton("🚀 Earn Tokens")],
        [KeyboardButton("📊 My Campaigns"), KeyboardButton("➕ Create Campaign")],
        [KeyboardButton("👥 Referrals"), KeyboardButton("🏆 Achievements")],
        [KeyboardButton("🎁 Daily Bonus"), KeyboardButton("📈 Leaderboard")],
        [KeyboardButton("🏪 Shop"), KeyboardButton("ℹ️ Help")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

# ========================
# 🏠 START & MAIN MENU
# ========================

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start command handler"""
    user_data = await get_or_create_user(update)
    user = update.effective_user
    
    # Send logo
    try:
        with open('bot_logo.png', 'rb') as logo:
            await update.message.reply_photo(
                photo=logo,
                caption=WELCOME_MESSAGE.format(
                    join_reward=JOIN_REWARD,
                    referral_bonus=REFERRAL_BONUS_L1,
                    daily_bonus=DAILY_LOGIN_BONUS,
                    signup_bonus=SIGNUP_BONUS,
                    advertiser_cost=ADVERTISER_COST
                ),
                parse_mode=ParseMode.HTML,
                reply_markup=get_main_keyboard()
            )
    except:
        await update.message.reply_text(
            WELCOME_MESSAGE.format(
                join_reward=JOIN_REWARD,
                referral_bonus=REFERRAL_BONUS_L1,
                daily_bonus=DAILY_LOGIN_BONUS,
                signup_bonus=SIGNUP_BONUS,
                advertiser_cost=ADVERTISER_COST
            ),
            parse_mode=ParseMode.HTML,
            reply_markup=get_main_keyboard()
        )

async def menu_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle menu button presses"""
    text = update.message.text
    user_data = await get_or_create_user(update)
    
    if text == "💼 My Wallet":
        await wallet_command(update, context)
    elif text == "🚀 Earn Tokens":
        await earn_command(update, context)
    elif text == "📊 My Campaigns":
        await my_campaigns_command(update, context)
    elif text == "➕ Create Campaign":
        await create_campaign_start(update, context)
    elif text == "👥 Referrals":
        await referral_command(update, context)
    elif text == "🏆 Achievements":
        await achievements_command(update, context)
    elif text == "🎁 Daily Bonus":
        await daily_bonus_command(update, context)
    elif text == "📈 Leaderboard":
        await leaderboard_command(update, context)
    elif text == "🏪 Shop":
        await shop_command(update, context)
    elif text == "ℹ️ Help":
        await help_command(update, context)

# ========================
# 💼 WALLET & BALANCE
# ========================

async def wallet_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show wallet information"""
    user_data = await get_or_create_user(update)
    level_data = LEVELS[user_data['level']]
    
    # Get next level info
    next_level = user_data['level'] + 1
    next_level_joins = LEVELS[next_level]['joins'] if next_level in LEVELS else None
    
    wallet_text = f"""
💼 <b>YOUR WALLET</b>

💰 <b>Balance:</b> {user_data['tokens']:,} tokens
{level_data['name']} <b>Level {user_data['level']}</b>

📊 <b>Statistics:</b>
• Total Earned: {user_data['total_earned']:,} tokens
• Total Spent: {user_data['total_spent']:,} tokens
• Total Joins: {user_data['total_joins']:,}
• Total Referrals: {user_data['total_referrals']:,}

⭐ <b>Trust Score:</b> {user_data['trust_score']}/200
🎯 <b>Reward Multiplier:</b> {level_data['reward_multiplier']}x

"""
    
    if next_level_joins:
        progress = user_data['total_joins']
        remaining = next_level_joins - progress
        wallet_text += f"📈 <b>Next Level:</b> {remaining:,} more joins needed\n"
    
    keyboard = [
        [
            InlineKeyboardButton("💳 Deposit", callback_data="deposit"),
            InlineKeyboardButton("💸 Withdraw", callback_data="withdraw")
        ],
        [
            InlineKeyboardButton("📊 Transactions", callback_data="transactions"),
            InlineKeyboardButton("🔄 Refresh", callback_data="wallet")
        ]
    ]
    
    await update.message.reply_text(
        wallet_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ========================
# 🚀 EARN TOKENS
# ========================

async def earn_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show available earning opportunities"""
    user_data = await get_or_create_user(update)
    level_data = LEVELS[user_data['level']]
    
    # Get active campaigns (excluding user's own)
    campaigns = db.get_active_campaigns(limit=5, exclude_user=user_data['user_id'])
    
    if not campaigns:
        await update.message.reply_text(
            "🔍 <b>No Active Campaigns</b>\n\n"
            "There are no campaigns available right now.\n"
            "Check back soon or create your own campaign!",
            parse_mode=ParseMode.HTML
        )
        return
    
    earn_text = f"""
🚀 <b>EARN TOKENS</b>

Your Earning Rate: <b>{level_data['reward_multiplier']}x</b>
Base Reward: <b>{JOIN_REWARD} tokens</b>
Your Reward: <b>{int(JOIN_REWARD * level_data['reward_multiplier'])} tokens</b>

📢 <b>Available Campaigns ({len(campaigns)}):</b>

"""
    
    keyboard = []
    for i, campaign in enumerate(campaigns, 1):
        reward = int(campaign['join_reward'] * level_data['reward_multiplier'])
        progress = campaign['delivered_members']
        target = campaign['target_members']
        campaign_type = CAMPAIGN_TYPES.get(campaign['campaign_type'], {}).get('name', 'Standard')
        
        earn_text += f"{i}. {campaign_type}\n"
        earn_text += f"   Reward: {reward} tokens | Progress: {progress}/{target}\n\n"
        
        # Check if already joined
        if not db.user_joined_campaign(campaign['id'], user_data['user_id']):
            keyboard.append([
                InlineKeyboardButton(
                    f"🎯 Join #{i} - Get {reward} tokens",
                    callback_data=f"join_campaign_{campaign['id']}"
                )
            ])
    
    if not keyboard:
        earn_text += "\n✅ You've joined all available campaigns!\n"
    
    keyboard.append([InlineKeyboardButton("🔄 Refresh", callback_data="earn")])
    
    await update.message.reply_text(
        earn_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def handle_join_campaign(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle campaign join"""
    query = update.callback_query
    await query.answer()
    
    user_data = await get_or_create_user(update)
    campaign_id = int(query.data.split('_')[2])
    
    # Get campaign details
    campaigns = db.get_active_campaigns(limit=100)
    campaign = next((c for c in campaigns if c['id'] == campaign_id), None)
    
    if not campaign:
        await query.edit_message_text("❌ Campaign not found or no longer active.")
        return
    
    # Check if already joined
    if db.user_joined_campaign(campaign_id, user_data['user_id']):
        await query.edit_message_text("⚠️ You've already joined this campaign!")
        return
    
    # Get level multiplier
    level_data = LEVELS[user_data['level']]
    reward = int(campaign['join_reward'] * level_data['reward_multiplier'])
    
    # Add join record
    if not db.add_campaign_join(campaign_id, user_data['user_id'], level_data['reward_multiplier']):
        await query.edit_message_text("❌ Failed to join campaign. Try again.")
        return
    
    join_text = f"""
✅ <b>Campaign Joined!</b>

Please follow these steps:

1️⃣ Click the button below to join the channel
2️⃣ Stay in the channel
3️⃣ Return here and click "Verify Join"

Channel: {campaign['channel_link']}
💰 Reward: {reward} tokens

⏱️ You have 5 minutes to complete this task.
"""
    
    keyboard = [
        [InlineKeyboardButton("📢 Join Channel", url=campaign['channel_link'])],
        [InlineKeyboardButton("✅ Verify Join", callback_data=f"verify_{campaign_id}")],
        [InlineKeyboardButton("❌ Cancel", callback_data="earn")]
    ]
    
    await query.edit_message_text(
        join_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def handle_verify_join(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle join verification"""
    query = update.callback_query
    await query.answer("Verifying your join...")
    
    user_data = await get_or_create_user(update)
    campaign_id = int(query.data.split('_')[1])
    
    # Get campaign
    campaigns = db.get_active_campaigns(limit=100)
    campaign = next((c for c in campaigns if c['id'] == campaign_id), None)
    
    if not campaign:
        await query.edit_message_text("❌ Campaign not found.")
        return
    
    # Calculate reward
    level_data = LEVELS[user_data['level']]
    reward = int(campaign['join_reward'] * level_data['reward_multiplier'])
    
    # Check for bonus multipliers (happy hour, weekend, double rewards)
    multiplier = 1.0
    bonus_text = ""
    
    # Happy hour bonus
    if HAPPY_HOURS['enabled']:
        current_hour = datetime.now().hour
        if current_hour in HAPPY_HOURS['hours']:
            multiplier *= HAPPY_HOURS['multiplier']
            bonus_text += f"🎉 Happy Hour Bonus: {HAPPY_HOURS['multiplier']}x\n"
    
    # Weekend bonus
    if WEEKEND_BONUS['enabled']:
        if datetime.now().weekday() >= 5:  # Saturday or Sunday
            multiplier *= WEEKEND_BONUS['multiplier']
            bonus_text += f"🎊 Weekend Bonus: {WEEKEND_BONUS['multiplier']}x\n"
    
    # Double rewards power-up
    if user_data['double_rewards_until']:
        until_time = datetime.fromisoformat(user_data['double_rewards_until'])
        if datetime.now() < until_time:
            multiplier *= 2.0
            bonus_text += "💎 2x Rewards Active!\n"
    
    final_reward = int(reward * multiplier)
    
    # Credit tokens
    if db.update_user_tokens(
        user_data['user_id'], 
        final_reward, 
        'campaign_join',
        f"Campaign join reward (ID: {campaign_id})",
        campaign_id
    ):
        # Verify in database
        db.verify_campaign_join(campaign_id, user_data['user_id'], final_reward)
        
        # Update trust score
        db.update_trust_score(user_data['user_id'], TRUST_REWARDS['successful_join'], 'successful_join')
        
        # Check level up
        level_up = check_level_up(user_data['user_id'])
        
        # Check achievements
        achievement = await check_and_unlock_achievement(user_data['user_id'], 'first_join')
        achievement_text = ""
        if achievement:
            achievement_text = f"\n\n🏆 <b>Achievement Unlocked!</b>\n{achievement['icon']} {achievement['name']}\n+{achievement['reward']} tokens"
        
        success_text = f"""
✅ <b>JOIN VERIFIED!</b>

💰 <b>Tokens Earned:</b> {final_reward:,}
{bonus_text}
⭐ <b>Trust Score:</b> +{TRUST_REWARDS['successful_join']}

Your New Balance: {db.get_user(user_data['user_id'])['tokens']:,} tokens
{achievement_text}
"""
        
        if level_up:
            success_text += f"\n\n🎊 <b>LEVEL UP!</b>\nYou reached {level_up['level_data']['name']}!\nBonus: +{level_up['bonus']} tokens"
        
        keyboard = [
            [InlineKeyboardButton("🚀 Earn More", callback_data="earn")],
            [InlineKeyboardButton("💼 View Wallet", callback_data="wallet")]
        ]
        
        await query.edit_message_text(
            success_text,
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        
        # Check for more achievements
        await check_and_unlock_achievement(user_data['user_id'], 'join_10')
        await check_and_unlock_achievement(user_data['user_id'], 'join_50')
        await check_and_unlock_achievement(user_data['user_id'], 'join_100')
        await check_and_unlock_achievement(user_data['user_id'], 'earn_5k')
    else:
        await query.edit_message_text("❌ Failed to credit tokens. Please contact support.")

# ========================
# ➕ CREATE CAMPAIGN
# ========================

async def create_campaign_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start campaign creation"""
    user_data = await get_or_create_user(update)
    level_data = LEVELS[user_data['level']]
    
    create_text = f"""
➕ <b>CREATE CAMPAIGN</b>

Promote your Telegram channel/group and get real members!

💰 <b>Your Cost:</b> {ADVERTISER_COST} tokens per member
📊 <b>Member Reward:</b> {JOIN_REWARD} tokens
🏢 <b>Platform Fee:</b> {PLATFORM_FEE} tokens

🎯 <b>Campaign Types Available:</b>

"""
    
    keyboard = []
    for type_id, type_data in CAMPAIGN_TYPES.items():
        cost = int(ADVERTISER_COST * type_data['cost_multiplier'])
        create_text += f"{type_data['name']}\n"
        create_text += f"Cost: {cost} tokens/member | Priority: {type_data['priority']}\n"
        if 'features' in type_data:
            create_text += f"Features: {', '.join(type_data['features'])}\n"
        create_text += "\n"
        
        keyboard.append([
            InlineKeyboardButton(
                f"{type_data['name']} - {cost} tokens",
                callback_data=f"campaign_type_{type_id}"
            )
        ])
    
    create_text += f"\n💼 <b>Your Balance:</b> {user_data['tokens']:,} tokens"
    
    await update.message.reply_text(
        create_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def handle_campaign_type(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle campaign type selection"""
    query = update.callback_query
    await query.answer()
    
    campaign_type = query.data.split('_')[2]
    context.user_data['campaign_type'] = campaign_type
    
    type_data = CAMPAIGN_TYPES[campaign_type]
    
    await query.edit_message_text(
        f"✅ Selected: {type_data['name']}\n\n"
        "Please send your channel/group link (e.g., @channel or https://t.me/channel)",
        parse_mode=ParseMode.HTML
    )
    
    context.user_data['awaiting'] = 'channel_link'

async def handle_campaign_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle campaign creation input"""
    user_data = await get_or_create_user(update)
    
    if context.user_data.get('awaiting') == 'channel_link':
        channel_link = update.message.text.strip()
        
        # Basic validation
        if not (channel_link.startswith('@') or 't.me' in channel_link):
            await update.message.reply_text("❌ Invalid channel link. Please try again.")
            return
        
        context.user_data['channel_link'] = channel_link
        context.user_data['awaiting'] = 'member_count'
        
        await update.message.reply_text(
            f"✅ Channel: {channel_link}\n\n"
            f"How many members do you want? (Min: {MIN_CAMPAIGN_MEMBERS}, Max: {MAX_CAMPAIGN_MEMBERS})"
        )
    
    elif context.user_data.get('awaiting') == 'member_count':
        try:
            member_count = int(update.message.text.strip())
            
            if member_count < MIN_CAMPAIGN_MEMBERS or member_count > MAX_CAMPAIGN_MEMBERS:
                await update.message.reply_text(
                    f"❌ Please enter a number between {MIN_CAMPAIGN_MEMBERS} and {MAX_CAMPAIGN_MEMBERS}"
                )
                return
            
            # Calculate cost
            campaign_type = context.user_data['campaign_type']
            type_data = CAMPAIGN_TYPES[campaign_type]
            cost_per_member = int(ADVERTISER_COST * type_data['cost_multiplier'])
            total_cost = cost_per_member * member_count
            
            # Check balance
            if user_data['tokens'] < total_cost:
                await update.message.reply_text(
                    f"❌ Insufficient balance!\n\n"
                    f"Required: {total_cost:,} tokens\n"
                    f"Your Balance: {user_data['tokens']:,} tokens\n"
                    f"Needed: {total_cost - user_data['tokens']:,} tokens"
                )
                return
            
            # Create campaign
            campaign_id = db.create_campaign(
                user_id=user_data['user_id'],
                channel_link=context.user_data['channel_link'],
                target_members=member_count,
                join_reward=JOIN_REWARD,
                advertiser_rate=cost_per_member,
                platform_fee=int(cost_per_member - JOIN_REWARD),
                total_cost=total_cost,
                campaign_type=campaign_type,
                priority=type_data['priority']
            )
            
            if campaign_id:
                # Deduct tokens
                db.update_user_tokens(
                    user_data['user_id'],
                    -total_cost,
                    'campaign_creation',
                    f'Created campaign #{campaign_id}',
                    campaign_id
                )
                
                # Check achievement
                await check_and_unlock_achievement(user_data['user_id'], 'campaign_1')
                
                success_text = CAMPAIGN_CREATED_MESSAGE.format(
                    channel=context.user_data['channel_link'],
                    members=member_count,
                    cost_per=cost_per_member,
                    total_cost=total_cost,
                    platform_fee=int(cost_per_member - JOIN_REWARD) * member_count,
                    balance=db.get_user(user_data['user_id'])['tokens'],
                    priority=type_data['name']
                )
                
                keyboard = [
                    [InlineKeyboardButton("📊 View Campaign", callback_data=f"view_campaign_{campaign_id}")],
                    [InlineKeyboardButton("➕ Create Another", callback_data="create_campaign")]
                ]
                
                await update.message.reply_text(
                    success_text,
                    parse_mode=ParseMode.HTML,
                    reply_markup=InlineKeyboardMarkup(keyboard)
                )
                
                # Clear context
                context.user_data.clear()
            else:
                await update.message.reply_text("❌ Failed to create campaign. Please try again.")
        
        except ValueError:
            await update.message.reply_text("❌ Please enter a valid number.")

# ========================
# 📊 MY CAMPAIGNS
# ========================

async def my_campaigns_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user's campaigns"""
    user_data = await get_or_create_user(update)
    campaigns = db.get_user_campaigns(user_data['user_id'])
    
    if not campaigns:
        await update.message.reply_text(
            "📊 <b>MY CAMPAIGNS</b>\n\n"
            "You haven't created any campaigns yet.\n"
            "Use ➕ Create Campaign to start promoting!",
            parse_mode=ParseMode.HTML
        )
        return
    
    campaign_text = f"📊 <b>MY CAMPAIGNS</b>\n\nTotal: {len(campaigns)}\n\n"
    
    keyboard = []
    for campaign in campaigns[:10]:  # Show last 10
        status_emoji = "✅" if campaign['status'] == 'completed' else "🔄" if campaign['status'] == 'active' else "❌"
        progress = campaign['delivered_members']
        target = campaign['target_members']
        percentage = int((progress / target) * 100) if target > 0 else 0
        
        campaign_text += f"{status_emoji} <b>Campaign #{campaign['id']}</b>\n"
        campaign_text += f"Channel: {campaign['channel_link']}\n"
        campaign_text += f"Progress: {progress}/{target} ({percentage}%)\n"
        campaign_text += f"Status: {campaign['status'].upper()}\n\n"
        
        keyboard.append([
            InlineKeyboardButton(
                f"View #{campaign['id']} - {percentage}%",
                callback_data=f"view_campaign_{campaign['id']}"
            )
        ])
    
    await update.message.reply_text(
        campaign_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard) if keyboard else None
    )

# ========================
# 👥 REFERRAL SYSTEM
# ========================

async def referral_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show referral information"""
    user_data = await get_or_create_user(update)
    bot_username = (await context.bot.get_me()).username
    referral_link = f"https://t.me/{bot_username}?start=REF{user_data['user_id']}"
    
    referral_text = f"""
👥 <b>REFERRAL PROGRAM</b>

Invite friends and earn rewards!

🎁 <b>Referral Bonuses:</b>
• Level 1: {REFERRAL_BONUS_L1} tokens per referral
• Level 2: {REFERRAL_BONUS_L2} tokens
• Level 3: {REFERRAL_BONUS_L3} tokens

📊 <b>Your Stats:</b>
• Total Referrals: {user_data['total_referrals']}
• Estimated Earnings: {user_data['total_referrals'] * REFERRAL_BONUS_L1:,} tokens

🔗 <b>Your Referral Link:</b>
<code>{referral_link}</code>

Tap to copy and share with friends!
"""
    
    keyboard = [
        [InlineKeyboardButton("📤 Share Link", url=f"https://t.me/share/url?url={referral_link}&text=Join this amazing bot!")],
        [InlineKeyboardButton("📊 View Referrals", callback_data="view_referrals")]
    ]
    
    await update.message.reply_text(
        referral_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ========================
# 🏆 ACHIEVEMENTS
# ========================

async def achievements_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show achievements"""
    user_data = await get_or_create_user(update)
    user_achievements = db.get_user_achievements(user_data['user_id'])
    unlocked_ids = {a['achievement_id'] for a in user_achievements}
    
    total_rewards = sum(ACHIEVEMENTS[a['achievement_id']]['reward'] 
                       for a in user_achievements if a['claimed'])
    
    ach_text = f"""
🏆 <b>ACHIEVEMENTS</b>

Unlocked: {len(unlocked_ids)}/{len(ACHIEVEMENTS)}
Total Rewards Earned: {total_rewards:,} tokens

"""
    
    keyboard = []
    for ach_id, ach_data in ACHIEVEMENTS.items():
        is_unlocked = ach_id in unlocked_ids
        status = "✅" if is_unlocked else "🔒"
        
        ach_text += f"{status} {ach_data['icon']} <b>{ach_data['name']}</b>\n"
        ach_text += f"   {ach_data['description']}\n"
        ach_text += f"   Reward: {ach_data['reward']} tokens\n\n"
    
    await update.message.reply_text(
        ach_text,
        parse_mode=ParseMode.HTML
    )

# ========================
# 🎁 DAILY BONUS
# ========================

async def daily_bonus_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle daily bonus claim"""
    user_data = await get_or_create_user(update)
    
    # Check if already claimed today
    last_claim = user_data['last_daily_claim']
    if last_claim:
        last_claim_date = datetime.fromisoformat(last_claim).date()
        today = datetime.now().date()
        
        if last_claim_date == today:
            # Already claimed
            next_claim = datetime.combine(today + timedelta(days=1), datetime.min.time())
            hours_left = int((next_claim - datetime.now()).total_seconds() / 3600)
            
            await update.message.reply_text(
                f"⏰ <b>Daily Bonus Already Claimed!</b>\n\n"
                f"Come back in {hours_left} hours for your next bonus.\n"
                f"Current Streak: {user_data['daily_streak']} days 🔥",
                parse_mode=ParseMode.HTML
            )
            return
        
        # Check streak
        yesterday = today - timedelta(days=1)
        if last_claim_date == yesterday:
            # Continue streak
            new_streak = user_data['daily_streak'] + 1
        else:
            # Streak broken
            new_streak = 1
    else:
        new_streak = 1
    
    # Calculate bonus with streak multiplier
    base_bonus = DAILY_LOGIN_BONUS
    streak_multiplier = 1.0
    
    for days, multiplier in sorted(DAILY_STREAK_MULTIPLIER.items(), reverse=True):
        if new_streak >= days:
            streak_multiplier = multiplier
            break
    
    total_bonus = int(base_bonus * streak_multiplier)
    
    # Credit tokens
    db.update_user_tokens(
        user_data['user_id'],
        total_bonus,
        'daily_bonus',
        f'Daily bonus (Streak: {new_streak})'
    )
    
    # Update streak
    conn = db.get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE users 
        SET daily_streak = ?,
            last_daily_claim = CURRENT_TIMESTAMP
        WHERE user_id = ?
    """, (new_streak, user_data['user_id']))
    conn.commit()
    conn.close()
    
    # Check streak achievements
    if new_streak >= 7:
        await check_and_unlock_achievement(user_data['user_id'], 'streak_7')
    if new_streak >= 30:
        await check_and_unlock_achievement(user_data['user_id'], 'streak_30')
    
    bonus_text = f"""
🎁 <b>DAILY BONUS CLAIMED!</b>

💰 <b>Bonus Received:</b> {total_bonus:,} tokens
🔥 <b>Streak:</b> {new_streak} days

"""
    
    if streak_multiplier > 1.0:
        bonus_text += f"🌟 <b>Streak Bonus:</b> {streak_multiplier}x multiplier!\n"
    
    bonus_text += f"\n💼 <b>New Balance:</b> {db.get_user(user_data['user_id'])['tokens']:,} tokens"
    
    keyboard = [
        [InlineKeyboardButton("🚀 Earn More", callback_data="earn")],
        [InlineKeyboardButton("💼 View Wallet", callback_data="wallet")]
    ]
    
    await update.message.reply_text(
        bonus_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ========================
# 📈 LEADERBOARD
# ========================

async def leaderboard_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show leaderboard"""
    user_data = await get_or_create_user(update)
    
    leaderboard_text = "📈 <b>TOP EARNERS LEADERBOARD</b>\n\n"
    
    leaders = db.get_leaderboard(limit=LEADERBOARD_TOP_N, metric='total_earned')
    
    medals = ["🥇", "🥈", "🥉"]
    for i, leader in enumerate(leaders):
        medal = medals[i] if i < 3 else f"{i+1}."
        level_data = LEVELS.get(leader['level'], LEVELS[1])
        
        name = leader['first_name']
        if leader['username']:
            name = f"@{leader['username']}"
        
        leaderboard_text += f"{medal} <b>{name}</b>\n"
        leaderboard_text += f"   💰 {leader['total_earned']:,} tokens | {level_data['name']}\n\n"
    
    keyboard = [
        [
            InlineKeyboardButton("💰 Earnings", callback_data="lb_earned"),
            InlineKeyboardButton("🎯 Joins", callback_data="lb_joins")
        ],
        [
            InlineKeyboardButton("👥 Referrals", callback_data="lb_referrals"),
            InlineKeyboardButton("🔄 Refresh", callback_data="leaderboard")
        ]
    ]
    
    await update.message.reply_text(
        leaderboard_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ========================
# 🏪 SHOP
# ========================

async def shop_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show shop items"""
    user_data = await get_or_create_user(update)
    
    shop_text = f"""
🏪 <b>TOKEN SHOP</b>

Buy power-ups and bonuses!

💼 <b>Your Balance:</b> {user_data['tokens']:,} tokens

🛍️ <b>Available Items:</b>

"""
    
    keyboard = []
    for item_id, item_data in SHOP_ITEMS.items():
        shop_text += f"{item_data['name']}\n"
        shop_text += f"{item_data['description']}\n"
        shop_text += f"Cost: {item_data['cost']:,} tokens\n\n"
        
        keyboard.append([
            InlineKeyboardButton(
                f"Buy {item_data['name']} - {item_data['cost']:,} tokens",
                callback_data=f"buy_{item_id}"
            )
        ])
    
    await update.message.reply_text(
        shop_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def handle_shop_purchase(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle shop item purchase"""
    query = update.callback_query
    await query.answer()
    
    user_data = await get_or_create_user(update)
    item_id = query.data.split('_', 1)[1]
    
    if item_id not in SHOP_ITEMS:
        await query.edit_message_text("❌ Item not found.")
        return
    
    item_data = SHOP_ITEMS[item_id]
    cost = item_data['cost']
    
    # Check balance
    if user_data['tokens'] < cost:
        await query.edit_message_text(
            f"❌ Insufficient balance!\n\n"
            f"Required: {cost:,} tokens\n"
            f"Your Balance: {user_data['tokens']:,} tokens"
        )
        return
    
    # Deduct tokens
    if not db.update_user_tokens(
        user_data['user_id'],
        -cost,
        'shop_purchase',
        f'Purchased: {item_data["name"]}')
    :
        await query.edit_message_text("❌ Purchase failed. Try again.")
        return
    
    # Handle different item types
    success_text = f"✅ <b>Purchase Successful!</b>\n\n"
    success_text += f"Item: {item_data['name']}\n"
    success_text += f"Cost: {cost:,} tokens\n\n"
    
    if item_id == 'lucky_spin' or item_id == 'mega_spin':
        # Lucky spin - random reward
        min_win = 100 if item_id == 'lucky_spin' else 500
        max_win = 10000 if item_id == 'lucky_spin' else 50000
        win_amount = random.randint(min_win, max_win)
        
        db.update_user_tokens(
            user_data['user_id'],
            win_amount,
            'spin_win',
            f'Won from {item_data["name"]}'
        )
        
        success_text += f"🎰 <b>YOU WON: {win_amount:,} TOKENS!</b>\n"
    
    elif 'duration_hours' in item_data:
        # Time-based power-up
        expiry_time = datetime.now() + timedelta(hours=item_data['duration_hours'])
        
        conn = db.get_connection()
        cursor = conn.cursor()
        
        if 'priority_boost' in item_id:
            cursor.execute("""
                UPDATE users 
                SET priority_boost_until = ?
                WHERE user_id = ?
            """, (expiry_time.isoformat(), user_data['user_id']))
            success_text += f"⚡ Priority Boost active for {item_data['duration_hours']}h!\n"
        
        elif 'double_rewards' in item_id:
            cursor.execute("""
                UPDATE users 
                SET double_rewards_until = ?
                WHERE user_id = ?
            """, (expiry_time.isoformat(), user_data['user_id']))
            success_text += f"💎 Double Rewards active for {item_data['duration_hours']}h!\n"
        
        elif 'vip' in item_id:
            expiry_time = datetime.now() + timedelta(days=item_data['duration_days'])
            cursor.execute("""
                UPDATE users 
                SET is_vip = 1, vip_until = ?
                WHERE user_id = ?
            """, (expiry_time.isoformat(), user_data['user_id']))
            success_text += f"👑 VIP Status active for {item_data['duration_days']} days!\n"
        
        conn.commit()
        conn.close()
    
    elif 'trust_restore' in item_id:
        # Trust restore
        restore_amount = 20 if '20' in item_id else 50
        db.update_trust_score(user_data['user_id'], restore_amount, 'shop_purchase')
        success_text += f"🛡️ Trust Score restored by +{restore_amount}!\n"
    
    success_text += f"\n💼 New Balance: {db.get_user(user_data['user_id'])['tokens']:,} tokens"
    
    keyboard = [
        [InlineKeyboardButton("🏪 Shop", callback_data="shop")],
        [InlineKeyboardButton("💼 Wallet", callback_data="wallet")]
    ]
    
    await query.edit_message_text(
        success_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ========================
# ℹ️ HELP
# ========================

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show help information"""
    help_text = """
ℹ️ <b>BOT HELP & GUIDE</b>

<b>📖 How It Works:</b>

1️⃣ <b>Earn Tokens:</b>
   • Join campaigns to earn tokens
   • Refer friends for bonuses
   • Claim daily rewards
   • Complete achievements

2️⃣ <b>Create Campaigns:</b>
   • Use tokens to promote your channel
   • Choose campaign type
   • Set target members
   • Track progress

3️⃣ <b>Level Up:</b>
   • Complete more joins to level up
   • Higher levels = better rewards
   • Unlock new features

4️⃣ <b>Earn More:</b>
   • Maintain login streaks
   • Participate during happy hours
   • Use power-ups from shop
   • Build your referral network

<b>💡 Pro Tips:</b>
• Keep your trust score high
• Complete daily tasks
• Use priority boost for faster tasks
• Join during happy hours for bonuses

<b>🔗 Quick Commands:</b>
/start - Main menu
/wallet - View balance
/earn - Find campaigns
/referral - Get referral link
/help - Show this help

Need more help? Contact support!
"""
    
    await update.message.reply_text(help_text, parse_mode=ParseMode.HTML)

# ========================
# 📞 CALLBACK HANDLERS
# ========================

async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle all callback queries"""
    query = update.callback_query
    data = query.data
    
    try:
        if data == "wallet":
            user_data = await get_or_create_user(update)
            # Recreate wallet message
            await query.message.delete()
            await wallet_command(update, context)
        
        elif data == "earn":
            await query.message.delete()
            await earn_command(update, context)
        
        elif data.startswith("join_campaign_"):
            await handle_join_campaign(update, context)
        
        elif data.startswith("verify_"):
            await handle_verify_join(update, context)
        
        elif data.startswith("campaign_type_"):
            await handle_campaign_type(update, context)
        
        elif data.startswith("buy_"):
            await handle_shop_purchase(update, context)
        
        elif data == "shop":
            await query.message.delete()
            await shop_command(update, context)
        
        elif data == "leaderboard":
            await query.message.delete()
            await leaderboard_command(update, context)
        
        elif data == "deposit":
            await query.answer("💳 Deposit feature - Contact admin to add funds!")
        
        elif data == "withdraw":
            await query.answer("💸 Withdrawal feature - Contact admin to request withdrawal!")
        
        elif data == "transactions":
            await query.answer("📊 Transaction history - Coming soon!")
        
        else:
            await query.answer("Feature coming soon!")
    
    except Exception as e:
        logger.error(f"Callback error: {e}")
        await query.answer("An error occurred. Please try again.")

# ========================
# 🔧 ADMIN COMMANDS
# ========================

async def admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show admin statistics"""
    if not is_admin(update.effective_user.id):
        return
    
    stats = db.get_system_stats()
    
    stats_text = f"""
👑 <b>ADMIN DASHBOARD</b>

📊 <b>System Statistics:</b>

👥 Total Users: {stats.get('total_users', 0):,}
🟢 Active (24h): {stats.get('active_users_24h', 0):,}

📢 Total Campaigns: {stats.get('total_campaigns', 0):,}
🔄 Active Campaigns: {stats.get('active_campaigns', 0):,}

💰 Tokens in Circulation: {stats.get('tokens_in_circulation', 0):,}
💎 Platform Profit: {stats.get('platform_profit', 0):,}

⏰ Last Updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
    
    await update.message.reply_text(stats_text, parse_mode=ParseMode.HTML)

# ========================
# 🚀 MAIN APPLICATION
# ========================

def main():
    """Start the bot"""
    print("""
╔════════════════════════════════════════════════╗
║   🤖 PREMIUM EXCHANGE BOT PRO                 ║
║   Version: 4.0.0 ULTRA                         ║
║   Status: STARTING...                          ║
╚════════════════════════════════════════════════╝
    """)
    
    # Create application
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Command handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("stats", admin_stats))
    
    # Message handlers
    application.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND,
        lambda u, c: handle_campaign_input(u, c) if c.user_data.get('awaiting') else menu_handler(u, c)
    ))
    
    # Callback handler
    application.add_handler(CallbackQueryHandler(callback_handler))
    
    # Start bot
    logger.info("🚀 Bot started successfully!")
    print("""
╔════════════════════════════════════════════════╗
║   ✅ BOT IS RUNNING!                          ║
║   Press Ctrl+C to stop                         ║
╚════════════════════════════════════════════════╝
    """)
    
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
