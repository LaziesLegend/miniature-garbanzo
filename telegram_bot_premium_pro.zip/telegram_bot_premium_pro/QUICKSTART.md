# 🚀 QUICK START GUIDE

## Get Started in 60 Seconds!

### Method 1: Instant Launch (Recommended)

**On Linux/Mac:**
```bash
unzip telegram_bot_premium_pro.zip
cd telegram_bot_premium_pro
./start.sh
```

**On Windows:**
```cmd
1. Extract telegram_bot_premium_pro.zip
2. Open the folder
3. Double-click start.bat
```

That's it! Your bot is running! 🎉

---

### Method 2: Manual Launch

```bash
# Step 1: Extract
unzip telegram_bot_premium_pro.zip
cd telegram_bot_premium_pro

# Step 2: Install dependencies (one-time)
pip install python-telegram-bot pillow

# Step 3: Run the bot
python main.py
```

---

## ✅ Pre-Configured Settings

Your bot is ready to use with:
- ✅ **Bot Token**: Already configured
- ✅ **Admin ID**: Already set (8301300209)
- ✅ **Database**: Auto-created on first run
- ✅ **Logo**: Auto-generated
- ✅ **All Features**: Enabled

**No configuration needed!** Just run and use.

---

## 📱 First Steps After Launch

1. **Find your bot** on Telegram
2. **Send** `/start`
3. **Click** "🚀 Earn Tokens" to see campaigns
4. **Create** your first campaign with "➕ Create Campaign"
5. **Refer** friends with "👥 Referrals" to earn bonuses

---

## 🎯 Quick Tips

### For Earning
- Join campaigns to earn tokens
- Claim daily bonus for streak bonuses
- Refer friends for passive income
- Complete achievements for big rewards

### For Promoting
- Create campaigns to promote your channel
- Choose Premium/Urgent for faster delivery
- Monitor progress in "My Campaigns"
- Refill campaigns when needed

---

## 🆘 Troubleshooting

**Bot not starting?**
```bash
pip install --upgrade python-telegram-bot
python main.py
```

**"ModuleNotFoundError"?**
```bash
pip install -r requirements.txt
```

**Database error?**
```bash
rm bot_premium_pro.db  # Delete old database
python main.py  # Restart bot
```

---

## 📊 What's Included

- ✅ Complete working bot
- ✅ Professional logo (512x512)
- ✅ SQLite database (auto-created)
- ✅ All PR Gram features
- ✅ Admin panel
- ✅ Comprehensive documentation
- ✅ Auto-setup scripts

---

## 🎮 Main Features Quick Access

| Button | Function |
|--------|----------|
| 💼 My Wallet | View balance, level, stats |
| 🚀 Earn Tokens | Browse and join campaigns |
| 📊 My Campaigns | Manage your campaigns |
| ➕ Create Campaign | Promote your channel |
| 👥 Referrals | Get referral link |
| 🏆 Achievements | Claim achievement rewards |
| 🎁 Daily Bonus | Claim daily rewards |
| 📈 Leaderboard | View top users |
| 🏪 Shop | Buy power-ups |

---

## 💰 Token Economy

- **Join Campaigns**: 90 tokens (up to 180 with bonuses)
- **Daily Login**: 15-75 tokens (streak based)
- **Referral L1**: 20 tokens
- **Referral L2**: 8 tokens
- **Referral L3**: 3 tokens
- **Welcome Bonus**: 150 tokens
- **Achievements**: Up to 10,000 tokens

---

## 🎁 Special Bonuses

- **Happy Hours** (10AM, 2PM, 6PM, 10PM): 1.6x earnings
- **Weekends**: 1.3x all rewards
- **Streak Bonuses**: Up to 5x daily reward
- **Level Multipliers**: Up to 2x earnings
- **VIP Status**: Reduced fees

---

## 📞 Need Help?

1. Check the `/help` command in bot
2. Read the full README.md
3. Review config.py for customization
4. All features are working out-of-the-box!

---

## ⚡ Performance Notes

- Handles 1000+ users
- Support 100+ concurrent campaigns
- Real-time updates
- Auto-saves every transaction
- No manual intervention needed

---

**Enjoy your Premium Exchange Bot PRO!** 🎉

Made with ❤️ - Version 4.0.0 ULTRA
