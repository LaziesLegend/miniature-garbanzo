# 🚀 QUICK START GUIDE

Get your Telegram Member Exchange Bot Pro running in **5 minutes**!

---

## ⚡ Super Quick Setup (3 Steps)

### Step 1: Get Bot Token
1. Open Telegram
2. Message [@BotFather](https://t.me/BotFather)
3. Send `/newbot`
4. Follow instructions
5. **Copy your bot token**

### Step 2: Configure Bot
```bash
# Edit config.py
nano config.py
```

Replace these lines:
```python
BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"  # ← Paste your token here
ADMIN_IDS = [123456789]             # ← Add your Telegram user ID
```

**How to get your Telegram ID:**
1. Message [@userinfobot](https://t.me/userinfobot)
2. Copy the ID number
3. Add to `ADMIN_IDS`

### Step 3: Run Bot
```bash
# Run installation (optional but recommended)
./INSTALL.sh

# Or install manually
pip install -r requirements.txt

# Start the bot
python3 main.py
```

✅ **Done! Your bot is running!**

---

## 📱 First Commands

### For Users:
```
/start          - Get welcome bonus (100 tokens)
/menu           - Show main menu
/stats          - View your statistics
```

### For Admins:
```
/admin          - Access admin panel
```

---

## 🎯 Quick Feature Tour

### 1. Earn Your First Tokens (30 seconds)
```
1. Click "🚀 Earn" button
2. Click any available campaign
3. Click "Join Campaign"
4. Join the Telegram channel
5. Return and click "Verify"
6. Receive 90+ tokens!
```

### 2. Refer Your First Friend (1 minute)
```
1. Click "👥 Referrals"
2. Copy your referral link
3. Share with a friend
4. When they sign up: +15 tokens
5. When they earn: more tokens!
```

### 3. Create Your First Campaign (2 minutes)
```
/campaign @your_channel 50
```
Or:
```
1. Click "📢 Campaign"
2. Follow the instructions
3. Use format: /campaign @channel 100
4. Confirm payment
5. Campaign starts immediately!
```

### 4. Claim Daily Reward (10 seconds)
```
1. Click "🎁 Daily"
2. Click "Claim Now"
3. Receive 10+ tokens
4. Come back tomorrow for streaks!
```

---

## 🎮 User Journey Examples

### Example 1: The Earner
```
Day 1: Join bot → Get 100 tokens bonus
       Join 5 campaigns → Earn 450 tokens
       Refer 2 friends → Earn 30 tokens
       Total: 580 tokens

Day 2: Claim daily reward → 10 tokens
       Join 10 campaigns → Earn 900 tokens  
       Referrals complete tasks → 10 tokens
       Total: 1,500 tokens

Day 7: Daily streak → 15 tokens
       Join 20 campaigns → Earn 1,800 tokens
       Level up to Bronze → 1.05x multiplier
       Total: 4,000+ tokens
```

### Example 2: The Advertiser
```
Day 1: Buy 10,000 tokens (via deposit)
       Create campaign for 100 members
       Cost: 11,500 tokens
       
Day 2: 50 members joined
       Campaign 50% complete
       
Day 3: Campaign completed!
       100 real members in channel
       Remaining tokens: Can create more!
```

### Example 3: The Referrer
```
Day 1: Refer 10 friends → 150 tokens

Day 7: Friends refer 50 people → 250 tokens
       Total from referrals: 400 tokens

Day 30: 3-level network active
        Passive income: 100+ tokens/day
        Total earned: 5,000+ tokens
```

---

## 💡 Pro Tips

### Maximize Earnings
1. ✅ **Join campaigns daily** (up to 100/day)
2. ✅ **Maintain high trust score** (complete verifications)
3. ✅ **Level up fast** (better multipliers)
4. ✅ **Refer friends** (passive income)
5. ✅ **Claim daily rewards** (build streaks)
6. ✅ **Complete achievements** (bonus tokens)

### Create Successful Campaigns
1. ✅ **Use clear channel names** (@channel_username)
2. ✅ **Start with small campaigns** (50-100 members)
3. ✅ **Choose Premium for quality** (verified members)
4. ✅ **Monitor progress** (check "My Campaigns")
5. ✅ **Refill if needed** (campaigns can auto-refill)

### Build Referral Network
1. ✅ **Share on social media**
2. ✅ **Join Telegram groups**
3. ✅ **Create content about the bot**
4. ✅ **Help referrals get started**
5. ✅ **Build trust and value**

---

## 🎁 Welcome Bonus Breakdown

When you join, you get:
```
✅ 100 tokens signup bonus
✅ Access to all features
✅ Trust score: 100/100
✅ Level: Newbie
✅ Unique referral link
✅ Daily reward ready
✅ Achievement tracking active
```

---

## 🔥 First Week Challenge

Complete these to maximize earnings:

**Day 1:**
- [x] Join bot (+100 tokens)
- [x] Complete 5 joins (+450 tokens)
- [x] Refer 1 friend (+15 tokens)
- [x] Claim daily reward (+10 tokens)
**Total: 575 tokens**

**Day 2-6:**
- [x] Claim daily rewards (+50 tokens)
- [x] Join 30 campaigns (+2,700 tokens)
- [x] Referral bonuses (+50 tokens)
**Total: 2,800 tokens**

**Day 7:**
- [x] Claim streak bonus (+15 tokens)
- [x] Achievement unlocks (+200 tokens)
- [x] Level up bonus (+100 tokens)
**Total: 315 tokens**

**Week 1 Total: 3,690+ tokens!**
*Enough to create your own campaign!*

---

## ⚙️ Admin Quick Setup

### Access Admin Panel
```
/admin
```

### Key Admin Actions

**1. Approve Deposits**
```
/admin → Deposits → Review → Approve/Reject
```

**2. Process Withdrawals**
```
/admin → Withdrawals → Review → Process
```

**3. Add Tokens to User**
```
/addtokens 123456789 1000
```

**4. Broadcast Message**
```
/broadcast Your message here
```

**5. View Global Stats**
```
/admin → Statistics → View All
```

---

## 🆘 Quick Troubleshooting

### Bot doesn't respond
```bash
# Check if bot is running
ps aux | grep python

# Check logs
tail -f bot.log

# Restart bot
python3 main.py
```

### Buttons not working
```
Solution: Update to latest python-telegram-bot
pip install --upgrade python-telegram-bot
```

### "Insufficient balance" error
```
Solution: Deposit more tokens or earn through joins
```

### Verification fails
```
Solution: 
1. Make sure you actually joined the channel
2. Wait 10 seconds before verifying
3. Check if bot has channel access
```

---

## 📚 Next Steps

After setup, check:
1. 📖 [README.md](README.md) - Full documentation
2. 📋 [FEATURES.md](FEATURES.md) - Complete feature list
3. ⚙️ [config.py](config.py) - Advanced configuration
4. 🗄️ Database schema - In database.py

---

## 🎯 Success Metrics

### Week 1 Goals
- [ ] 10+ users joined
- [ ] 5+ campaigns created
- [ ] 100+ joins completed
- [ ] 50+ referrals made

### Month 1 Goals
- [ ] 100+ users
- [ ] 50+ campaigns
- [ ] 1,000+ joins
- [ ] 500+ referrals

---

## 💬 Support

Need help?
- 📖 Check README.md
- 🐛 Report issues on GitHub
- 💬 Join support channel
- 📧 Contact: support@yourbot.com

---

## 🎉 Congratulations!

You're now running one of the most advanced Telegram Member Exchange Bots!

**Features you have:**
✅ 30+ advanced features
✅ Professional design
✅ Complete security
✅ Multi-level referrals
✅ Achievement system
✅ Token shop
✅ And much more!

**Start earning and growing your network today!** 🚀

---

<div align="center">

**Made with ❤️ by Premium Bot Team**

Version 3.0.0 - The Ultimate Edition

[⬆ Back to Top](#-quick-start-guide)

</div>
