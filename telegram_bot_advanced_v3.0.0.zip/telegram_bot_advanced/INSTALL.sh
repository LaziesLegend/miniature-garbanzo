#!/bin/bash

# 🚀 Telegram Member Exchange Bot Pro - Installation Script
# Version: 3.0.0

echo "╔══════════════════════════════════════════════════════════╗"
echo "║   🤖 TELEGRAM MEMBER EXCHANGE BOT PRO                   ║"
echo "║   Installation Script v3.0.0                             ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check Python version
echo -e "${YELLOW}Checking Python version...${NC}"
python_version=$(python3 --version 2>&1 | awk '{print $2}')
required_version="3.9.0"

if [ "$(printf '%s\n' "$required_version" "$python_version" | sort -V | head -n1)" = "$required_version" ]; then 
    echo -e "${GREEN}✓ Python $python_version found${NC}"
else
    echo -e "${RED}✗ Python 3.9+ required. Found: $python_version${NC}"
    exit 1
fi

# Check pip
echo -e "${YELLOW}Checking pip...${NC}"
if command -v pip3 &> /dev/null; then
    echo -e "${GREEN}✓ pip3 found${NC}"
else
    echo -e "${RED}✗ pip3 not found. Installing...${NC}"
    sudo apt-get install python3-pip -y
fi

# Install dependencies
echo ""
echo -e "${YELLOW}Installing dependencies...${NC}"
pip3 install -r requirements.txt

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Dependencies installed successfully${NC}"
else
    echo -e "${RED}✗ Failed to install dependencies${NC}"
    exit 1
fi

# Create database
echo ""
echo -e "${YELLOW}Initializing database...${NC}"
python3 -c "from database import Database; Database('bot_premium.db')"

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Database initialized${NC}"
else
    echo -e "${RED}✗ Failed to initialize database${NC}"
    exit 1
fi

# Check configuration
echo ""
echo -e "${YELLOW}Checking configuration...${NC}"
if grep -q "YOUR_BOT_TOKEN_HERE" config.py; then
    echo -e "${RED}⚠️  WARNING: Bot token not configured!${NC}"
    echo -e "${YELLOW}Please edit config.py and add your bot token from @BotFather${NC}"
    echo ""
else
    echo -e "${GREEN}✓ Configuration looks good${NC}"
fi

# Final message
echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║   ✅ INSTALLATION COMPLETE!                              ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
echo -e "${YELLOW}Next steps:${NC}"
echo "1. Edit config.py with your bot token"
echo "2. Add your Telegram user ID to ADMIN_IDS"
echo "3. Run: python3 main.py"
echo ""
echo -e "${GREEN}Need help? Check README.md${NC}"
echo ""
