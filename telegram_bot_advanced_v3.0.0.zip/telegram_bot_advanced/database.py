"""
🗄️ ENHANCED DATABASE LAYER - Advanced Schema with New Features
Complete data management for Premium Exchange Bot
Version: 3.0.0
"""

import sqlite3
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
import json
import logging

logger = logging.getLogger(__name__)

class Database:
    def __init__(self, db_name: str = "bot_premium.db"):
        self.db_name = db_name
        self.init_database()
        logger.info(f"✅ Database initialized: {db_name}")
    
    def get_connection(self):
        """Get database connection with row factory"""
        conn = sqlite3.connect(self.db_name)
        conn.row_factory = sqlite3.Row
        return conn
    
    def init_database(self):
        """Initialize all database tables with enhanced schema"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # ========================
        # 👤 USERS TABLE (Enhanced)
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                tokens INTEGER DEFAULT 0,
                level INTEGER DEFAULT 1,
                trust_score INTEGER DEFAULT 100,
                total_joins INTEGER DEFAULT 0,
                total_earned INTEGER DEFAULT 0,
                total_spent INTEGER DEFAULT 0,
                total_referrals INTEGER DEFAULT 0,
                referred_by INTEGER,
                join_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_daily_claim TIMESTAMP,
                daily_streak INTEGER DEFAULT 0,
                is_banned INTEGER DEFAULT 0,
                ban_reason TEXT,
                ban_until TIMESTAMP,
                is_vip INTEGER DEFAULT 0,
                vip_until TIMESTAMP,
                language TEXT DEFAULT 'en',
                notifications_enabled INTEGER DEFAULT 1,
                FOREIGN KEY (referred_by) REFERENCES users(user_id)
            )
        """)
        
        # ========================
        # 🚀 CAMPAIGNS TABLE (Enhanced)
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS campaigns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                channel_link TEXT NOT NULL,
                channel_username TEXT,
                channel_title TEXT,
                target_members INTEGER NOT NULL,
                delivered_members INTEGER DEFAULT 0,
                pending_members INTEGER DEFAULT 0,
                verified_members INTEGER DEFAULT 0,
                join_reward INTEGER NOT NULL,
                advertiser_rate INTEGER NOT NULL,
                platform_fee INTEGER NOT NULL,
                total_cost INTEGER NOT NULL,
                status TEXT DEFAULT 'active',
                campaign_type TEXT DEFAULT 'standard',
                priority INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                started_at TIMESTAMP,
                completed_at TIMESTAMP,
                cancelled_at TIMESTAMP,
                cancel_reason TEXT,
                auto_refill INTEGER DEFAULT 0,
                refill_threshold INTEGER DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        
        # ========================
        # 🔗 CAMPAIGN JOINS TABLE (Enhanced)
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS campaign_joins (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                campaign_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                verified INTEGER DEFAULT 0,
                verification_attempts INTEGER DEFAULT 0,
                reward_multiplier REAL DEFAULT 1.0,
                tokens_earned INTEGER DEFAULT 0,
                joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                verified_at TIMESTAMP,
                left_channel INTEGER DEFAULT 0,
                left_at TIMESTAMP,
                quality_score INTEGER DEFAULT 0,
                FOREIGN KEY (campaign_id) REFERENCES campaigns(id),
                FOREIGN KEY (user_id) REFERENCES users(user_id),
                UNIQUE(campaign_id, user_id)
            )
        """)
        
        # ========================
        # 💰 TRANSACTIONS TABLE (Enhanced)
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                type TEXT NOT NULL,
                amount INTEGER NOT NULL,
                description TEXT,
                related_id INTEGER,
                related_type TEXT,
                balance_before INTEGER,
                balance_after INTEGER,
                metadata TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        
        # ========================
        # 💳 DEPOSITS TABLE (Enhanced)
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS deposits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                method TEXT NOT NULL,
                amount INTEGER NOT NULL,
                bonus_amount INTEGER DEFAULT 0,
                total_credited INTEGER,
                tier TEXT,
                status TEXT DEFAULT 'pending',
                tx_hash TEXT,
                payment_proof_file_id TEXT,
                payment_details TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                processed_at TIMESTAMP,
                approved_by INTEGER,
                reject_reason TEXT,
                notes TEXT,
                FOREIGN KEY (user_id) REFERENCES users(user_id),
                FOREIGN KEY (approved_by) REFERENCES users(user_id)
            )
        """)
        
        # ========================
        # 💸 WITHDRAWALS TABLE (NEW)
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS withdrawals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                method TEXT NOT NULL,
                amount INTEGER NOT NULL,
                fee_amount INTEGER NOT NULL,
                net_amount INTEGER NOT NULL,
                payment_details TEXT NOT NULL,
                status TEXT DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                processed_at TIMESTAMP,
                processed_by INTEGER,
                tx_reference TEXT,
                reject_reason TEXT,
                notes TEXT,
                FOREIGN KEY (user_id) REFERENCES users(user_id),
                FOREIGN KEY (processed_by) REFERENCES users(user_id)
            )
        """)
        
        # ========================
        # 👥 REFERRALS TABLE (Enhanced)
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS referrals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                referrer_id INTEGER NOT NULL,
                referred_user_id INTEGER NOT NULL,
                level INTEGER DEFAULT 1,
                signup_bonus_given INTEGER DEFAULT 0,
                task_bonus_given INTEGER DEFAULT 0,
                total_bonus_earned INTEGER DEFAULT 0,
                first_task_completed INTEGER DEFAULT 0,
                is_active INTEGER DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (referrer_id) REFERENCES users(user_id),
                FOREIGN KEY (referred_user_id) REFERENCES users(user_id),
                UNIQUE(referrer_id, referred_user_id)
            )
        """)
        
        # ========================
        # 🏆 ACHIEVEMENTS TABLE (NEW)
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS achievements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                achievement_key TEXT NOT NULL,
                unlocked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                reward_claimed INTEGER DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES users(user_id),
                UNIQUE(user_id, achievement_key)
            )
        """)
        
        # ========================
        # 📅 DAILY REWARDS TABLE (NEW)
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS daily_rewards (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                claim_date DATE NOT NULL,
                streak_day INTEGER NOT NULL,
                base_reward INTEGER NOT NULL,
                bonus_reward INTEGER DEFAULT 0,
                total_reward INTEGER NOT NULL,
                claimed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id),
                UNIQUE(user_id, claim_date)
            )
        """)
        
        # ========================
        # 🎯 DAILY TASKS TABLE (NEW)
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS daily_tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                task_key TEXT NOT NULL,
                task_date DATE NOT NULL,
                progress INTEGER DEFAULT 0,
                target INTEGER NOT NULL,
                completed INTEGER DEFAULT 0,
                reward_claimed INTEGER DEFAULT 0,
                completed_at TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id),
                UNIQUE(user_id, task_key, task_date)
            )
        """)
        
        # ========================
        # 🏪 SHOP PURCHASES TABLE (NEW)
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS shop_purchases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                item_key TEXT NOT NULL,
                cost INTEGER NOT NULL,
                purchased_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP,
                is_active INTEGER DEFAULT 1,
                metadata TEXT,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        
        # ========================
        # 📊 USER STATISTICS TABLE (NEW)
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_statistics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                date DATE NOT NULL,
                joins_completed INTEGER DEFAULT 0,
                tokens_earned INTEGER DEFAULT 0,
                campaigns_created INTEGER DEFAULT 0,
                referrals_made INTEGER DEFAULT 0,
                time_active_minutes INTEGER DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES users(user_id),
                UNIQUE(user_id, date)
            )
        """)
        
        # ========================
        # 🚨 SECURITY LOGS TABLE (Enhanced)
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS security_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                event_type TEXT NOT NULL,
                severity TEXT NOT NULL,
                description TEXT,
                ip_address TEXT,
                user_agent TEXT,
                metadata TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        
        # ========================
        # 🔔 NOTIFICATIONS TABLE (NEW)
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                type TEXT NOT NULL,
                title TEXT NOT NULL,
                message TEXT NOT NULL,
                is_read INTEGER DEFAULT 0,
                action_url TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                read_at TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        
        # ========================
        # ⚙️ SYSTEM SETTINGS TABLE (NEW)
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS system_settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                description TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_by INTEGER,
                FOREIGN KEY (updated_by) REFERENCES users(user_id)
            )
        """)
        
        # Create indexes for performance
        self._create_indexes(cursor)
        
        # Insert default system settings
        self._insert_default_settings(cursor)
        
        conn.commit()
        conn.close()
        
        logger.info("✅ All tables and indexes created successfully")
    
    def _create_indexes(self, cursor):
        """Create indexes for better query performance"""
        indexes = [
            "CREATE INDEX IF NOT EXISTS idx_users_level ON users(level)",
            "CREATE INDEX IF NOT EXISTS idx_users_trust_score ON users(trust_score)",
            "CREATE INDEX IF NOT EXISTS idx_campaigns_status ON campaigns(status)",
            "CREATE INDEX IF NOT EXISTS idx_campaigns_user ON campaigns(user_id, status)",
            "CREATE INDEX IF NOT EXISTS idx_campaign_joins_verified ON campaign_joins(verified)",
            "CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id, created_at DESC)",
            "CREATE INDEX IF NOT EXISTS idx_deposits_status ON deposits(status)",
            "CREATE INDEX IF NOT EXISTS idx_withdrawals_status ON withdrawals(status)",
            "CREATE INDEX IF NOT EXISTS idx_referrals_referrer ON referrals(referrer_id)",
            "CREATE INDEX IF NOT EXISTS idx_notifications_user_unread ON notifications(user_id, is_read)",
            "CREATE INDEX IF NOT EXISTS idx_security_logs_user ON security_logs(user_id, created_at DESC)"
        ]
        
        for index_sql in indexes:
            try:
                cursor.execute(index_sql)
            except sqlite3.Error as e:
                logger.warning(f"Index creation warning: {e}")
    
    def _insert_default_settings(self, cursor):
        """Insert default system settings"""
        default_settings = [
            ('maintenance_mode', '0', 'System maintenance mode flag'),
            ('registration_enabled', '1', 'New user registration flag'),
            ('deposits_enabled', '1', 'Deposit system flag'),
            ('withdrawals_enabled', '1', 'Withdrawal system flag'),
            ('min_withdrawal', '1000', 'Minimum withdrawal amount'),
            ('platform_fee_percent', '21.7', 'Platform fee percentage')
        ]
        
        for key, value, description in default_settings:
            try:
                cursor.execute("""
                    INSERT OR IGNORE INTO system_settings (key, value, description)
                    VALUES (?, ?, ?)
                """, (key, value, description))
            except sqlite3.Error as e:
                logger.warning(f"Setting insertion warning: {e}")
    
    # ========================
    # 👤 USER OPERATIONS
    # ========================
    
    def create_user(self, user_id: int, username: str, first_name: str, 
                   last_name: str = None, referred_by: int = None, 
                   signup_bonus: int = 0) -> bool:
        """Create a new user"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO users (
                    user_id, username, first_name, last_name, 
                    tokens, referred_by
                ) VALUES (?, ?, ?, ?, ?, ?)
            """, (user_id, username, first_name, last_name, signup_bonus, referred_by))
            
            # Log signup bonus transaction
            if signup_bonus > 0:
                cursor.execute("""
                    INSERT INTO transactions (
                        user_id, type, amount, description, 
                        balance_before, balance_after
                    ) VALUES (?, 'bonus', ?, 'Welcome signup bonus', 0, ?)
                """, (user_id, signup_bonus, signup_bonus))
            
            conn.commit()
            conn.close()
            
            logger.info(f"✅ Created user {user_id} ({username})")
            return True
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error creating user: {e}")
            return False
    
    def get_user(self, user_id: int) -> Optional[Dict]:
        """Get user by ID"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
            row = cursor.fetchone()
            conn.close()
            
            return dict(row) if row else None
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error getting user: {e}")
            return None
    
    def update_user_activity(self, user_id: int):
        """Update user's last active timestamp"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                UPDATE users 
                SET last_active = CURRENT_TIMESTAMP 
                WHERE user_id = ?
            """, (user_id,))
            
            conn.commit()
            conn.close()
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error updating activity: {e}")
    
    def update_user_level(self, user_id: int, new_level: int) -> bool:
        """Update user's level"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                UPDATE users SET level = ? WHERE user_id = ?
            """, (new_level, user_id))
            
            conn.commit()
            conn.close()
            
            logger.info(f"✅ Updated user {user_id} to level {new_level}")
            return True
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error updating level: {e}")
            return False
    
    def update_user_tokens(self, user_id: int, amount: int, 
                          tx_type: str, description: str,
                          related_id: int = None) -> bool:
        """Update user tokens and log transaction"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            # Get current balance
            cursor.execute("SELECT tokens FROM users WHERE user_id = ?", (user_id,))
            row = cursor.fetchone()
            if not row:
                return False
            
            current_balance = row[0]
            new_balance = current_balance + amount
            
            # Prevent negative balance
            if new_balance < 0:
                logger.warning(f"⚠️ Insufficient balance for user {user_id}")
                return False
            
            # Update balance
            cursor.execute("""
                UPDATE users 
                SET tokens = tokens + ?,
                    total_earned = total_earned + CASE WHEN ? > 0 THEN ? ELSE 0 END,
                    total_spent = total_spent + CASE WHEN ? < 0 THEN ABS(?) ELSE 0 END
                WHERE user_id = ?
            """, (amount, amount, amount, amount, amount, user_id))
            
            # Log transaction
            cursor.execute("""
                INSERT INTO transactions (
                    user_id, type, amount, description, related_id,
                    balance_before, balance_after
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (user_id, tx_type, amount, description, related_id,
                  current_balance, new_balance))
            
            conn.commit()
            conn.close()
            
            logger.info(f"✅ Updated tokens for user {user_id}: {amount:+d}")
            return True
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error updating tokens: {e}")
            return False
    
    def get_leaderboard(self, limit: int = 10, metric: str = 'total_earned') -> List[Dict]:
        """Get top users leaderboard"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            valid_metrics = ['total_earned', 'total_joins', 'level', 'total_referrals']
            if metric not in valid_metrics:
                metric = 'total_earned'
            
            cursor.execute(f"""
                SELECT user_id, username, first_name, {metric}, level, trust_score
                FROM users 
                WHERE is_banned = 0
                ORDER BY {metric} DESC, level DESC
                LIMIT ?
            """, (limit,))
            
            rows = cursor.fetchall()
            conn.close()
            
            return [dict(row) for row in rows]
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error getting leaderboard: {e}")
            return []
    
    # Add placeholder methods for other database operations
    # (Campaign, Transaction, Deposit, Withdrawal, etc.)
    # These would follow similar patterns...
    
    def get_system_stats(self) -> Dict[str, Any]:
        """Get system-wide statistics"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            stats = {}
            
            # User stats
            cursor.execute("SELECT COUNT(*) FROM users")
            stats['total_users'] = cursor.fetchone()[0]
            
            cursor.execute("""
                SELECT COUNT(*) FROM users 
                WHERE last_active >= datetime('now', '-24 hours')
            """)
            stats['active_users_24h'] = cursor.fetchone()[0]
            
            # Campaign stats
            cursor.execute("SELECT COUNT(*) FROM campaigns")
            stats['total_campaigns'] = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM campaigns WHERE status = 'active'")
            stats['active_campaigns'] = cursor.fetchone()[0]
            
            # Token stats
            cursor.execute("SELECT SUM(tokens) FROM users")
            result = cursor.fetchone()[0]
            stats['tokens_in_circulation'] = result if result else 0
            
            # Platform profit
            cursor.execute("""
                SELECT SUM(platform_fee) FROM campaigns 
                WHERE status IN ('active', 'completed')
            """)
            result = cursor.fetchone()[0]
            stats['platform_profit'] = result if result else 0
            
            conn.close()
            
            return stats
            
        except sqlite3.Error as e:
            logger.error(f"❌ Error getting system stats: {e}")
            return {}

# Initialize logger
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
