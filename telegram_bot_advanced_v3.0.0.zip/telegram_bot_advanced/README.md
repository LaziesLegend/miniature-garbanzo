# 🤖 Telegram Member Exchange Bot Pro

<div align="center">

![Bot Logo](assets/bot_logo.png)

**Premium Telegram Member Exchange Platform**

[![Version](https://img.shields.io/badge/version-3.0.0-blue.svg)](https://github.com/yourusername/telegram-bot-pro)
[![Python](https://img.shields.io/badge/python-3.9+-green.svg)](https://www.python.org/)
[![License](https://img.shields.io/badge/license-MIT-yellow.svg)](LICENSE)

</div>

---

## 🌟 Features Overview

### 💰 **Token Economy System**
- **Earn tokens** by joining Telegram channels
- **Create campaigns** to promote your channels
- **Multi-level referral program** (3 levels deep)
- **Daily rewards** with streak bonuses
- **Achievement system** with token rewards

### 🚀 **Campaign Management**
- **Three campaign types**: Standard, Premium, Urgent
- **Real-time tracking** of campaign progress
- **Smart distribution** algorithm
- **Automatic verification** via Telegram API
- **Flexible pricing** with volume discounts

### 👥 **Advanced Referral System**
- **Level 1**: 15 tokens per direct referral
- **Level 2**: 5 tokens per indirect referral  
- **Level 3**: 2 tokens per 3rd level referral
- **Task bonuses**: 5 tokens when referrals complete first task
- **Passive income** generation

### 🛡️ **Security & Anti-Cheat**
- **Trust score system** (0-150 scale)
- **Dynamic penalties** for violations
- **Rate limiting** to prevent spam
- **Verification timeout** protection
- **Pattern detection** for suspicious activity

### 🎮 **Gamification**
- **7-level progression** system (Newbie to Master)
- **Reward multipliers** up to 1.30x
- **Daily tasks** with bonus rewards
- **Achievement unlocks** 
- **Leaderboard** competition

### 💳 **Payment System**
- **Multiple deposit methods**: UPI, PayPal, Crypto
- **Tiered bonuses**: Bronze to Platinum
- **Withdrawal system** with low fees
- **VIP benefits** for top users
- **Admin approval workflow**

### 🏪 **Token Shop**
- **Priority Boost**: Get tasks first
- **Trust Restore**: Recover trust points
- **VIP Status**: Lower fees + priority support
- **Lucky Spin**: Random token rewards

### 📊 **Analytics & Stats**
- **Real-time dashboard** for users
- **Lifetime statistics** tracking
- **Admin panel** with system metrics
- **Performance monitoring**
- **Transaction history**

---

## 📋 Table of Contents

1. [Installation](#-installation)
2. [Configuration](#%EF%B8%8F-configuration)
3. [Usage Guide](#-usage-guide)
4. [Bot Commands](#-bot-commands)
5. [Features Explained](#-features-explained)
6. [Admin Panel](#-admin-panel)
7. [Database Schema](#%EF%B8%8F-database-schema)
8. [API Reference](#-api-reference)
9. [Troubleshooting](#-troubleshooting)
10. [Contributing](#-contributing)

---

## 🚀 Installation

### Prerequisites
- Python 3.9 or higher
- pip package manager
- Telegram Bot Token (from [@BotFather](https://t.me/BotFather))

### Step 1: Clone Repository
```bash
git clone https://github.com/yourusername/telegram-bot-pro.git
cd telegram-bot-pro
```

### Step 2: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 3: Configure Bot
1. Get your bot token from [@BotFather](https://t.me/BotFather)
2. Open `config.py`
3. Replace `BOT_TOKEN` with your actual token
4. Add your Telegram user ID to `ADMIN_IDS`

```python
BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"
ADMIN_IDS = [123456789]  # Your Telegram ID
```

### Step 4: Run Bot
```bash
python main.py
```

✅ **That's it! Your bot is now running!**

---

## ⚙️ Configuration

### Basic Configuration (`config.py`)

#### Token Economy
```python
JOIN_REWARD = 90              # Tokens per join
ADVERTISER_COST = 115         # Cost per member
PLATFORM_FEE = 25             # Auto-calculated
SIGNUP_BONUS = 100            # Welcome bonus
```

#### Referral System
```python
REFERRAL_BONUS_L1 = 15        # Direct referral
REFERRAL_BONUS_L2 = 5         # 2nd level
REFERRAL_BONUS_L3 = 2         # 3rd level
REFERRAL_TASK_BONUS = 5       # First task bonus
```

#### Daily Rewards
```python
DAILY_LOGIN_BONUS = 10
DAILY_STREAK_MULTIPLIER = {
    7: 1.5,    # 7-day streak bonus
    14: 2.0,   # 14-day streak bonus
    30: 3.0    # 30-day streak bonus
}
```

#### Campaign Limits
```python
MIN_CAMPAIGN_MEMBERS = 5
MAX_CAMPAIGN_MEMBERS = 10000
```

### Advanced Configuration

#### Trust Score System
```python
INITIAL_TRUST_SCORE = 100
MIN_TRUST_SCORE = 20
MAX_TRUST_SCORE = 150

TRUST_PENALTIES = {
    "fake_join": -15,
    "leave_after_join": -8,
    "spam_report": -20,
    "multiple_violations": -25,
    "bot_behavior": -50
}

TRUST_REWARDS = {
    "successful_join": 2,
    "campaign_complete": 5,
    "perfect_month": 10,
    "top_contributor": 15
}
```

#### Level System
```python
LEVELS = {
    1: {"joins": 0, "name": "🆕 Newbie", "reward_multiplier": 1.0},
    2: {"joins": 50, "name": "🥉 Bronze", "reward_multiplier": 1.05},
    3: {"joins": 200, "name": "🥈 Silver", "reward_multiplier": 1.10},
    4: {"joins": 500, "name": "🥇 Gold", "reward_multiplier": 1.15},
    5: {"joins": 1000, "name": "💎 Platinum", "reward_multiplier": 1.20},
    6: {"joins": 2500, "name": "👑 Diamond", "reward_multiplier": 1.25},
    7: {"joins": 5000, "name": "🌟 Master", "reward_multiplier": 1.30}
}
```

---

## 📖 Usage Guide

### For Users (Earners)

#### 1. Start the Bot
```
/start
```
- Receive welcome bonus (100 tokens)
- Get unique referral link
- Access main menu

#### 2. Join Campaigns
1. Click "🚀 Earn" button
2. Browse available campaigns
3. Click "Join Campaign"
4. Join the Telegram channel
5. Return and click "Verify"
6. Receive tokens instantly!

#### 3. Refer Friends
1. Click "👥 Referrals"
2. Copy your referral link
3. Share with friends
4. Earn 15+ tokens per referral
5. Earn from their referrals too!

#### 4. Daily Rewards
1. Click "🎁 Daily" button
2. Claim your daily bonus
3. Build streak for multipliers
4. Up to 3x bonus at 30 days!

#### 5. Token Shop
1. Click "🏪 Shop"
2. Browse available items
3. Purchase power-ups
4. Enhance your earnings!

### For Advertisers

#### 1. Create Campaign
```
/campaign @yourchannel 100
```
or
1. Click "📢 Campaign"
2. Choose campaign type
3. Enter channel and member count
4. Confirm payment
5. Campaign activates instantly!

#### 2. Campaign Types

**Standard Campaign**
- Cost: 115 tokens/member
- Priority: Normal
- Delivery: 24-48 hours

**Premium Campaign**
- Cost: 150 tokens/member (+30%)
- Priority: High
- Features: Verified members, faster delivery

**Urgent Campaign**
- Cost: 173 tokens/member (+50%)
- Priority: Highest
- Features: Top priority, 24h guarantee

#### 3. Track Progress
1. Click "📊 My Campaigns"
2. View real-time statistics
3. Monitor member joins
4. Track completion

---

## 🎮 Bot Commands

### User Commands
```
/start              - Start bot & get welcome bonus
/menu               - Show main menu
/stats              - View your statistics
/campaign @ch 100   - Create campaign
/referrals          - Referral program info
/help               - Get help
```

### Admin Commands
```
/admin              - Access admin panel
/broadcast <msg>    - Broadcast to all users
/addtokens <id> <amt> - Add tokens to user
/ban <id> <reason>  - Ban user
/unban <id>         - Unban user
/stats_global       - Global statistics
```

---

## 🎯 Features Explained

### 💰 Token Economy

The bot operates on a self-sustaining token economy:

**Revenue Model:**
- Users earn: 90 tokens per join
- Advertisers pay: 115 tokens per member
- Platform profit: 25 tokens (21.7% margin)

**Example Transaction:**
```
Campaign: 100 members
User earnings: 9,000 tokens (90 × 100)
Advertiser cost: 11,500 tokens (115 × 100)
Platform profit: 2,500 tokens (25 × 100)
```

### 🎮 Level System

Users progress through 7 levels based on total joins:

| Level | Name | Joins Required | Multiplier |
|-------|------|---------------|------------|
| 1 | 🆕 Newbie | 0 | 1.00x |
| 2 | 🥉 Bronze | 50 | 1.05x |
| 3 | 🥈 Silver | 200 | 1.10x |
| 4 | 🥇 Gold | 500 | 1.15x |
| 5 | 💎 Platinum | 1000 | 1.20x |
| 6 | 👑 Diamond | 2500 | 1.25x |
| 7 | 🌟 Master | 5000 | 1.30x |

**Benefits of Leveling Up:**
- Higher reward multipliers
- More active campaigns allowed
- Priority in task distribution
- Exclusive perks

### 👥 Referral System

**3-Level Deep Tracking:**

```
You (Referrer)
  ├─ Friend 1 (Level 1) → You earn 15 tokens
  │   ├─ Their Friend A (Level 2) → You earn 5 tokens
  │   │   └─ Friend of A (Level 3) → You earn 2 tokens
  │   └─ Their Friend B (Level 2) → You earn 5 tokens
  └─ Friend 2 (Level 1) → You earn 15 tokens
```

**Bonus Structure:**
- Signup: 15 tokens (Level 1)
- First Task: +5 tokens bonus
- Indirect referrals: 5 tokens (Level 2)
- 3rd level: 2 tokens (Level 3)

**Example Earnings:**
```
10 direct referrals = 150 tokens
50 indirect referrals (5 each) = 250 tokens
100 3rd level referrals = 200 tokens
Total passive income = 600 tokens!
```

### 🛡️ Trust Score System

**Trust Score Range:** 0-150
- Start: 100 points
- Minimum to earn: 20 points
- Maximum: 150 points (super trusted)

**How to Gain Trust:**
- Successful join: +2 points
- Campaign completion: +5 points
- Perfect month: +10 points
- Top contributor: +15 points

**How to Lose Trust:**
- Fake join: -15 points
- Leave after join: -8 points
- Spam report: -20 points
- Multiple violations: -25 points
- Bot behavior: -50 points

**Trust Score Effects:**
- **0-19**: Cannot earn (banned from tasks)
- **20-49**: Limited tasks available
- **50-79**: Normal access
- **80-100**: Full access
- **100-150**: Priority access + bonuses

### 🎁 Daily Rewards

**Base Reward:** 10 tokens/day

**Streak Bonuses:**
- 7 days: 1.5x bonus (15 tokens)
- 14 days: 2.0x bonus (20 tokens)
- 30 days: 3.0x bonus (30 tokens)

**Example:**
```
Day 1-6: 10 tokens/day = 60 tokens
Day 7-13: 15 tokens/day = 105 tokens
Day 14-29: 20 tokens/day = 320 tokens
Day 30+: 30 tokens/day = ongoing
```

### 🏆 Achievements

**Available Achievements:**

1. **First Steps** (50 tokens)
   - Complete your first join

2. **Referral Master** (500 tokens)
   - Refer 10 users

3. **Advertiser** (100 tokens)
   - Create your first campaign

4. **Loyal Member** (1,000 tokens)
   - Maintain 30-day streak

5. **Top Earner** (2,000 tokens)
   - Earn 10,000 tokens total

### 🏪 Token Shop

**Available Items:**

1. **⚡ Priority Boost (24h)**
   - Cost: 500 tokens
   - Get tasks first for 24 hours
   - Better campaign selection

2. **🛡️ Trust Restore**
   - Cost: 1,000 tokens
   - Restore 20 trust points
   - One-time use

3. **👑 VIP Status (7 days)**
   - Cost: 2,000 tokens
   - Lower withdrawal fees (2% instead of 5%)
   - Priority support
   - Exclusive perks

4. **🎰 Lucky Spin**
   - Cost: 100 tokens
   - Win 100-5,000 tokens
   - Random multiplier

---

## 👑 Admin Panel

### Access
```
/admin
```

### Features

#### 📊 System Statistics
- Total users count
- Active users (24h)
- Campaign metrics
- Token circulation
- Platform profit
- Pending actions

#### 👥 User Management
```
/addtokens <user_id> <amount>    # Add tokens
/removetokens <user_id> <amount> # Remove tokens
/ban <user_id> <reason>          # Ban user
/unban <user_id>                 # Unban user
/setlevel <user_id> <level>      # Set user level
/settrust <user_id> <score>      # Set trust score
```

#### 💳 Deposit Management
- View pending deposits
- Approve/reject deposits
- Add bonus tokens
- Track payment proofs

#### 💸 Withdrawal Management
- Review withdrawal requests
- Process payments
- Fraud prevention checks
- Transaction logging

#### 📢 Broadcasting
```
/broadcast <message>
```
- Send message to all users
- Markdown formatting support
- Image/video support

---

## 🗄️ Database Schema

### Main Tables

#### users
```sql
user_id             INTEGER PRIMARY KEY
username            TEXT
first_name          TEXT
tokens              INTEGER DEFAULT 0
level               INTEGER DEFAULT 1
trust_score         INTEGER DEFAULT 100
total_joins         INTEGER
total_earned        INTEGER
total_spent         INTEGER
total_referrals     INTEGER
referred_by         INTEGER
daily_streak        INTEGER
is_vip              BOOLEAN
```

#### campaigns
```sql
id                  INTEGER PRIMARY KEY
user_id             INTEGER
channel_username    TEXT
target_members      INTEGER
delivered_members   INTEGER
status              TEXT
campaign_type       TEXT
priority            INTEGER
created_at          TIMESTAMP
```

#### campaign_joins
```sql
id                  INTEGER PRIMARY KEY
campaign_id         INTEGER
user_id             INTEGER
verified            BOOLEAN
tokens_earned       INTEGER
joined_at           TIMESTAMP
```

#### transactions
```sql
id                  INTEGER PRIMARY KEY
user_id             INTEGER
type                TEXT
amount              INTEGER
description         TEXT
balance_before      INTEGER
balance_after       INTEGER
created_at          TIMESTAMP
```

#### referrals
```sql
id                  INTEGER PRIMARY KEY
referrer_id         INTEGER
referred_user_id    INTEGER
level               INTEGER
total_bonus_earned  INTEGER
```

### Additional Tables
- deposits
- withdrawals
- achievements
- daily_rewards
- daily_tasks
- shop_purchases
- notifications
- security_logs

---

## 🔌 API Reference

### Database Class

#### User Operations
```python
db.create_user(user_id, username, first_name)
db.get_user(user_id)
db.update_user_tokens(user_id, amount, type, description)
db.update_user_level(user_id, new_level)
db.get_leaderboard(limit)
```

#### Campaign Operations
```python
db.create_campaign(user_id, channel, members, cost)
db.get_available_campaigns(user_id)
db.update_campaign_progress(campaign_id)
db.complete_campaign(campaign_id)
```

#### Transaction Operations
```python
db.log_transaction(user_id, type, amount, description)
db.get_transaction_history(user_id, limit)
```

---

## 🔧 Troubleshooting

### Common Issues

#### Bot doesn't respond
**Solution:**
1. Check bot token is correct
2. Verify bot is running
3. Check internet connection
4. Review logs for errors

#### Buttons not working
**Solution:**
1. Update python-telegram-bot to latest version
2. Check callback query handlers
3. Verify button callback_data matches handlers

#### Database errors
**Solution:**
1. Check database file permissions
2. Verify database schema
3. Run database migrations
4. Check disk space

#### Verification fails
**Solution:**
1. Verify bot is admin in channel
2. Check channel username format
3. Ensure user actually joined
4. Check API rate limits

### Error Logs

Enable detailed logging:
```python
logging.basicConfig(level=logging.DEBUG)
```

---

## 🤝 Contributing

We welcome contributions! Here's how:

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

### Development Guidelines
- Follow PEP 8 style guide
- Add docstrings to functions
- Write unit tests
- Update documentation

---

## 📝 License

This project is licensed under the MIT License - see [LICENSE](LICENSE) file.

---

## 👨‍💻 Support

Need help? Contact us:
- Telegram: [@YourSupport](https://t.me/yoursupport)
- Email: support@yourbot.com
- Issues: [GitHub Issues](https://github.com/yourusername/telegram-bot-pro/issues)

---

## 🙏 Acknowledgments

- [python-telegram-bot](https://github.com/python-telegram-bot/python-telegram-bot)
- Telegram Bot API
- SQLite Database
- All contributors

---

## 📈 Changelog

### Version 3.0.0 (2025-02-08)
- ✨ Complete bot rewrite
- ✅ Fixed all button issues
- 🎨 Added professional logo
- 🚀 Enhanced UI/UX
- 💎 Multi-level referrals (3 levels)
- 🏪 Token shop system
- 🎁 Daily rewards with streaks
- 🏆 Achievement system
- 📊 Advanced analytics
- 💸 Withdrawal system
- 🛡️ Enhanced security
- 🎮 7-level progression
- 🌟 And much more!

---

<div align="center">

**Made with ❤️ by Premium Bot Team**

⭐ Star this repo if you find it useful!

</div>
