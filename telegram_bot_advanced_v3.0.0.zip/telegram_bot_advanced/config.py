"""
🚀 TELEGRAM MEMBER EXCHANGE BOT PRO - ADVANCED CONFIGURATION
Complete Token Economy & Feature System
Version: 3.0.0
"""

import os
from typing import Final
from datetime import datetime

# ========================
# 🤖 BOT CONFIGURATION
# ========================
BOT_TOKEN: Final = "7847819490:AAFAIGl_XqYN_LjGEzR9NkdKEWoaWCy9ZTw"  # Your test token
ADMIN_IDS: Final = [123456789, 987654321]  # Add your Telegram user IDs
BOT_USERNAME: Final = "@YourBotUsername"  # Will be auto-fetched

# ========================
# 💰 TOKEN ECONOMY
# ========================
JOIN_REWARD: Final = 90  # Tokens user earns per join
ADVERTISER_COST: Final = 115  # Tokens advertiser pays per member
PLATFORM_FEE: Final = ADVERTISER_COST - JOIN_REWARD  # Auto-calculated: 25 tokens

MIN_CAMPAIGN_MEMBERS: Final = 5  # Minimum campaign size
MAX_CAMPAIGN_MEMBERS: Final = 10000  # Maximum campaign size
DEFAULT_CAMPAIGN_PRIORITY: Final = 0  # Normal priority

# ========================
# 👥 REFERRAL SYSTEM (Enhanced)
# ========================
REFERRAL_BONUS_L1: Final = 15  # Level 1 referral bonus (increased)
REFERRAL_BONUS_L2: Final = 5   # Level 2 referral bonus (increased)
REFERRAL_BONUS_L3: Final = 2   # Level 3 referral bonus (NEW)
SIGNUP_BONUS: Final = 100      # Welcome bonus for new users (increased)
REFERRAL_TASK_BONUS: Final = 5 # Bonus when referral completes first task (NEW)

# ========================
# 🎁 DAILY REWARDS (NEW)
# ========================
DAILY_LOGIN_BONUS: Final = 10
DAILY_STREAK_MULTIPLIER: Final = {
    7: 1.5,   # 7-day streak: 1.5x bonus
    14: 2.0,  # 14-day streak: 2x bonus
    30: 3.0   # 30-day streak: 3x bonus
}

# ========================
# 💳 DEPOSIT SYSTEM (Enhanced)
# ========================
DEPOSIT_METHODS = {
    "UPI": {
        "enabled": True, 
        "bonus_percent": 5,
        "payment_info": "UPI ID: merchant@upi",
        "min_amount": 100
    },
    "CRYPTO": {
        "enabled": True, 
        "bonus_percent": 10,
        "wallets": {
            "BTC": "bc1q...",
            "ETH": "0x...",
            "USDT": "TR...",
        },
        "min_amount": 500
    },
    "PAYPAL": {
        "enabled": True,
        "bonus_percent": 3,
        "email": "merchant@paypal.com",
        "min_amount": 200
    }
}

DEPOSIT_TIERS = {
    "BRONZE": {"min": 1000, "bonus_percent": 5, "badge": "🥉"},
    "SILVER": {"min": 5000, "bonus_percent": 10, "badge": "🥈"},
    "GOLD": {"min": 10000, "bonus_percent": 15, "badge": "🥇"},
    "PLATINUM": {"min": 50000, "bonus_percent": 20, "badge": "💎"}
}

# ========================
# 🎮 LEVEL SYSTEM (Enhanced)
# ========================
LEVELS = {
    1: {
        "joins": 0, 
        "name": "🆕 Newbie", 
        "reward_multiplier": 1.0,
        "max_campaigns": 2,
        "priority_boost": 0
    },
    2: {
        "joins": 50, 
        "name": "🥉 Bronze", 
        "reward_multiplier": 1.05,
        "max_campaigns": 5,
        "priority_boost": 1
    },
    3: {
        "joins": 200, 
        "name": "🥈 Silver", 
        "reward_multiplier": 1.10,
        "max_campaigns": 10,
        "priority_boost": 2
    },
    4: {
        "joins": 500, 
        "name": "🥇 Gold", 
        "reward_multiplier": 1.15,
        "max_campaigns": 20,
        "priority_boost": 3
    },
    5: {
        "joins": 1000, 
        "name": "💎 Platinum", 
        "reward_multiplier": 1.20,
        "max_campaigns": 50,
        "priority_boost": 5
    },
    6: {
        "joins": 2500, 
        "name": "👑 Diamond", 
        "reward_multiplier": 1.25,
        "max_campaigns": 100,
        "priority_boost": 10
    },
    7: {
        "joins": 5000, 
        "name": "🌟 Master", 
        "reward_multiplier": 1.30,
        "max_campaigns": 9999,
        "priority_boost": 20
    }
}

# ========================
# 🛡️ ANTI-CHEAT SYSTEM (Enhanced)
# ========================
INITIAL_TRUST_SCORE: Final = 100
MIN_TRUST_SCORE: Final = 20
MAX_TRUST_SCORE: Final = 150  # Can go above 100 for super trusted users

TRUST_PENALTIES = {
    "fake_join": -15,           # Increased penalty
    "leave_after_join": -8,     # Increased penalty
    "spam_report": -20,         # Increased penalty
    "multiple_violations": -25, # NEW
    "bot_behavior": -50         # NEW - Heavy penalty
}

TRUST_REWARDS = {
    "successful_join": 2,
    "campaign_complete": 5,
    "perfect_month": 10,        # NEW - 30 days no violations
    "top_contributor": 15       # NEW - Top 10 leaderboard
}

# Rate limiting (Enhanced)
MAX_DAILY_JOINS: Final = 100  # Increased limit
MAX_HOURLY_JOINS: Final = 20  # NEW - Hourly limit
JOIN_COOLDOWN_SECONDS: Final = 30  # Reduced cooldown
VERIFY_TIMEOUT_SECONDS: Final = 300  # 5 minutes to verify
MAX_VERIFICATION_ATTEMPTS: Final = 3

# ========================
# 💸 WITHDRAWAL SYSTEM (Enhanced & Active)
# ========================
WITHDRAWAL_ENABLED: Final = True  # NEW - Enable withdrawals
MIN_WITHDRAWAL: Final = 1000
MAX_WITHDRAWAL: Final = 50000  # NEW - Daily max per user
WITHDRAWAL_FEE_PERCENT: Final = 5
DAILY_WITHDRAWAL_LIMIT: Final = 100000  # Platform-wide limit
WITHDRAWAL_METHODS = ["UPI", "PAYPAL", "CRYPTO"]
WITHDRAWAL_PROCESSING_TIME: Final = "24-48 hours"

# VIP users get reduced fees (NEW)
VIP_WITHDRAWAL_FEE: Final = 2  # 2% for VIP users

# ========================
# 🏆 ACHIEVEMENT SYSTEM (NEW)
# ========================
ACHIEVEMENTS = {
    "first_join": {
        "name": "First Steps",
        "description": "Complete your first join",
        "reward": 50,
        "icon": "🎯"
    },
    "referral_master": {
        "name": "Referral Master",
        "description": "Refer 10 users",
        "reward": 500,
        "icon": "👥"
    },
    "campaign_creator": {
        "name": "Advertiser",
        "description": "Create your first campaign",
        "reward": 100,
        "icon": "📢"
    },
    "loyal_member": {
        "name": "Loyal Member",
        "description": "30-day streak",
        "reward": 1000,
        "icon": "💎"
    },
    "top_earner": {
        "name": "Top Earner",
        "description": "Earn 10,000 tokens",
        "reward": 2000,
        "icon": "🌟"
    }
}

# ========================
# 🎁 BONUS EVENTS (NEW)
# ========================
HAPPY_HOURS = {
    "enabled": True,
    "hours": [12, 18, 20],  # 12 PM, 6 PM, 8 PM
    "multiplier": 1.5       # 1.5x rewards during happy hours
}

WEEKEND_BONUS = {
    "enabled": True,
    "multiplier": 1.25      # 25% extra on weekends
}

# ========================
# 📊 ANALYTICS & TRACKING (Enhanced)
# ========================
LEADERBOARD_TOP_N: Final = 20  # Show top 20 users
LEADERBOARD_REFRESH_INTERVAL: Final = 300  # 5 minutes
ANALYTICS_RETENTION_DAYS: Final = 90  # Keep data for 90 days

# ========================
# 🎨 UI/UX (Enhanced)
# ========================
ITEMS_PER_PAGE: Final = 5  # Pagination
ANIMATION_ENABLED: Final = True
EMOJI_ENABLED: Final = True
LOADING_MESSAGES = [
    "⚡ Processing...",
    "🚀 Loading...",
    "💫 Please wait...",
    "🔄 Working on it..."
]

# ========================
# 🔔 NOTIFICATIONS (NEW)
# ========================
NOTIFICATIONS = {
    "campaign_complete": True,
    "new_referral": True,
    "level_up": True,
    "achievement_unlock": True,
    "deposit_approved": True,
    "withdrawal_processed": True,
    "daily_reward_ready": True,
    "low_balance_warning": True  # When campaign balance is low
}

# ========================
# 🎮 GAMIFICATION (NEW)
# ========================
DAILY_TASKS = {
    "join_campaigns": {
        "target": 5,
        "reward": 100,
        "description": "Join 5 campaigns"
    },
    "refer_friend": {
        "target": 1,
        "reward": 150,
        "description": "Refer 1 friend"
    },
    "create_campaign": {
        "target": 1,
        "reward": 200,
        "description": "Create a campaign"
    }
}

# ========================
# 🏪 TOKEN SHOP (NEW)
# ========================
SHOP_ITEMS = {
    "priority_boost": {
        "name": "⚡ Priority Boost",
        "description": "Get tasks first for 24h",
        "cost": 500,
        "duration_hours": 24
    },
    "trust_restore": {
        "name": "🛡️ Trust Restore",
        "description": "Restore 20 trust points",
        "cost": 1000
    },
    "vip_status": {
        "name": "👑 VIP Status (7 days)",
        "description": "Lower fees + priority support",
        "cost": 2000,
        "duration_days": 7
    },
    "lucky_spin": {
        "name": "🎰 Lucky Spin",
        "description": "Win 100-5000 tokens",
        "cost": 100
    }
}

# ========================
# 💬 MESSAGES (Enhanced)
# ========================
WELCOME_MESSAGE = """
🎉 <b>Welcome to Premium Member Exchange Bot!</b>

💰 <b>Earn Tokens Multiple Ways:</b>
• Join campaigns: {join_reward} tokens per join
• Refer friends: {referral_bonus} tokens per referral
• Daily login: {daily_bonus} tokens
• Complete achievements: Up to 2,000 tokens
• Daily tasks: Extra bonuses

🚀 <b>Create Campaigns:</b>
• Promote your Telegram channels
• Only {advertiser_cost} tokens per member
• Fast & reliable delivery
• Advanced analytics

🎁 <b>Welcome Bonus:</b> {signup_bonus} tokens!
💎 <b>Your Level:</b> Newbie
⭐ <b>Trust Score:</b> 100/100

👇 Choose an option to get started:
"""

CAMPAIGN_CREATED_MESSAGE = """
✅ <b>Campaign Created Successfully!</b>

📊 <b>Campaign Details:</b>
• Channel: @{channel}
• Target Members: {members}
• Cost Per Member: {cost_per} tokens
• Total Cost: {total_cost} tokens
• Platform Fee: {platform_fee} tokens
• Remaining Balance: {balance} tokens

⏳ <b>Status:</b> Active & Distributing
📈 <b>Priority:</b> {priority}

Members will start joining within minutes!
Track progress in "My Campaigns" section.
"""

LEVEL_UP_MESSAGE = """
🎊 <b>LEVEL UP!</b> 🎊

Congratulations! You've reached:
{level_icon} <b>{level_name}</b>

🎁 <b>New Benefits:</b>
• Reward Multiplier: {multiplier}x
• Max Campaigns: {max_campaigns}
• Priority Boost: +{priority}

Keep completing tasks to unlock more rewards!
"""

# ========================
# 🗄️ DATABASE
# ========================
DATABASE_NAME: Final = "bot_premium.db"
BACKUP_ENABLED: Final = True
BACKUP_INTERVAL_HOURS: Final = 6

# ========================
# 🔒 SECURITY (Enhanced)
# ========================
REQUIRE_CHANNEL_VERIFICATION: Final = True
ANTI_SPAM_ENABLED: Final = True
CAPTCHA_ENABLED: Final = False  # For future implementation
TWO_FACTOR_ENABLED: Final = False  # For withdrawal security

# Rate limits
MAX_REQUESTS_PER_MINUTE: Final = 30
BAN_DURATION_HOURS: Final = 24
AUTO_BAN_THRESHOLD: Final = 3  # Ban after 3 violations

# ========================
# 🌍 LOCALIZATION (Ready for expansion)
# ========================
DEFAULT_LANGUAGE: Final = "en"
SUPPORTED_LANGUAGES: Final = ["en", "es", "hi", "ru"]  # Future expansion

# ========================
# 📱 SOCIAL FEATURES (NEW)
# ========================
ENABLE_CHAT: Final = False  # User-to-user chat (future)
ENABLE_GROUPS: Final = False  # User groups (future)
ENABLE_SOCIAL_SHARE: Final = True  # Share achievements

# ========================
# 🎯 CAMPAIGN TYPES (NEW)
# ========================
CAMPAIGN_TYPES = {
    "standard": {
        "name": "Standard Campaign",
        "cost_multiplier": 1.0,
        "priority": 0
    },
    "premium": {
        "name": "Premium Campaign",
        "cost_multiplier": 1.3,
        "priority": 10,
        "features": ["Verified members only", "Faster delivery"]
    },
    "urgent": {
        "name": "Urgent Campaign",
        "cost_multiplier": 1.5,
        "priority": 20,
        "features": ["Top priority", "24h completion guarantee"]
    }
}

# ========================
# 🤖 BOT FEATURES FLAGS
# ========================
FEATURES = {
    "wallet": True,
    "campaigns": True,
    "referrals": True,
    "deposits": True,
    "withdrawals": True,
    "achievements": True,
    "daily_rewards": True,
    "leaderboard": True,
    "shop": True,
    "statistics": True,
    "admin_panel": True
}

# ========================
# 📊 MONITORING (NEW)
# ========================
ENABLE_LOGGING: Final = True
LOG_LEVEL: Final = "INFO"
ENABLE_ERROR_ALERTS: Final = True  # Alert admins on errors
PERFORMANCE_MONITORING: Final = True

# ========================
# 🎨 BRANDING
# ========================
BOT_NAME: Final = "Premium Exchange Bot"
BOT_DESCRIPTION: Final = "Professional Telegram Member Exchange Platform"
SUPPORT_URL: Final = "https://t.me/support"
WEBSITE_URL: Final = "https://yourwebsite.com"

# Version
VERSION: Final = "3.0.0"
RELEASE_DATE: Final = "2025-02-08"

print(f"""
╔══════════════════════════════════════════╗
║   🤖 BOT CONFIGURATION LOADED           ║
║   Version: {VERSION}                      ║
║   Release: {RELEASE_DATE}                ║
╚══════════════════════════════════════════╝
""")
