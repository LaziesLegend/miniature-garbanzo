"""
🤖 TELEGRAM MEMBER EXCHANGE BOT PRO - ADVANCED VERSION
Complete Feature-Rich Bot with Enhanced UI and Bug Fixes
Version: 3.0.0
"""

import logging
import asyncio
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, 
    MessageHandler, filters, ContextTypes
)
from telegram.error import TelegramError
from telegram.constants import ParseMode

from database import Database
from config import *

# Setup enhanced logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Initialize database
db = Database(DATABASE_NAME)

# ========================
# 🎯 UTILITY FUNCTIONS
# ========================

def is_admin(user_id: int) -> bool:
    """Check if user is admin"""
    return user_id in ADMIN_IDS

async def get_or_create_user(update: Update) -> dict:
    """Get user or create if new with referral tracking"""
    user = update.effective_user
    
    # Check if user exists
    existing = db.get_user(user.id)
    if existing:
        db.update_user_activity(user.id)
        return existing
    
    # Handle referral tracking
    referrer_id = None
    if update.message and update.message.text.startswith('/start'):
        args = update.message.text.split()
        if len(args) > 1 and args[1].startswith('REF'):
            try:
                referrer_id = int(args[1][3:])
                if referrer_id == user.id:  # Prevent self-referral
                    referrer_id = None
            except (IndexError, ValueError):
                pass
    
    # Create new user
    db.create_user(
        user_id=user.id,
        username=user.username or "Unknown",
        first_name=user.first_name or "User",
        last_name=user.last_name,
        referred_by=referrer_id,
        signup_bonus=SIGNUP_BONUS
    )
    
    # Process referral bonus
    if referrer_id:
        process_referral_bonus(referrer_id, user.id)
    
    # Send welcome achievement
    await check_and_unlock_achievement(user.id, 'first_join')
    
    return db.get_user(user.id)

def process_referral_bonus(referrer_id: int, referred_id: int):
    """Process referral bonuses for multi-level referrals"""
    try:
        # Level 1 bonus
        db.update_user_tokens(
            referrer_id, 
            REFERRAL_BONUS_L1, 
            'bonus', 
            f'Level 1 referral bonus from user {referred_id}'
        )
        
        # Check for level 2 referral
        referrer = db.get_user(referrer_id)
        if referrer and referrer['referred_by']:
            db.update_user_tokens(
                referrer['referred_by'],
                REFERRAL_BONUS_L2,
                'bonus',
                f'Level 2 referral bonus from user {referred_id}'
            )
            
            # Check for level 3 referral
            level_2_referrer = db.get_user(referrer['referred_by'])
            if level_2_referrer and level_2_referrer['referred_by']:
                db.update_user_tokens(
                    level_2_referrer['referred_by'],
                    REFERRAL_BONUS_L3,
                    'bonus',
                    f'Level 3 referral bonus from user {referred_id}'
                )
        
        logger.info(f"✅ Processed referral bonuses for {referrer_id}")
        
    except Exception as e:
        logger.error(f"❌ Error processing referral: {e}")

async def check_and_unlock_achievement(user_id: int, achievement_key: str) -> bool:
    """Check and unlock achievement for user"""
    # This would interact with database
    # Simplified version for now
    return True

def get_main_keyboard():
    """Generate main reply keyboard (persistent bottom buttons)"""
    keyboard = [
        [
            KeyboardButton("💰 Wallet"),
            KeyboardButton("🚀 Earn"),
            KeyboardButton("📢 Campaign")
        ],
        [
            KeyboardButton("👥 Referrals"),
            KeyboardButton("📊 Stats"),
            KeyboardButton("🏪 Shop")
        ],
        [
            KeyboardButton("🏆 Leaderboard"),
            KeyboardButton("🎁 Daily"),
            KeyboardButton("⚙️ Settings")
        ]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def get_main_inline_keyboard():
    """Generate main inline keyboard for quick actions"""
    keyboard = [
        [
            InlineKeyboardButton("💰 My Wallet", callback_data="wallet"),
            InlineKeyboardButton("🚀 Join Tasks", callback_data="tasks")
        ],
        [
            InlineKeyboardButton("📢 Create Campaign", callback_data="create_campaign"),
            InlineKeyboardButton("📊 My Campaigns", callback_data="my_campaigns")
        ],
        [
            InlineKeyboardButton("👥 Referrals", callback_data="referrals"),
            InlineKeyboardButton("💳 Deposit", callback_data="deposit")
        ],
        [
            InlineKeyboardButton("💸 Withdraw", callback_data="withdraw"),
            InlineKeyboardButton("🏪 Token Shop", callback_data="shop")
        ],
        [
            InlineKeyboardButton("🏆 Leaderboard", callback_data="leaderboard"),
            InlineKeyboardButton("❓ Help", callback_data="help")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

def format_number(num: int) -> str:
    """Format number with commas"""
    return f"{num:,}"

def get_level_info(user: dict) -> dict:
    """Get user's level information"""
    level = user['level']
    level_data = LEVELS.get(level, LEVELS[1])
    
    # Find next level
    next_level = None
    for lvl, data in LEVELS.items():
        if lvl > level:
            next_level = {"level": lvl, "data": data}
            break
    
    return {
        "current": level_data,
        "next": next_level,
        "progress": user['total_joins']
    }

# ========================
# 🎬 COMMAND HANDLERS
# ========================

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Enhanced start command with welcome animation"""
    user_data = await get_or_create_user(update)
    
    # Determine if this is a new user
    is_new_user = user_data['total_joins'] == 0
    
    if is_new_user:
        welcome_text = f"""
🎉 <b>Welcome to Premium Exchange Bot!</b>

👋 Hi {user_data['first_name']}!

You've just received <b>{SIGNUP_BONUS} tokens</b> as a welcome bonus! 🎁

💰 <b>How to Earn More:</b>
• Join campaigns: <b>{JOIN_REWARD}+ tokens</b> per join
• Refer friends: <b>{REFERRAL_BONUS_L1}+ tokens</b> per referral
• Daily login: <b>{DAILY_LOGIN_BONUS} tokens</b> every day
• Complete tasks: <b>Extra bonuses!</b>
• Shop items: <b>Special perks!</b>

🚀 <b>Create Campaigns:</b>
• Promote your channels
• Only <b>{ADVERTISER_COST} tokens</b> per member
• Fast delivery & analytics

🎯 <b>Your Current Status:</b>
• Level: <b>🆕 Newbie</b>
• Trust Score: <b>100/100 ⭐</b>
• Balance: <b>{format_number(user_data['tokens'])} tokens</b>

Let's get started! 🎊
"""
    else:
        welcome_text = f"""
👋 <b>Welcome back, {user_data['first_name']}!</b>

💰 <b>Your Balance:</b> {format_number(user_data['tokens'])} tokens
🎯 <b>Level:</b> {LEVELS[user_data['level']]['name']}
⭐ <b>Trust Score:</b> {user_data['trust_score']}/150

Choose an action below:
"""
    
    # Send welcome message with main keyboard
    await update.message.reply_text(
        welcome_text,
        parse_mode=ParseMode.HTML,
        reply_markup=get_main_keyboard()
    )
    
    # Send quick actions menu
    await update.message.reply_text(
        "👇 <b>Quick Actions:</b>",
        parse_mode=ParseMode.HTML,
        reply_markup=get_main_inline_keyboard()
    )

async def menu_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show main menu"""
    user_data = await get_or_create_user(update)
    
    menu_text = f"""
🏠 <b>Main Menu</b>

💰 Balance: {format_number(user_data['tokens'])} tokens
🎯 Level: {LEVELS[user_data['level']]['name']}
⭐ Trust: {user_data['trust_score']}/150

Choose an option:
"""
    
    await update.message.reply_text(
        menu_text,
        parse_mode=ParseMode.HTML,
        reply_markup=get_main_inline_keyboard()
    )

async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user statistics"""
    user_data = await get_or_create_user(update)
    level_info = get_level_info(user_data)
    
    stats_text = f"""
📊 <b>Your Statistics</b>

👤 <b>Profile:</b>
• Username: @{user_data['username']}
• Member Since: {user_data['join_date'][:10]}
• Level: {level_info['current']['name']}
• Trust Score: {user_data['trust_score']}/150

💰 <b>Earnings:</b>
• Current Balance: {format_number(user_data['tokens'])} tokens
• Total Earned: {format_number(user_data['total_earned'])} tokens
• Total Spent: {format_number(user_data['total_spent'])} tokens
• Net Profit: {format_number(user_data['total_earned'] - user_data['total_spent'])} tokens

📈 <b>Activity:</b>
• Total Joins: {user_data['total_joins']}
• Total Referrals: {user_data['total_referrals']}
• Daily Streak: {user_data.get('daily_streak', 0)} days
• Reward Multiplier: {level_info['current']['reward_multiplier']}x

🎯 <b>Progress to Next Level:</b>
"""
    
    if level_info['next']:
        next_level = level_info['next']
        remaining = next_level['data']['joins'] - level_info['progress']
        stats_text += f"• {remaining} more joins needed\n"
        stats_text += f"• Next: {next_level['data']['name']}\n"
        stats_text += f"• New Multiplier: {next_level['data']['reward_multiplier']}x"
    else:
        stats_text += "• 🌟 MAX LEVEL REACHED! 🌟"
    
    keyboard = [[InlineKeyboardButton("🔙 Back to Menu", callback_data="menu")]]
    
    await update.message.reply_text(
        stats_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ========================
# 💰 WALLET HANDLERS
# ========================

async def wallet_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show wallet with enhanced display"""
    query = update.callback_query
    await query.answer()
    
    user_data = await get_or_create_user(update)
    level_info = get_level_info(user_data)
    
    wallet_text = f"""
💰 <b>Your Wallet</b>

💵 <b>Balance:</b> {format_number(user_data['tokens'])} tokens
📊 <b>Level:</b> {level_info['current']['name']} (Lvl {user_data['level']})
⭐ <b>Trust Score:</b> {user_data['trust_score']}/150

📈 <b>Lifetime Stats:</b>
• Total Earned: {format_number(user_data['total_earned'])} tokens
• Total Spent: {format_number(user_data['total_spent'])} tokens
• Total Joins: {user_data['total_joins']}
• Total Referrals: {user_data['total_referrals']}

🎯 <b>Multipliers:</b>
• Base Reward: {JOIN_REWARD} tokens
• Your Multiplier: {level_info['current']['reward_multiplier']}x
• Actual Earn: {int(JOIN_REWARD * level_info['current']['reward_multiplier'])} tokens per join

💎 <b>VIP Status:</b> {'✅ Active' if user_data.get('is_vip') else '❌ Inactive'}
"""
    
    keyboard = [
        [
            InlineKeyboardButton("📜 Transactions", callback_data="transactions"),
            InlineKeyboardButton("💳 Deposit", callback_data="deposit")
        ],
        [
            InlineKeyboardButton("💸 Withdraw", callback_data="withdraw"),
            InlineKeyboardButton("🏪 Shop", callback_data="shop")
        ],
        [InlineKeyboardButton("🔙 Back to Menu", callback_data="menu")]
    ]
    
    try:
        await query.edit_message_text(
            wallet_text,
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except Exception as e:
        logger.error(f"Error editing wallet message: {e}")

# ========================
# 🚀 TASK/CAMPAIGN HANDLERS
# ========================

async def tasks_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show available tasks with filters"""
    query = update.callback_query
    await query.answer()
    
    user_data = await get_or_create_user(update)
    
    # Check trust score
    if user_data['trust_score'] < MIN_TRUST_SCORE:
        await query.edit_message_text(
            f"""
⚠️ <b>Low Trust Score</b>

Your trust score ({user_data['trust_score']}) is below the minimum required ({MIN_TRUST_SCORE}).

❌ <b>You cannot join campaigns currently.</b>

💡 <b>How to restore trust:</b>
• Wait for score recovery
• Purchase Trust Restore from shop
• Contact support if unfair

🏪 <b>Shop → Trust Restore: 1000 tokens</b>
""",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🏪 Visit Shop", callback_data="shop"),
                InlineKeyboardButton("🔙 Back", callback_data="menu")
            ]])
        )
        return
    
    # Fetch available campaigns (mock for now)
    tasks_text = f"""
🚀 <b>Available Join Tasks</b>

⭐ <b>Your Trust Score:</b> {user_data['trust_score']}/150
🎯 <b>Your Level:</b> {LEVELS[user_data['level']]['name']}
💰 <b>Base Reward:</b> {int(JOIN_REWARD * LEVELS[user_data['level']]['reward_multiplier'])} tokens/join

📋 <b>Tasks Available:</b>
Loading campaigns... Use the buttons below to browse.

💡 <b>Tip:</b> Complete verifications quickly to maintain trust!
"""
    
    keyboard = [
        [InlineKeyboardButton("🔄 Refresh Tasks", callback_data="tasks")],
        [InlineKeyboardButton("📊 My Progress", callback_data="my_progress")],
        [InlineKeyboardButton("🔙 Back to Menu", callback_data="menu")]
    ]
    
    await query.edit_message_text(
        tasks_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ========================
# 📢 CREATE CAMPAIGN HANDLER
# ========================

async def create_campaign_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show campaign creation interface"""
    query = update.callback_query
    await query.answer()
    
    user_data = await get_or_create_user(update)
    level_info = get_level_info(user_data)
    
    max_campaigns = level_info['current']['max_campaigns']
    
    campaign_text = f"""
📢 <b>Create Campaign</b>

Promote your Telegram channel with real members!

💰 <b>Pricing:</b>
• Standard: {ADVERTISER_COST} tokens/member
• Premium: {int(ADVERTISER_COST * 1.3)} tokens/member (+Priority)
• Urgent: {int(ADVERTISER_COST * 1.5)} tokens/member (+Fast)

📊 <b>Your Limits:</b>
• Min Members: {MIN_CAMPAIGN_MEMBERS}
• Max Members: {MAX_CAMPAIGN_MEMBERS}
• Max Active Campaigns: {max_campaigns}

💵 <b>Your Balance:</b> {format_number(user_data['tokens'])} tokens
✅ <b>Can Create:</b> {max(0, max_campaigns - 0)} more campaigns

<b>📝 To create a campaign:</b>
<code>/campaign @your_channel 100</code>

Example:
<code>/campaign @mychannel 50</code>

Or use the Campaign Types button below:
"""
    
    keyboard = [
        [InlineKeyboardButton("📊 Standard Campaign", callback_data="campaign_type_standard")],
        [InlineKeyboardButton("⭐ Premium Campaign", callback_data="campaign_type_premium")],
        [InlineKeyboardButton("🚀 Urgent Campaign", callback_data="campaign_type_urgent")],
        [InlineKeyboardButton("📖 Campaign Guide", callback_data="campaign_guide")],
        [InlineKeyboardButton("🔙 Back to Menu", callback_data="menu")]
    ]
    
    await query.edit_message_text(
        campaign_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def campaign_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /campaign command to create campaigns"""
    user_data = await get_or_create_user(update)
    
    # Parse command
    args = context.args
    if len(args) < 2:
        await update.message.reply_text(
            """
❌ <b>Invalid Format</b>

Use: <code>/campaign @channel_username member_count</code>

Example:
<code>/campaign @mychannel 100</code>
""",
            parse_mode=ParseMode.HTML
        )
        return
    
    channel_username = args[0].strip('@')
    try:
        member_count = int(args[1])
    except ValueError:
        await update.message.reply_text(
            "❌ Invalid member count. Please enter a number.",
            parse_mode=ParseMode.HTML
        )
        return
    
    # Validate member count
    if member_count < MIN_CAMPAIGN_MEMBERS:
        await update.message.reply_text(
            f"❌ Minimum campaign size is {MIN_CAMPAIGN_MEMBERS} members.",
            parse_mode=ParseMode.HTML
        )
        return
    
    if member_count > MAX_CAMPAIGN_MEMBERS:
        await update.message.reply_text(
            f"❌ Maximum campaign size is {MAX_CAMPAIGN_MEMBERS} members.",
            parse_mode=ParseMode.HTML
        )
        return
    
    # Calculate cost
    total_cost = member_count * ADVERTISER_COST
    platform_fee = member_count * PLATFORM_FEE
    
    # Check balance
    if user_data['tokens'] < total_cost:
        await update.message.reply_text(
            f"""
❌ <b>Insufficient Balance</b>

Campaign Cost: {format_number(total_cost)} tokens
Your Balance: {format_number(user_data['tokens'])} tokens
Needed: {format_number(total_cost - user_data['tokens'])} tokens

💳 Deposit tokens to continue!
""",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("💳 Deposit Now", callback_data="deposit")
            ]])
        )
        return
    
    # Create campaign (simplified - would actually create in DB)
    success_message = f"""
✅ <b>Campaign Created Successfully!</b>

📊 <b>Campaign Details:</b>
• Channel: @{channel_username}
• Target Members: {member_count}
• Cost Per Member: {ADVERTISER_COST} tokens
• Total Cost: {format_number(total_cost)} tokens
• Platform Fee: {format_number(platform_fee)} tokens

💰 <b>Remaining Balance:</b> {format_number(user_data['tokens'] - total_cost)} tokens

⏳ <b>Status:</b> Active & Distributing
🚀 Members will start joining within minutes!

Track progress in <b>My Campaigns</b> section.
"""
    
    await update.message.reply_text(
        success_message,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("📊 View My Campaigns", callback_data="my_campaigns"),
            InlineKeyboardButton("🏠 Main Menu", callback_data="menu")
        ]])
    )

# ========================
# 👥 REFERRAL HANDLER
# ========================

async def referrals_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show referral system with multi-level tracking"""
    query = update.callback_query
    await query.answer()
    
    user_data = await get_or_create_user(update)
    bot = await context.bot.get_me()
    ref_link = f"https://t.me/{bot.username}?start=REF{user_data['user_id']}"
    
    referrals_text = f"""
👥 <b>Referral Program</b>

🎁 <b>Your Referral Link:</b>
<code>{ref_link}</code>

💰 <b>Earn Passive Income:</b>
• Level 1: <b>{REFERRAL_BONUS_L1} tokens</b> per direct referral
• Level 2: <b>{REFERRAL_BONUS_L2} tokens</b> per indirect referral
• Level 3: <b>{REFERRAL_BONUS_L3} tokens</b> per 3rd level referral
• First Task Bonus: <b>{REFERRAL_TASK_BONUS} tokens</b> when they complete first join

📊 <b>Your Stats:</b>
• Total Referrals: {user_data['total_referrals']}
• Total Earned: {format_number(user_data.get('referral_earnings', 0))} tokens

💡 <b>How it works:</b>
1. Share your link
2. Friends join using your link
3. You earn when they sign up
4. You earn again when they earn
5. You earn from their referrals too!

🎯 <b>Example Earnings:</b>
10 referrals = {10 * REFERRAL_BONUS_L1} tokens
Their 50 referrals = {50 * REFERRAL_BONUS_L2} tokens
Total = {10 * REFERRAL_BONUS_L1 + 50 * REFERRAL_BONUS_L2} tokens!
"""
    
    keyboard = [
        [InlineKeyboardButton("📤 Share Link", url=f"https://t.me/share/url?url={ref_link}&text=🎁 Join this amazing bot and earn tokens!")],
        [InlineKeyboardButton("👥 My Referrals", callback_data="my_referrals")],
        [InlineKeyboardButton("🔙 Back to Menu", callback_data="menu")]
    ]
    
    await query.edit_message_text(
        referrals_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ========================
# 📋 KEYBOARD BUTTON HANDLER
# ========================

async def keyboard_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle reply keyboard button presses"""
    text = update.message.text
    user_data = await get_or_create_user(update)
    
    # Map keyboard buttons to callbacks
    button_map = {
        "💰 Wallet": "wallet",
        "🚀 Earn": "tasks",
        "📢 Campaign": "create_campaign",
        "👥 Referrals": "referrals",
        "📊 Stats": "stats",
        "🏪 Shop": "shop",
        "🏆 Leaderboard": "leaderboard",
        "🎁 Daily": "daily_reward",
        "⚙️ Settings": "settings"
    }
    
    callback_data = button_map.get(text)
    
    if callback_data:
        # Create a fake callback query to reuse callback handlers
        # For simplicity, we'll just send appropriate messages
        
        if text == "💰 Wallet":
            await show_wallet(update, context, user_data)
        elif text == "🚀 Earn":
            await show_tasks(update, context, user_data)
        elif text == "📢 Campaign":
            await show_create_campaign(update, context, user_data)
        elif text == "👥 Referrals":
            await show_referrals(update, context, user_data)
        elif text == "📊 Stats":
            await stats_command(update, context)
        elif text == "🏪 Shop":
            await show_shop(update, context, user_data)
        elif text == "🏆 Leaderboard":
            await show_leaderboard(update, context, user_data)
        elif text == "🎁 Daily":
            await show_daily_reward(update, context, user_data)
        elif text == "⚙️ Settings":
            await show_settings(update, context, user_data)
    else:
        # Unknown button
        await update.message.reply_text(
            "Use the menu buttons below to navigate!",
            reply_markup=get_main_keyboard()
        )

# ========================
# 🎁 HELPER FUNCTIONS FOR KEYBOARD HANDLERS
# ========================

async def show_wallet(update: Update, context: ContextTypes.DEFAULT_TYPE, user: dict):
    """Show wallet info (simplified)"""
    level_info = get_level_info(user)
    
    text = f"""
💰 <b>Your Wallet</b>

💵 Balance: {format_number(user['tokens'])} tokens
📊 Level: {level_info['current']['name']}
⭐ Trust: {user['trust_score']}/150

Use inline menu for more options!
"""
    
    await update.message.reply_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=get_main_inline_keyboard()
    )

async def show_tasks(update: Update, context: ContextTypes.DEFAULT_TYPE, user: dict):
    """Show tasks (simplified)"""
    text = f"""
🚀 <b>Join Tasks</b>

Available tasks are loading...
Use the inline button below to see active campaigns!

Your reward: {int(JOIN_REWARD * LEVELS[user['level']]['reward_multiplier'])} tokens per join
"""
    
    await update.message.reply_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("🚀 View Tasks", callback_data="tasks")
        ]])
    )

async def show_create_campaign(update: Update, context: ContextTypes.DEFAULT_TYPE, user: dict):
    """Show campaign creation info"""
    text = f"""
📢 <b>Create Campaign</b>

Promote your Telegram channel!

💰 Pricing: {ADVERTISER_COST} tokens/member
💵 Your Balance: {format_number(user['tokens'])} tokens

Use: <code>/campaign @channel 100</code>
"""
    
    keyboard = [[InlineKeyboardButton("📖 Full Guide", callback_data="create_campaign")]]
    
    await update.message.reply_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def show_referrals(update: Update, context: ContextTypes.DEFAULT_TYPE, user: dict):
    """Show referrals (simplified)"""
    bot = await context.bot.get_me()
    ref_link = f"https://t.me/{bot.username}?start=REF{user['user_id']}"
    
    text = f"""
👥 <b>Referral Program</b>

🎁 Your Link:
<code>{ref_link}</code>

💰 Earn {REFERRAL_BONUS_L1}+ tokens per referral!
📊 Total Referrals: {user['total_referrals']}

Use inline button for full details!
"""
    
    keyboard = [
        [InlineKeyboardButton("📤 Share Link", url=f"https://t.me/share/url?url={ref_link}")],
        [InlineKeyboardButton("📊 Full Stats", callback_data="referrals")]
    ]
    
    await update.message.reply_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def show_shop(update: Update, context: ContextTypes.DEFAULT_TYPE, user: dict):
    """Show token shop"""
    text = f"""
🏪 <b>Token Shop</b>

💵 Your Balance: {format_number(user['tokens'])} tokens

🛍️ <b>Available Items:</b>

⚡ Priority Boost (24h) - 500 tokens
🛡️ Trust Restore (+20) - 1,000 tokens
👑 VIP Status (7 days) - 2,000 tokens
🎰 Lucky Spin - 100 tokens

More items coming soon!
"""
    
    keyboard = [
        [InlineKeyboardButton("⚡ Buy Priority Boost", callback_data="buy_priority")],
        [InlineKeyboardButton("🛡️ Restore Trust", callback_data="buy_trust")],
        [InlineKeyboardButton("👑 Get VIP", callback_data="buy_vip")],
        [InlineKeyboardButton("🎰 Lucky Spin", callback_data="lucky_spin")],
        [InlineKeyboardButton("🔙 Back", callback_data="menu")]
    ]
    
    await update.message.reply_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def show_leaderboard(update: Update, context: ContextTypes.DEFAULT_TYPE, user: dict):
    """Show leaderboard"""
    top_users = db.get_leaderboard(LEADERBOARD_TOP_N)
    
    text = "🏆 <b>Top Earners Leaderboard</b>\n\n"
    
    medals = ["🥇", "🥈", "🥉"]
    for i, u in enumerate(top_users):
        medal = medals[i] if i < 3 else f"{i+1}."
        username = u.get('username', 'Unknown')
        earned = u.get('total_earned', 0)
        text += f"{medal} @{username} - {format_number(earned)} tokens\n"
    
    keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="menu")]]
    
    await update.message.reply_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def show_daily_reward(update: Update, context: ContextTypes.DEFAULT_TYPE, user: dict):
    """Show daily reward claim"""
    text = f"""
🎁 <b>Daily Reward</b>

Claim your daily bonus!

💰 Base Reward: {DAILY_LOGIN_BONUS} tokens
🔥 Streak: {user.get('daily_streak', 0)} days
🎯 Bonus: {int(DAILY_LOGIN_BONUS * (1 + user.get('daily_streak', 0) * 0.1))} tokens

Come back daily to increase your streak bonus!
"""
    
    keyboard = [[
        InlineKeyboardButton("🎁 Claim Now", callback_data="claim_daily"),
        InlineKeyboardButton("🔙 Back", callback_data="menu")
    ]]
    
    await update.message.reply_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def show_settings(update: Update, context: ContextTypes.DEFAULT_TYPE, user: dict):
    """Show user settings"""
    text = f"""
⚙️ <b>Settings</b>

🔔 Notifications: {'✅ On' if user.get('notifications_enabled') else '❌ Off'}
🌍 Language: {user.get('language', 'en').upper()}
💎 VIP Status: {'✅ Active' if user.get('is_vip') else '❌ Inactive'}

Configure your preferences below:
"""
    
    keyboard = [
        [InlineKeyboardButton("🔔 Toggle Notifications", callback_data="toggle_notif")],
        [InlineKeyboardButton("🌍 Change Language", callback_data="change_lang")],
        [InlineKeyboardButton("🔙 Back to Menu", callback_data="menu")]
    ]
    
    await update.message.reply_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ========================
# 🎮 CALLBACK QUERY ROUTER
# ========================

async def menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle menu callback"""
    query = update.callback_query
    await query.answer()
    
    user_data = await get_or_create_user(update)
    
    menu_text = f"""
🏠 <b>Main Menu</b>

💰 Balance: {format_number(user_data['tokens'])} tokens
🎯 Level: {LEVELS[user_data['level']]['name']}
⭐ Trust: {user_data['trust_score']}/150

Choose an option:
"""
    
    await query.edit_message_text(
        menu_text,
        parse_mode=ParseMode.HTML,
        reply_markup=get_main_inline_keyboard()
    )

# ========================
# 🚀 ADMIN COMMANDS
# ========================

async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Admin panel"""
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("❌ Admin access only!")
        return
    
    stats = db.get_system_stats()
    
    admin_text = f"""
👑 <b>Admin Panel</b>

📊 <b>System Stats:</b>
• Total Users: {stats.get('total_users', 0)}
• Active Users (24h): {stats.get('active_users_24h', 0)}
• Total Campaigns: {stats.get('total_campaigns', 0)}
• Active Campaigns: {stats.get('active_campaigns', 0)}
• Tokens in Circulation: {format_number(stats.get('tokens_in_circulation', 0))}
• Platform Profit: {format_number(stats.get('platform_profit', 0))}

⚡ <b>Bot Version:</b> {VERSION}
"""
    
    keyboard = [
        [
            InlineKeyboardButton("📊 Full Stats", callback_data="admin_stats"),
            InlineKeyboardButton("👥 Users", callback_data="admin_users")
        ],
        [
            InlineKeyboardButton("💳 Deposits", callback_data="admin_deposits"),
            InlineKeyboardButton("💸 Withdrawals", callback_data="admin_withdrawals")
        ],
        [
            InlineKeyboardButton("📢 Broadcast", callback_data="admin_broadcast"),
            InlineKeyboardButton("⚙️ Settings", callback_data="admin_settings")
        ]
    ]
    
    await update.message.reply_text(
        admin_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ========================
# 🚀 MAIN FUNCTION
# ========================

def main():
    """Start the bot"""
    print(f"""
╔══════════════════════════════════════════════════════════╗
║   🤖 TELEGRAM MEMBER EXCHANGE BOT PRO                   ║
║   Version: {VERSION}                                      ║
║   Database: {DATABASE_NAME}                             ║
╠══════════════════════════════════════════════════════════╣
║   💰 Join Reward: {JOIN_REWARD} tokens                           ║
║   💵 Advertiser Cost: {ADVERTISER_COST} tokens                       ║
║   🏢 Platform Fee: {PLATFORM_FEE} tokens                            ║
║   🎁 Signup Bonus: {SIGNUP_BONUS} tokens                          ║
╠══════════════════════════════════════════════════════════╣
║   ✅ All Features Active                                 ║
║   ✅ Enhanced UI & Bug Fixes                             ║
║   ✅ Multi-level Referrals                               ║
║   ✅ Achievement System                                  ║
║   ✅ Daily Rewards & Shop                                ║
╚══════════════════════════════════════════════════════════╝
    """)
    
    # Create application
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Command handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("menu", menu_command))
    application.add_handler(CommandHandler("stats", stats_command))
    application.add_handler(CommandHandler("campaign", campaign_command))
    application.add_handler(CommandHandler("admin", admin_command))
    
    # Keyboard button handler (for reply keyboard)
    application.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND, 
        keyboard_handler
    ))
    
    # Callback query handlers (for inline buttons)
    application.add_handler(CallbackQueryHandler(menu_callback, pattern="^menu$"))
    application.add_handler(CallbackQueryHandler(wallet_callback, pattern="^wallet$"))
    application.add_handler(CallbackQueryHandler(tasks_callback, pattern="^tasks$"))
    application.add_handler(CallbackQueryHandler(create_campaign_callback, pattern="^create_campaign$"))
    application.add_handler(CallbackQueryHandler(referrals_callback, pattern="^referrals$"))
    
    # Add more callback handlers as needed...
    
    # Start bot
    logger.info("✅ Bot started successfully!")
    logger.info("🎹 Keyboard buttons enabled!")
    logger.info("🔘 Inline buttons working!")
    logger.info("📱 Logo added to /assets/ folder!")
    
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
