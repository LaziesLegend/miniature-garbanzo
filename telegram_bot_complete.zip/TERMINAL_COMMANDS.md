# 🚀 Terminal Commands - Run Bot from Phone or Desktop

## 📱 FOR PHONE (Termux App)

### Step 1: Install Termux
Download **Termux** from Google Play Store (free app)

### Step 2: Open Termux and Run These Commands

```bash
# Update package manager
apt update && apt upgrade -y

# Install Python 3
apt install python3 -y

# Install git (for cloning)
apt install git -y

# Install zip tools
apt install unzip -y

# Go to home directory
cd ~

# Create a folder for the bot
mkdir bot_project
cd bot_project

# Download the bot (you'll need to transfer the zip file first)
# If you have the zip file, unzip it:
unzip telegram_bot_complete.zip

# Go into telegram_bot directory
cd telegram_bot

# Install dependencies
pip install -r requirements.txt

# Run the bot
python main.py
```

### Troubleshooting on Termux
```bash
# If you get permission errors
chmod +x main.py

# If pip install is slow
pip install -r requirements.txt --no-cache-dir

# Check Python version
python3 --version

# Check if bot is running (from another terminal)
ps aux | grep main.py
```

---

## 💻 FOR DESKTOP (Windows, Mac, Linux)

### Windows Command Prompt / PowerShell

```cmd
# Navigate to where you want to put the bot
cd Desktop

# Create folder
mkdir telegram_bot
cd telegram_bot

# Extract zip file (or use Windows file explorer)
# Right-click zip -> Extract All

# Navigate into the extracted folder
cd telegram_bot

# Install dependencies
pip install -r requirements.txt

# Run the bot
python main.py
```

### Mac Terminal / Linux Terminal

```bash
# Navigate to home directory
cd ~

# Create folder
mkdir telegram_bot
cd telegram_bot

# Extract zip
unzip telegram_bot_complete.zip

# Go into telegram_bot directory
cd telegram_bot

# Create virtual environment (recommended)
python3 -m venv venv

# Activate virtual environment
# On Mac/Linux:
source venv/bin/activate
# On Windows (if using WSL):
source venv/Scripts/activate

# Install dependencies
pip install -r requirements.txt

# Run the bot
python3 main.py
```

---

## 🔧 QUICK COMMAND REFERENCE

### Extract ZIP
```bash
# Linux/Mac/Termux
unzip telegram_bot_complete.zip

# Windows (PowerShell)
Expand-Archive -Path telegram_bot_complete.zip -DestinationPath .
```

### Navigate to Bot
```bash
cd telegram_bot
cd telegram_bot  # Yes, twice! First to the extracted folder, then to bot folder
```

### Install Dependencies
```bash
pip install -r requirements.txt
```

### Run Bot
```bash
python main.py        # Any OS
# OR
python3 main.py       # If 'python' doesn't work
```

### Stop Bot
```bash
# Press Ctrl + C in the terminal
```

### Check if Running
```bash
# Linux/Mac/Termux
ps aux | grep main.py

# Windows PowerShell
Get-Process | findstr python
```

---

## 📋 COMPLETE STEP-BY-STEP FOR PHONE (Termux)

### Assuming you have telegram_bot_complete.zip file:

```bash
# 1. Update system
apt update && apt upgrade -y

# 2. Install Python
apt install python3 -y

# 3. Install tools
apt install git zip unzip -y

# 4. Create working directory
cd ~
mkdir telegram_bot
cd telegram_bot

# 5. Copy zip file here and extract
# (Transfer the zip file to Termux first)
unzip telegram_bot_complete.zip

# 6. Navigate to bot folder
cd telegram_bot
cd telegram_bot

# 7. Show what's inside
ls -la

# 8. Install Python packages
pip install --upgrade pip
pip install -r requirements.txt

# 9. Run the bot!
python main.py
```

**You should see:**
```
INFO:telegram.ext._application:Application started
INFO:root:Starting bot...
INFO:root:Database initialized successfully
```

---

## 🎮 ONCE BOT IS RUNNING

### Open Another Terminal/Tab and:

```bash
# Check logs
tail -f bot.log

# View database
sqlite3 bot_database.db ".tables"

# Stop the bot
# Press Ctrl + C in the terminal where bot is running
```

---

## 💡 TIPS FOR PHONE (Termux)

### Keep Bot Running After Closing App
```bash
# Install screen or tmux
apt install screen

# Run bot in screen session
screen -S botname
python main.py

# Press Ctrl+A then D to detach

# Reattach later
screen -r botname
```

### Or use nohup
```bash
nohup python main.py &
# Bot runs in background even if you close terminal
```

### Keep Screen On
- In Termux settings: Enable "Keep Screen On"
- Or use Android settings to prevent auto-sleep

### Monitor Bot Performance
```bash
# Check if bot is running
pgrep -f main.py

# View memory usage
free -h

# View CPU usage
top
```

---

## 🔐 SECURITY TIPS

### Never share these:
- Bot token in config.py
- Admin ID
- UPI credentials

### Keep backups:
```bash
# Backup database
cp bot_database.db bot_database.backup.db

# Backup entire bot
cp -r telegram_bot telegram_bot_backup
```

---

## 📊 WHAT YOU'LL SEE

When bot starts successfully:

```
2025-02-10 14:00:00,000 - root - INFO - Database initialized successfully
2025-02-10 14:00:01,000 - root - INFO - Starting bot...
2025-02-10 14:00:02,000 - telegram.ext._application - INFO - Application started
2025-02-10 14:00:02,500 - root - INFO - Bot is polling for messages
```

---

## ❌ COMMON ERRORS & FIXES

### Error: "ModuleNotFoundError: No module named 'telegram'"
```bash
pip install python-telegram-bot
pip install -r requirements.txt
```

### Error: "python: command not found"
```bash
# Use python3 instead
python3 main.py
```

### Error: "sqlite3 database is locked"
```bash
# Delete the database and restart
rm bot_database.db
python main.py
```

### Error: "Permission denied"
```bash
# On Linux/Mac/Termux
chmod +x main.py
chmod +x config.py
python main.py
```

### Error: "Address already in use"
```bash
# Another instance is running, find and kill it
# Linux/Mac/Termux:
pkill -f main.py
python main.py

# Windows:
taskkill /IM python.exe /F
python main.py
```

---

## 🎯 MINIMAL COMMANDS (Copy & Paste)

### For Termux (Phone):
```bash
apt update && apt upgrade -y && apt install python3 unzip -y && mkdir -p ~/bot && cd ~/bot && unzip telegram_bot_complete.zip && cd telegram_bot/telegram_bot && pip install -r requirements.txt && python main.py
```

### For Linux/Mac Desktop:
```bash
mkdir ~/telegram_bot && cd ~/telegram_bot && unzip telegram_bot_complete.zip && cd telegram_bot && python3 -m venv venv && source venv/bin/activate && pip install -r requirements.txt && python3 main.py
```

### For Windows PowerShell:
```powershell
mkdir telegram_bot; cd telegram_bot; Expand-Archive -Path telegram_bot_complete.zip -DestinationPath .; cd telegram_bot; pip install -r requirements.txt; python main.py
```

---

## 📱 PHONE-SPECIFIC TIPS

### Running on Phone Continuously:

**Option 1: Using Screen**
```bash
apt install screen
screen -S mybotname
python main.py
# Detach: Ctrl+A then D
# Reattach: screen -r mybotname
```

**Option 2: Using tmux**
```bash
apt install tmux
tmux new-session -d -s mybotname "python main.py"
tmux attach -t mybotname
```

**Option 3: Using Supervisor (Advanced)**
```bash
apt install supervisor
# Create config file and set bot to run as service
```

---

## 🔄 RESTART BOT

```bash
# Stop current instance
# Press Ctrl+C

# Clear screen
clear

# Restart
python main.py
```

---

## 📈 MONITOR PERFORMANCE

```bash
# View real-time stats
top

# View memory
free -m

# View disk space
df -h

# View running processes
ps aux | grep python
```

---

## 🎓 NEXT COMMANDS AFTER BOT STARTS

### Test Bot is Working
```bash
# From another terminal, test the bot:
# Send /start to your bot on Telegram
# You should see it respond
```

### View Logs
```bash
# If you want to see bot logs:
tail -100 bot.log

# Or run in foreground for live logs:
python main.py
```

### Check Database
```bash
# See all tables
sqlite3 bot_database.db ".tables"

# See users
sqlite3 bot_database.db "SELECT * FROM users LIMIT 5;"

# See campaigns
sqlite3 bot_database.db "SELECT * FROM campaigns LIMIT 5;"
```

---

## ✅ VERIFICATION COMMANDS

```bash
# Check Python installed
python3 --version

# Check pip installed
pip --version

# Check if bot files exist
ls -la telegram_bot/

# Check if requirements installed
pip list | grep telegram

# Check if bot is running
ps aux | grep main.py
```

---

## 🛑 STOP & UNINSTALL

### Stop Bot
```bash
# Press Ctrl+C in the terminal
```

### Uninstall on Phone
```bash
# Delete bot folder
rm -rf ~/bot

# Uninstall Termux app
# (Remove from Play Store or app manager)
```

### Uninstall on Desktop
```bash
# Delete bot folder
rm -rf ~/telegram_bot

# Deactivate virtual environment (if used)
deactivate

# Optional: Uninstall Python
# (Use system package manager or control panel)
```

---

## 📞 QUICK HELP

```bash
# Show Python help
python --help

# Show pip help
pip help

# Show available commands
help

# Exit Python interactive mode
exit()
```

---

## 🎉 YOU'RE READY!

Just follow the commands above for your device and the bot will be running in minutes!

**Questions?**
- Read the documentation files included
- Check the error message and google it
- Review QUICK_REFERENCE.md for code help

**Good luck! 🚀**
