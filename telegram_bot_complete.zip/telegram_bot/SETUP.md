# Quick Start Guide

## 1. Setup Environment

```bash
# Navigate to bot directory
cd telegram_bot

# Create virtual environment (optional but recommended)
python -m venv venv

# Activate virtual environment
# On Linux/Mac:
source venv/bin/activate
# On Windows:
# venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

## 2. Configure Bot

Edit `config.py` and update:

```python
BOT_TOKEN = "8438773973:AAHzZUXMjUw6whaZI9pG7wr3IWGj30xiFww"  # Already set
ADMIN_ID = 8301300209  # Already set
UPI_ID = "dummy@paytm"  # Change to your UPI
BOT_USERNAME = "YourBotUsername"  # Set your bot's username
```

## 3. Run the Bot

```bash
python main.py
```

You should see:
```
INFO:telegram.ext._application:Application started
INFO:root:Starting bot...
INFO:root:Database initialized successfully
```

## 4. Test the Bot

1. Open Telegram
2. Find your bot by username or `/start`
3. Test features:
   - 💰 Earn (view available tasks)
   - 📢 Create Campaign (requires tokens)
   - 💳 Deposit (UPI payment simulation)
   - 👤 Profile (view stats)

## 5. Admin Commands (from ADMIN_ID account)

```
/stats              - View platform statistics
/pending            - View pending deposits
/approve_deposit 1  - Approve deposit with ID 1
/reject_deposit 1   - Reject deposit with ID 1
/broadcast Hello    - Send message to all users
/reply 1 Thanks     - Reply to support ticket 1
```

## Production Deployment

### Using systemd (Linux)

Create `/etc/systemd/system/telegram-bot.service`:

```ini
[Unit]
Description=Telegram Token Bot
After=network.target

[Service]
Type=simple
User=botuser
WorkingDirectory=/home/botuser/telegram_bot
ExecStart=/home/botuser/telegram_bot/venv/bin/python main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Then:
```bash
sudo systemctl enable telegram-bot
sudo systemctl start telegram-bot
sudo systemctl status telegram-bot
```

### Using Docker

Create `Dockerfile`:

```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["python", "main.py"]
```

Build and run:
```bash
docker build -t telegram-bot .
docker run -d --name telegram-bot telegram-bot
```

### Using Heroku

1. Create `Procfile`:
```
worker: python main.py
```

2. Deploy:
```bash
heroku login
heroku create your-bot-name
git push heroku main
```

## Database Management

### SQLite (Default)
```bash
# View database
sqlite3 bot_database.db

# Backup
cp bot_database.db bot_database.backup.db

# Restore
cp bot_database.backup.db bot_database.db
```

### PostgreSQL (Recommended for production)

Update `config.py`:
```python
DATABASE_URL = "postgresql+asyncpg://user:password@localhost:5432/bot_db"
```

Create database:
```bash
psql -U postgres -c "CREATE DATABASE bot_db;"
```

## Monitoring

### View Logs

If running with systemd:
```bash
journalctl -u telegram-bot -f
```

If running in terminal:
```bash
python main.py 2>&1 | tee bot.log
```

### Check Bot Health

Get statistics:
```
/stats
```

This shows:
- Total users
- Active campaigns
- Tokens in circulation
- Platform earnings
- Pending deposits

## Troubleshooting

### Bot not responding
1. Check if running: `ps aux | grep main.py`
2. Check logs for errors
3. Verify BOT_TOKEN is correct
4. Ensure internet connection

### Database locked
```bash
# Reset database
rm bot_database.db
python main.py
```

### Memory leaks
```bash
# Monitor memory usage
watch -n 1 'ps aux | grep main.py'
```

### High CPU usage
- Check for infinite loops in handlers
- Optimize database queries
- Consider using PostgreSQL

## File Checklist

Ensure you have:
- ✅ `config.py` - Configuration
- ✅ `database.py` - Database models
- ✅ `main.py` - Main application
- ✅ `requirements.txt` - Dependencies
- ✅ `handlers/` - All handler files
- ✅ `services/` - Service files
- ✅ `README.md` - Documentation

## Next Steps

1. **Customize tokens**: Edit `CAMPAIGN_CREATOR_COST` etc. in config.py
2. **Add payment methods**: Extend `handlers/deposit.py`
3. **Analytics**: Add logging to track user behavior
4. **Notifications**: Add alerts for deposits
5. **Auto-approval**: Implement automatic deposit verification

## Support URLs

- **Telegram Bot API**: https://core.telegram.org/bots/api
- **python-telegram-bot**: https://python-telegram-bot.readthedocs.io
- **SQLAlchemy**: https://docs.sqlalchemy.org

## Success Indicators

After startup, you should see:
```
✅ Database initialized
✅ Bot polling started
✅ Ready for user connections
```

Users can:
- ✅ Join and create account
- ✅ Navigate menus
- ✅ Complete tasks (with token verification)
- ✅ Create campaigns (with balance check)
- ✅ Submit deposits
- ✅ Use referral system

Admins can:
- ✅ View stats
- ✅ Approve deposits
- ✅ Manage campaigns
- ✅ Broadcast messages
- ✅ Reply to support

---

**You're all set!** The bot is ready for use. 🎉
