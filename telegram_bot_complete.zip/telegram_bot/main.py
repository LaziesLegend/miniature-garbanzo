import logging
import asyncio
from telegram import Update
from telegram.ext import (
    Application, CommandHandler, MessageHandler, CallbackQueryHandler, 
    ConversationHandler, filters
)
from config import BOT_TOKEN, ADMIN_ID, States
from database import init_database, close_database, get_db
from handlers.start import start, home, help_command, error_handler, get_main_keyboard
from handlers.home import home_menu, main_button_handler
from handlers.earn import (
    earn_menu, show_available_tasks, show_campaign_detail, 
    verify_task, show_completed_tasks
)
from handlers.campaign import (
    campaign_menu, start_create_campaign, receive_channel, 
    receive_members, confirm_campaign, show_my_campaigns, CAMPAIGN_CHANNEL, 
    CAMPAIGN_MEMBERS, CAMPAIGN_CONFIRM
)
from handlers.deposit import (
    deposit_menu, start_upi_deposit, receive_deposit_amount, 
    receive_deposit_txid, DEPOSIT_AMOUNT, DEPOSIT_TXID
)
from handlers.referral import referral_menu, show_referral_list, copy_referral_link
from handlers.profile import profile_menu
from handlers.helpdesk import (
    helpdesk_menu, show_faq, start_contact_support, 
    receive_support_message, SUPPORT_MESSAGE
)
from handlers.admin import (
    admin_stats, show_pending_deposits, approve_deposit_cmd, 
    reject_deposit_cmd, pause_campaign_cmd, resume_campaign_cmd, 
    broadcast_cmd, reply_support_cmd
)

# Setup logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def main() -> None:
    """Start the bot"""
    # Create application
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Initialize database before starting
    async def init():
        await init_database()
    
    # Run initialization
    asyncio.run(init())
    
    # Command handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("stats", admin_stats))
    application.add_handler(CommandHandler("pending", show_pending_deposits))
    application.add_handler(CommandHandler("approve_deposit", approve_deposit_cmd))
    application.add_handler(CommandHandler("reject_deposit", reject_deposit_cmd))
    application.add_handler(CommandHandler("pause_campaign", pause_campaign_cmd))
    application.add_handler(CommandHandler("resume_campaign", resume_campaign_cmd))
    application.add_handler(CommandHandler("broadcast", broadcast_cmd))
    application.add_handler(CommandHandler("reply", reply_support_cmd))
    
    # Campaign creation conversation
    campaign_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_create_campaign, pattern="^create_campaign$")],
        states={
            CAMPAIGN_CHANNEL: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_channel),
                CallbackQueryHandler(campaign_menu, pattern="^campaign_menu$")
            ],
            CAMPAIGN_MEMBERS: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_members),
                CallbackQueryHandler(campaign_menu, pattern="^campaign_menu$")
            ],
            CAMPAIGN_CONFIRM: [
                CallbackQueryHandler(confirm_campaign, pattern="^confirm_campaign$|^campaign_menu$"),
            ],
        },
        fallbacks=[],
    )
    
    # Deposit conversation
    deposit_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_upi_deposit, pattern="^upi_deposit$")],
        states={
            DEPOSIT_AMOUNT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_deposit_amount),
                CallbackQueryHandler(deposit_menu, pattern="^deposit_menu$")
            ],
            DEPOSIT_TXID: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_deposit_txid),
                CallbackQueryHandler(deposit_menu, pattern="^deposit_menu$")
            ],
        },
        fallbacks=[],
    )
    
    # Support conversation
    support_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_contact_support, pattern="^contact_support$")],
        states={
            SUPPORT_MESSAGE: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_support_message),
                CallbackQueryHandler(helpdesk_menu, pattern="^helpdesk_menu$")
            ],
        },
        fallbacks=[],
    )
    
    # Add conversations
    application.add_handler(campaign_conv)
    application.add_handler(deposit_conv)
    application.add_handler(support_conv)
    
    # Main menu button handler
    application.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND,
        main_button_handler
    ))
    
    # Callback query handlers
    application.add_handler(CallbackQueryHandler(home_menu, pattern="^home_menu$"))
    application.add_handler(CallbackQueryHandler(earn_menu, pattern="^earn_menu$"))
    application.add_handler(CallbackQueryHandler(show_available_tasks, pattern="^available_tasks$"))
    application.add_handler(CallbackQueryHandler(show_completed_tasks, pattern="^my_tasks$"))
    application.add_handler(CallbackQueryHandler(verify_task, pattern="^verify_task_"))
    application.add_handler(CallbackQueryHandler(campaign_menu, pattern="^campaign_menu$"))
    application.add_handler(CallbackQueryHandler(show_my_campaigns, pattern="^my_campaigns$"))
    application.add_handler(CallbackQueryHandler(deposit_menu, pattern="^deposit_menu$"))
    application.add_handler(CallbackQueryHandler(referral_menu, pattern="^referral_menu$"))
    application.add_handler(CallbackQueryHandler(show_referral_list, pattern="^referral_list$"))
    application.add_handler(CallbackQueryHandler(copy_referral_link, pattern="^copy_referral_link$"))
    application.add_handler(CallbackQueryHandler(profile_menu, pattern="^profile_menu$"))
    application.add_handler(CallbackQueryHandler(helpdesk_menu, pattern="^helpdesk_menu$"))
    application.add_handler(CallbackQueryHandler(show_faq, pattern="^faq_menu$"))
    
    # Error handler
    application.add_error_handler(error_handler)
    
    # Setup post_stop to close database
    async def post_stop(app):
        await close_database()
    
    application.post_stop.append(post_stop)
    
    # Start bot
    logger.info("Starting bot...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
