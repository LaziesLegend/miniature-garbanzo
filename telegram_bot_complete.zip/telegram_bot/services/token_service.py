import logging
from sqlalchemy import select, and_
from database import User, Campaign, CompletedTask, Deposit, get_db
from config import (
    CAMPAIGN_CREATOR_COST, TASK_COMPLETER_REWARD, 
    PLATFORM_MARGIN, REFERRAL_BONUS
)

logger = logging.getLogger(__name__)

class TokenService:
    """Service for managing token operations"""
    
    @staticmethod
    async def get_user_balance(telegram_id: int) -> int:
        """Get user's current token balance"""
        db = await get_db()
        async with await db.get_session() as session:
            stmt = select(User).where(User.telegram_id == telegram_id)
            result = await session.execute(stmt)
            user = result.scalars().first()
            return user.balance if user else 0
    
    @staticmethod
    async def add_tokens(telegram_id: int, amount: int, reason: str = "manual"):
        """Add tokens to user balance"""
        if amount <= 0:
            raise ValueError("Amount must be positive")
        
        db = await get_db()
        async with await db.get_session() as session:
            stmt = select(User).where(User.telegram_id == telegram_id)
            result = await session.execute(stmt)
            user = result.scalars().first()
            
            if not user:
                logger.error(f"User {telegram_id} not found")
                return False
            
            user.balance += amount
            user.total_earned += amount
            await session.commit()
            logger.info(f"Added {amount} tokens to {telegram_id} ({reason})")
            return True
    
    @staticmethod
    async def deduct_tokens(telegram_id: int, amount: int, reason: str = "manual") -> bool:
        """Deduct tokens from user balance"""
        if amount <= 0:
            raise ValueError("Amount must be positive")
        
        db = await get_db()
        async with await db.get_session() as session:
            stmt = select(User).where(User.telegram_id == telegram_id)
            result = await session.execute(stmt)
            user = result.scalars().first()
            
            if not user:
                logger.error(f"User {telegram_id} not found")
                return False
            
            if user.balance < amount:
                logger.warning(f"Insufficient balance for {telegram_id}")
                return False
            
            user.balance -= amount
            user.total_spent += amount
            await session.commit()
            logger.info(f"Deducted {amount} tokens from {telegram_id} ({reason})")
            return True
    
    @staticmethod
    async def complete_task(user_telegram_id: int, campaign_id: int) -> dict:
        """
        Complete a task and handle token transfer
        Returns: {success: bool, message: str, tokens_earned: int}
        """
        db = await get_db()
        
        async with await db.get_session() as session:
            # Get user
            user_stmt = select(User).where(User.telegram_id == user_telegram_id)
            user_result = await session.execute(user_stmt)
            user = user_result.scalars().first()
            
            if not user:
                return {"success": False, "message": "User not found", "tokens_earned": 0}
            
            # Get campaign
            campaign_stmt = select(Campaign).where(Campaign.id == campaign_id)
            campaign_result = await session.execute(campaign_stmt)
            campaign = campaign_result.scalars().first()
            
            if not campaign:
                return {"success": False, "message": "Campaign not found", "tokens_earned": 0}
            
            # Check if user is campaign creator
            if user.id == campaign.creator_id:
                return {"success": False, "message": "Cannot complete own campaign", "tokens_earned": 0}
            
            # Check if already completed
            check_stmt = select(CompletedTask).where(
                and_(CompletedTask.user_id == user.id, CompletedTask.campaign_id == campaign_id)
            )
            check_result = await session.execute(check_stmt)
            if check_result.scalars().first():
                return {"success": False, "message": "Task already completed", "tokens_earned": 0}
            
            # Create completed task
            completed_task = CompletedTask(user_id=user.id, campaign_id=campaign_id)
            session.add(completed_task)
            
            # Update user balance
            user.balance += TASK_COMPLETER_REWARD
            user.total_earned += TASK_COMPLETER_REWARD
            
            # Update campaign
            campaign.remaining_slots -= 1
            if campaign.remaining_slots == 0:
                campaign.status = "completed"
            
            # Check for referral bonus
            if user.referred_by:
                referrer_stmt = select(User).where(User.id == user.referred_by)
                referrer_result = await session.execute(referrer_stmt)
                referrer = referrer_result.scalars().first()
                
                # Check if this is user's first completed task
                user_tasks_stmt = select(CompletedTask).where(CompletedTask.user_id == user.id)
                user_tasks_result = await session.execute(user_tasks_stmt)
                task_count = len(user_tasks_result.scalars().all())
                
                if referrer and task_count == 1:  # First task
                    referrer.balance += REFERRAL_BONUS
                    referrer.total_earned += REFERRAL_BONUS
                    logger.info(f"Added referral bonus to {referrer.telegram_id}")
            
            await session.commit()
            
            logger.info(f"Task completed: user={user_telegram_id}, campaign={campaign_id}")
            return {
                "success": True,
                "message": "Task completed successfully",
                "tokens_earned": TASK_COMPLETER_REWARD
            }
    
    @staticmethod
    async def get_user_stats(telegram_id: int) -> dict:
        """Get user statistics"""
        db = await get_db()
        
        async with await db.get_session() as session:
            # Get user
            user_stmt = select(User).where(User.telegram_id == telegram_id)
            user_result = await session.execute(user_stmt)
            user = user_result.scalars().first()
            
            if not user:
                return None
            
            # Get active campaigns
            campaign_stmt = select(Campaign).where(
                and_(Campaign.creator_id == user.id, Campaign.status == "active")
            )
            campaign_result = await session.execute(campaign_stmt)
            active_campaigns = len(campaign_result.scalars().all())
            
            # Get completed tasks
            tasks_stmt = select(CompletedTask).where(CompletedTask.user_id == user.id)
            tasks_result = await session.execute(tasks_stmt)
            completed_tasks = len(tasks_result.scalars().all())
            
            # Get referral count
            referral_stmt = select(User).where(User.referred_by == user.id)
            referral_result = await session.execute(referral_stmt)
            referral_count = len(referral_result.scalars().all())
            
            return {
                "balance": user.balance,
                "total_earned": user.total_earned,
                "total_spent": user.total_spent,
                "active_campaigns": active_campaigns,
                "completed_tasks": completed_tasks,
                "referral_count": referral_count,
                "referral_earnings": referral_count * REFERRAL_BONUS  # Approximate
            }

class CampaignService:
    """Service for managing campaigns"""
    
    @staticmethod
    async def create_campaign(creator_telegram_id: int, channel_username: str, total_slots: int) -> dict:
        """
        Create a new campaign
        Returns: {success: bool, message: str, campaign_id: int}
        """
        db = await get_db()
        
        # Validate input
        if total_slots <= 0:
            return {"success": False, "message": "Invalid slot count", "campaign_id": None}
        
        total_cost = total_slots * CAMPAIGN_CREATOR_COST
        
        async with await db.get_session() as session:
            # Get creator
            creator_stmt = select(User).where(User.telegram_id == creator_telegram_id)
            creator_result = await session.execute(creator_stmt)
            creator = creator_result.scalars().first()
            
            if not creator:
                return {"success": False, "message": "User not found", "campaign_id": None}
            
            # Check balance
            if creator.balance < total_cost:
                return {
                    "success": False,
                    "message": f"Insufficient balance. Need {total_cost}, have {creator.balance}",
                    "campaign_id": None
                }
            
            # Deduct tokens
            creator.balance -= total_cost
            creator.total_spent += total_cost
            
            # Create campaign
            campaign = Campaign(
                creator_id=creator.id,
                channel_username=channel_username,
                total_slots=total_slots,
                remaining_slots=total_slots,
                status="active"
            )
            session.add(campaign)
            await session.commit()
            
            logger.info(f"Campaign created: id={campaign.id}, creator={creator_telegram_id}")
            
            return {
                "success": True,
                "message": "Campaign created successfully",
                "campaign_id": campaign.id
            }
    
    @staticmethod
    async def get_active_campaigns(user_telegram_id: int) -> list:
        """Get all active campaigns user hasn't completed"""
        db = await get_db()
        
        async with await db.get_session() as session:
            # Get user
            user_stmt = select(User).where(User.telegram_id == user_telegram_id)
            user_result = await session.execute(user_stmt)
            user = user_result.scalars().first()
            
            if not user:
                return []
            
            # Get active campaigns user didn't create and hasn't completed
            campaign_stmt = select(Campaign).where(
                and_(
                    Campaign.status == "active",
                    Campaign.creator_id != user.id,
                    Campaign.remaining_slots > 0
                )
            )
            campaign_result = await session.execute(campaign_stmt)
            campaigns = campaign_result.scalars().all()
            
            # Filter out campaigns user already completed
            filtered_campaigns = []
            for campaign in campaigns:
                check_stmt = select(CompletedTask).where(
                    and_(CompletedTask.user_id == user.id, CompletedTask.campaign_id == campaign.id)
                )
                check_result = await session.execute(check_stmt)
                if not check_result.scalars().first():
                    filtered_campaigns.append(campaign)
            
            return filtered_campaigns
    
    @staticmethod
    async def get_user_campaigns(user_telegram_id: int) -> list:
        """Get all campaigns created by user"""
        db = await get_db()
        
        async with await db.get_session() as session:
            # Get user
            user_stmt = select(User).where(User.telegram_id == user_telegram_id)
            user_result = await session.execute(user_stmt)
            user = user_result.scalars().first()
            
            if not user:
                return []
            
            # Get campaigns
            campaign_stmt = select(Campaign).where(Campaign.creator_id == user.id)
            campaign_result = await session.execute(campaign_stmt)
            return campaign_result.scalars().all()
    
    @staticmethod
    async def get_campaign_by_id(campaign_id: int) -> Campaign:
        """Get campaign by ID"""
        db = await get_db()
        
        async with await db.get_session() as session:
            stmt = select(Campaign).where(Campaign.id == campaign_id)
            result = await session.execute(stmt)
            return result.scalars().first()

class DepositService:
    """Service for managing deposits"""
    
    @staticmethod
    async def create_deposit(user_telegram_id: int, amount: int, txid: str) -> dict:
        """Create a new deposit request"""
        db = await get_db()
        
        if amount <= 0:
            return {"success": False, "message": "Amount must be positive"}
        
        async with await db.get_session() as session:
            # Get user
            user_stmt = select(User).where(User.telegram_id == user_telegram_id)
            user_result = await session.execute(user_stmt)
            user = user_result.scalars().first()
            
            if not user:
                return {"success": False, "message": "User not found"}
            
            # Check for duplicate txid
            check_stmt = select(Deposit).where(Deposit.txid == txid)
            check_result = await session.execute(check_stmt)
            if check_result.scalars().first():
                return {"success": False, "message": "Transaction ID already exists"}
            
            # Create deposit
            deposit = Deposit(user_id=user.id, amount=amount, txid=txid, status="pending")
            session.add(deposit)
            await session.commit()
            
            logger.info(f"Deposit created: user={user_telegram_id}, amount={amount}")
            
            return {"success": True, "message": "Deposit request created"}
    
    @staticmethod
    async def approve_deposit(deposit_id: int) -> dict:
        """Approve a deposit"""
        db = await get_db()
        
        async with await db.get_session() as session:
            # Get deposit
            deposit_stmt = select(Deposit).where(Deposit.id == deposit_id)
            deposit_result = await session.execute(deposit_stmt)
            deposit = deposit_result.scalars().first()
            
            if not deposit:
                return {"success": False, "message": "Deposit not found"}
            
            if deposit.status != "pending":
                return {"success": False, "message": "Deposit already processed"}
            
            # Update deposit status
            deposit.status = "approved"
            
            # Get user and add tokens
            user = deposit.user
            user.balance += deposit.amount
            user.total_earned += deposit.amount
            
            await session.commit()
            
            logger.info(f"Deposit approved: user={user.telegram_id}, amount={deposit.amount}")
            
            return {
                "success": True,
                "message": f"Deposit approved: {deposit.amount} tokens added",
                "user_telegram_id": user.telegram_id,
                "amount": deposit.amount
            }
    
    @staticmethod
    async def reject_deposit(deposit_id: int) -> dict:
        """Reject a deposit"""
        db = await get_db()
        
        async with await db.get_session() as session:
            # Get deposit
            deposit_stmt = select(Deposit).where(Deposit.id == deposit_id)
            deposit_result = await session.execute(deposit_stmt)
            deposit = deposit_result.scalars().first()
            
            if not deposit:
                return {"success": False, "message": "Deposit not found"}
            
            if deposit.status != "pending":
                return {"success": False, "message": "Deposit already processed"}
            
            # Update deposit status
            deposit.status = "rejected"
            await session.commit()
            
            logger.info(f"Deposit rejected: deposit_id={deposit_id}")
            
            return {"success": True, "message": "Deposit rejected"}
    
    @staticmethod
    async def get_pending_deposits() -> list:
        """Get all pending deposits"""
        db = await get_db()
        
        async with await db.get_session() as session:
            stmt = select(Deposit).where(Deposit.status == "pending")
            result = await session.execute(stmt)
            return result.scalars().all()

class AdminService:
    """Service for admin operations"""
    
    @staticmethod
    async def get_stats() -> dict:
        """Get platform statistics"""
        db = await get_db()
        
        async with await db.get_session() as session:
            # Total users
            user_stmt = select(User)
            user_result = await session.execute(user_stmt)
            total_users = len(user_result.scalars().all())
            
            # Active campaigns
            campaign_stmt = select(Campaign).where(Campaign.status == "active")
            campaign_result = await session.execute(campaign_stmt)
            active_campaigns = len(campaign_result.scalars().all())
            
            # Total tokens in circulation
            circulation_stmt = select(User)
            circulation_result = await session.execute(circulation_stmt)
            users = circulation_result.scalars().all()
            total_tokens = sum(u.balance for u in users)
            
            # Pending deposits
            deposit_stmt = select(Deposit).where(Deposit.status == "pending")
            deposit_result = await session.execute(deposit_stmt)
            pending_deposits = len(deposit_result.scalars().all())
            
            # Platform earnings (15 tokens per completed task)
            task_stmt = select(CompletedTask)
            task_result = await session.execute(task_stmt)
            total_tasks = len(task_result.scalars().all())
            platform_earnings = total_tasks * PLATFORM_MARGIN
            
            return {
                "total_users": total_users,
                "active_campaigns": active_campaigns,
                "total_tokens_in_circulation": total_tokens,
                "pending_deposits": pending_deposits,
                "total_completed_tasks": total_tasks,
                "platform_earnings": platform_earnings
            }
