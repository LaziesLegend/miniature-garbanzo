import os
from dotenv import load_dotenv

load_dotenv()

# Bot Configuration
BOT_TOKEN = "8438773973:AAHzZUXMjUw6whaZI9pG7wr3IWGj30xiFww"
ADMIN_ID = 8301300209

# Database Configuration
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///bot_database.db")

# Token Economy Rules
CAMPAIGN_CREATOR_COST = 115  # Cost per member slot for campaign creator
TASK_COMPLETER_REWARD = 100  # Reward for task completion
PLATFORM_MARGIN = 15  # Platform keeps this many tokens per task
REFERRAL_BONUS = 10  # Bonus tokens for referrer when referred user completes first task

# UPI Configuration (for manual deposits)
UPI_ID = "dummy@paytm"  # Replace with actual UPI ID
UPI_NAME = "Bot Support"

# Deep Linking
BOT_USERNAME = "YourBotUsername"  # Replace with actual bot username

# FSM States
class States:
    WAITING_CHANNEL = 1
    WAITING_MEMBERS = 2
    CONFIRMING_CAMPAIGN = 3
    WAITING_DEPOSIT_AMOUNT = 4
    WAITING_DEPOSIT_TXID = 5
    WAITING_SUPPORT_MESSAGE = 6
    WAITING_ADMIN_REPLY = 7

# Logging Configuration
LOG_LEVEL = "INFO"
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
