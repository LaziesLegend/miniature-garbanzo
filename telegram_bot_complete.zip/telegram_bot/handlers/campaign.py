import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from services.token_service import TokenService, CampaignService
from config import CAMPAIGN_CREATOR_COST, TASK_COMPLETER_REWARD, PLATFORM_MARGIN

logger = logging.getLogger(__name__)

CAMPAIGN_CHANNEL = 1
CAMPAIGN_MEMBERS = 2
CAMPAIGN_CONFIRM = 3

async def campaign_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show campaign menu"""
    user = update.effective_user
    balance = await TokenService.get_user_balance(user.id)
    
    keyboard = [
        [InlineKeyboardButton("➕ Create New Campaign", callback_data="create_campaign")],
        [InlineKeyboardButton("📋 My Campaigns", callback_data="my_campaigns")],
        [InlineKeyboardButton("⬅️ Back", callback_data="home_menu")],
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    message = (
        f"📢 <b>Create Campaign</b>\n\n"
        f"💰 Your Balance: <b>{balance} tokens</b>\n\n"
        f"💡 <b>How it works:</b>\n"
        f"• You pay 115 tokens per member slot\n"
        f"• Each task completer earns 100 tokens\n"
        f"• Platform keeps 15 tokens per task\n\n"
        f"📊 <b>Example:</b>\n"
        f"If you create a campaign for 10 members:\n"
        f"Cost: 1,150 tokens (115 × 10)\n"
        f"Each completer earns: 100 tokens"
    )
    
    if update.callback_query:
        await update.callback_query.edit_message_text(message, parse_mode="HTML", reply_markup=reply_markup)
    else:
        await update.message.reply_text(message, parse_mode="HTML", reply_markup=reply_markup)

async def start_create_campaign(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Start campaign creation flow"""
    query = update.callback_query
    
    message = (
        "📱 <b>Step 1: Channel Username</b>\n\n"
        "Please enter the channel username (without @)\n"
        "Example: <code>mychannel</code>"
    )
    
    keyboard = [[InlineKeyboardButton("⬅️ Cancel", callback_data="campaign_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(message, parse_mode="HTML", reply_markup=reply_markup)
    
    return CAMPAIGN_CHANNEL

async def receive_channel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Receive channel username"""
    if update.callback_query:
        # Cancel was clicked
        if update.callback_query.data == "campaign_menu":
            await campaign_menu(update, context)
            return ConversationHandler.END
    
    # Get channel username
    channel = update.message.text.strip().lower()
    
    if not channel or ' ' in channel:
        await update.message.reply_text("❌ Invalid channel username. Please try again.")
        return CAMPAIGN_CHANNEL
    
    context.user_data['campaign_channel'] = channel
    
    # Ask for members
    message = (
        "👥 <b>Step 2: Number of Members</b>\n\n"
        f"How many members do you want to join?\n"
        f"Cost will be: <b>members × 115 tokens</b>"
    )
    
    keyboard = [[InlineKeyboardButton("⬅️ Cancel", callback_data="campaign_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(message, parse_mode="HTML", reply_markup=reply_markup)
    
    return CAMPAIGN_MEMBERS

async def receive_members(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Receive member count"""
    if update.callback_query:
        # Cancel was clicked
        if update.callback_query.data == "campaign_menu":
            await campaign_menu(update, context)
            return ConversationHandler.END
    
    try:
        members = int(update.message.text.strip())
        
        if members <= 0 or members > 10000:
            await update.message.reply_text("❌ Please enter a valid number (1-10000)")
            return CAMPAIGN_MEMBERS
        
        context.user_data['campaign_members'] = members
        
        # Calculate cost
        total_cost = members * CAMPAIGN_CREATOR_COST
        
        # Show confirmation
        message = (
            f"✅ <b>Campaign Summary</b>\n\n"
            f"📱 <b>Channel:</b> @{context.user_data['campaign_channel']}\n"
            f"👥 <b>Member Slots:</b> {members}\n"
            f"💰 <b>Total Cost:</b> {total_cost} tokens\n\n"
            f"<b>Breakdown:</b>\n"
            f"• You pay: 115 tokens per member\n"
            f"• Each user earns: 100 tokens\n"
            f"• Platform keeps: 15 tokens per completion\n\n"
            f"Confirm to proceed?"
        )
        
        keyboard = [
            [InlineKeyboardButton("✅ Confirm", callback_data="confirm_campaign"),
             InlineKeyboardButton("❌ Cancel", callback_data="campaign_menu")],
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(message, parse_mode="HTML", reply_markup=reply_markup)
        
        return CAMPAIGN_CONFIRM
    
    except ValueError:
        await update.message.reply_text("❌ Please enter a valid number")
        return CAMPAIGN_MEMBERS

async def confirm_campaign(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Confirm campaign creation"""
    query = update.callback_query
    user = query.from_user
    
    if query.data == "campaign_menu":
        await campaign_menu(update, context)
        return ConversationHandler.END
    
    channel = context.user_data.get('campaign_channel')
    members = context.user_data.get('campaign_members')
    
    # Check balance
    balance = await TokenService.get_user_balance(user.id)
    total_cost = members * CAMPAIGN_CREATOR_COST
    
    if balance < total_cost:
        await query.answer(
            f"❌ Insufficient balance. Need {total_cost}, have {balance}",
            show_alert=True
        )
        await campaign_menu(update, context)
        return ConversationHandler.END
    
    # Create campaign
    result = await CampaignService.create_campaign(user.id, channel, members)
    
    if result['success']:
        await query.answer(f"✅ Campaign created successfully!", show_alert=True)
        
        message = (
            f"🎉 <b>Campaign Created!</b>\n\n"
            f"📱 <b>Channel:</b> @{channel}\n"
            f"👥 <b>Slots:</b> {members}\n"
            f"💰 <b>Cost:</b> {total_cost} tokens\n"
            f"📊 <b>Campaign ID:</b> {result['campaign_id']}\n\n"
            f"Users can now join your channel and earn tokens!"
        )
        
        keyboard = [[InlineKeyboardButton("📋 View My Campaigns", callback_data="my_campaigns")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(message, parse_mode="HTML", reply_markup=reply_markup)
    else:
        await query.answer(f"❌ {result['message']}", show_alert=True)
    
    return ConversationHandler.END

async def show_my_campaigns(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show user's campaigns"""
    user = update.effective_user
    
    campaigns = await CampaignService.get_user_campaigns(user.id)
    
    if not campaigns:
        keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="campaign_menu")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        message = "📋 You haven't created any campaigns yet."
        await update.callback_query.edit_message_text(message, reply_markup=reply_markup)
        return
    
    campaign_list = "\n".join([
        f"{'🟢' if c.status == 'active' else '🔴'} "
        f"<b>@{c.channel_username}</b> - "
        f"Slots: {c.remaining_slots}/{c.total_slots}"
        for c in campaigns
    ])
    
    keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="campaign_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    message = (
        f"📋 <b>My Campaigns</b>\n\n"
        f"Total: {len(campaigns)}\n\n"
        f"{campaign_list}"
    )
    
    await update.callback_query.edit_message_text(message, parse_mode="HTML", reply_markup=reply_markup)
