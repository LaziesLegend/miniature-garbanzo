import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from services.token_service import TokenService

logger = logging.getLogger(__name__)

async def home_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show home menu"""
    user = update.effective_user
    balance = await TokenService.get_user_balance(user.id)
    
    keyboard = [
        [InlineKeyboardButton("💰 Earn", callback_data="earn_menu"),
         InlineKeyboardButton("📢 Create Campaign", callback_data="campaign_menu")],
        [InlineKeyboardButton("💳 Deposit", callback_data="deposit_menu"),
         InlineKeyboardButton("👥 Referral", callback_data="referral_menu")],
        [InlineKeyboardButton("🆘 Help Desk", callback_data="helpdesk_menu"),
         InlineKeyboardButton("👤 Profile", callback_data="profile_menu")],
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    message = (
        f"🏠 <b>Home</b>\n\n"
        f"💰 Current Balance: <b>{balance} tokens</b>\n\n"
        f"Select an option below:"
    )
    
    if update.callback_query:
        await update.callback_query.edit_message_text(message, parse_mode="HTML", reply_markup=reply_markup)
    else:
        await update.message.reply_text(message, parse_mode="HTML", reply_markup=reply_markup)

async def main_button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle main menu button presses"""
    text = update.message.text
    
    if text == "🏠 Home":
        await home_menu(update, context)
    elif text == "💰 Earn":
        from handlers.earn import earn_menu
        await earn_menu(update, context)
    elif text == "📢 Create Campaign":
        from handlers.campaign import campaign_menu
        await campaign_menu(update, context)
    elif text == "💳 Deposit":
        from handlers.deposit import deposit_menu
        await deposit_menu(update, context)
    elif text == "👥 Referral":
        from handlers.referral import referral_menu
        await referral_menu(update, context)
    elif text == "🆘 Help Desk":
        from handlers.helpdesk import helpdesk_menu
        await helpdesk_menu(update, context)
    elif text == "👤 Profile":
        from handlers.profile import profile_menu
        await profile_menu(update, context)
