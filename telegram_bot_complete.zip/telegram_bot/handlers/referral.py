import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from sqlalchemy import select
from database import User, get_db
from services.token_service import TokenService
from config import BOT_USERNAME

logger = logging.getLogger(__name__)

async def referral_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show referral menu"""
    user = update.effective_user
    
    db = await get_db()
    async with await db.get_session() as session:
        # Get user
        user_stmt = select(User).where(User.telegram_id == user.id)
        user_result = await session.execute(user_stmt)
        user_obj = user_result.scalars().first()
        
        if not user_obj:
            await update.callback_query.edit_message_text("❌ User not found")
            return
        
        referral_code = user_obj.referral_code
        
        # Get referral count
        referral_stmt = select(User).where(User.referred_by == user_obj.id)
        referral_result = await session.execute(referral_stmt)
        referred_users = referral_result.scalars().all()
        
        referral_count = len(referred_users)
        referral_earnings = referral_count * 10  # 10 tokens per referral
    
    referral_link = f"https://t.me/{BOT_USERNAME}?start={referral_code}"
    
    message = (
        f"👥 <b>Referral Program</b>\n\n"
        f"📊 <b>Your Stats:</b>\n"
        f"• Total Referrals: {referral_count}\n"
        f"• Total Earnings: {referral_earnings} tokens\n\n"
        f"💡 <b>How it works:</b>\n"
        f"• Share your referral link\n"
        f"• When someone joins and completes their first task\n"
        f"• You earn 10 bonus tokens automatically!\n\n"
        f"🔗 <b>Your Referral Link:</b>\n"
        f"<code>{referral_link}</code>"
    )
    
    keyboard = [
        [InlineKeyboardButton("📋 Referral List", callback_data="referral_list"),
         InlineKeyboardButton("📋 Copy Link", callback_data="copy_referral_link")],
        [InlineKeyboardButton("⬅️ Back", callback_data="home_menu")],
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(message, parse_mode="HTML", reply_markup=reply_markup)
    else:
        await update.message.reply_text(message, parse_mode="HTML", reply_markup=reply_markup)

async def show_referral_list(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show list of referred users"""
    query = update.callback_query
    user = query.from_user
    
    db = await get_db()
    async with await db.get_session() as session:
        # Get user
        user_stmt = select(User).where(User.telegram_id == user.id)
        user_result = await session.execute(user_stmt)
        user_obj = user_result.scalars().first()
        
        if not user_obj:
            await query.answer("❌ User not found", show_alert=True)
            return
        
        # Get referred users
        referral_stmt = select(User).where(User.referred_by == user_obj.id)
        referral_result = await session.execute(referral_stmt)
        referred_users = referral_result.scalars().all()
    
    if not referred_users:
        keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="referral_menu")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        message = "📋 You haven't referred anyone yet."
        await query.edit_message_text(message, reply_markup=reply_markup)
        return
    
    referral_list = "\n".join([
        f"👤 {u.username or f'User {u.telegram_id}'} - Joined {u.created_at.strftime('%d/%m/%Y')}"
        for u in referred_users
    ])
    
    keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="referral_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    message = (
        f"📋 <b>Your Referrals</b>\n\n"
        f"Total: {len(referred_users)}\n\n"
        f"{referral_list}"
    )
    
    await query.edit_message_text(message, parse_mode="HTML", reply_markup=reply_markup)

async def copy_referral_link(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle copy referral link"""
    query = update.callback_query
    user = query.from_user
    
    db = await get_db()
    async with await db.get_session() as session:
        # Get user
        user_stmt = select(User).where(User.telegram_id == user.id)
        user_result = await session.execute(user_stmt)
        user_obj = user_result.scalars().first()
        
        if not user_obj:
            await query.answer("❌ User not found", show_alert=True)
            return
        
        referral_code = user_obj.referral_code
    
    referral_link = f"https://t.me/{BOT_USERNAME}?start={referral_code}"
    
    # Show link for easy copying
    await query.answer(f"Link copied: {referral_link}", show_alert=False)
