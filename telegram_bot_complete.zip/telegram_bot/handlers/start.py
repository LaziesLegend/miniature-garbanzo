import logging
import random
import string
from telegram import Update, ReplyKeyboardMarkup, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from sqlalchemy import select
from database import User, get_db
from services.token_service import TokenService

logger = logging.getLogger(__name__)

def get_main_keyboard():
    """Get main menu keyboard"""
    keyboard = [
        ["🏠 Home", "💰 Earn"],
        ["📢 Create Campaign", "💳 Deposit"],
        ["👥 Referral", "🆘 Help Desk"],
        ["👤 Profile"]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Start command handler"""
    user = update.effective_user
    telegram_id = user.id
    
    db = await get_db()
    
    async with await db.get_session() as session:
        # Check if user exists
        stmt = select(User).where(User.telegram_id == telegram_id)
        result = await session.execute(stmt)
        existing_user = result.scalars().first()
        
        if not existing_user:
            # Create new user
            referral_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
            
            # Check if referred via deep link
            referred_by_id = None
            if context.args:
                ref_code = context.args[0]
                ref_stmt = select(User).where(User.referral_code == ref_code)
                ref_result = await session.execute(ref_stmt)
                ref_user = ref_result.scalars().first()
                if ref_user:
                    referred_by_id = ref_user.id
            
            new_user = User(
                telegram_id=telegram_id,
                username=user.username,
                referral_code=referral_code,
                referred_by=referred_by_id,
                balance=0,
                total_earned=0,
                total_spent=0
            )
            session.add(new_user)
            await session.commit()
            
            welcome_message = (
                f"🎉 Welcome {user.first_name}!\n\n"
                f"You've joined our token economy platform.\n"
                f"Your Referral Code: <code>{referral_code}</code>\n\n"
                f"Start earning tokens by completing tasks or create campaigns!"
            )
            
            logger.info(f"New user created: {telegram_id}")
        else:
            welcome_message = f"Welcome back, {user.first_name}! 👋"
            logger.info(f"User already exists: {telegram_id}")
    
    await update.message.reply_text(
        welcome_message,
        parse_mode="HTML",
        reply_markup=get_main_keyboard()
    )

async def home(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Home menu handler"""
    user = update.effective_user
    balance = await TokenService.get_user_balance(user.id)
    
    home_message = (
        f"🏠 <b>Home</b>\n\n"
        f"💰 Current Balance: <b>{balance} tokens</b>\n\n"
        f"Select an option from the menu below:"
    )
    
    await update.message.reply_text(
        home_message,
        parse_mode="HTML",
        reply_markup=get_main_keyboard()
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Help command"""
    help_message = (
        "📚 <b>Help & Information</b>\n\n"
        "🤖 <b>Bot Features:</b>\n"
        "• 💰 <b>Earn:</b> Complete campaigns and earn tokens\n"
        "• 📢 <b>Create Campaign:</b> Create tasks for others\n"
        "• 💳 <b>Deposit:</b> Add tokens via UPI\n"
        "• 👥 <b>Referral:</b> Earn bonuses from referrals\n"
        "• 👤 <b>Profile:</b> View your statistics\n\n"
        "💡 <b>Token Economy:</b>\n"
        "• Campaign creators pay 115 tokens per slot\n"
        "• Task completers earn 100 tokens\n"
        "• Platform keeps 15 tokens per task\n"
        "• Referral bonus: 10 tokens per first task\n\n"
        "❓ <b>Need Support?</b>\n"
        "Use the Help Desk option in the menu!"
    )
    
    await update.message.reply_text(help_message, parse_mode="HTML", reply_markup=get_main_keyboard())

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Error handler"""
    logger.error(f"Exception: {context.error}", exc_info=context.error)
    
    try:
        await update.message.reply_text(
            "❌ An error occurred. Please try again later.",
            reply_markup=get_main_keyboard()
        )
    except:
        pass
