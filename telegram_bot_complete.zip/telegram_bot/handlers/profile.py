import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from services.token_service import TokenService

logger = logging.getLogger(__name__)

async def profile_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show user profile"""
    user = update.effective_user
    
    stats = await TokenService.get_user_stats(user.id)
    
    if not stats:
        await update.callback_query.edit_message_text("❌ User not found")
        return
    
    message = (
        f"👤 <b>Profile</b>\n\n"
        f"<b>User Info:</b>\n"
        f"• ID: <code>{user.id}</code>\n"
        f"• Username: @{user.username or 'Not set'}\n\n"
        f"<b>Token Statistics:</b>\n"
        f"💰 Current Balance: <b>{stats['balance']}</b> tokens\n"
        f"📈 Total Earned: {stats['total_earned']} tokens\n"
        f"📉 Total Spent: {stats['total_spent']} tokens\n\n"
        f"<b>Activity:</b>\n"
        f"📢 Active Campaigns: {stats['active_campaigns']}\n"
        f"✅ Completed Tasks: {stats['completed_tasks']}\n"
        f"👥 Referrals: {stats['referral_count']}\n"
        f"💎 Referral Earnings: {stats['referral_earnings']} tokens"
    )
    
    keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="home_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(message, parse_mode="HTML", reply_markup=reply_markup)
    else:
        await update.message.reply_text(message, parse_mode="HTML", reply_markup=reply_markup)
