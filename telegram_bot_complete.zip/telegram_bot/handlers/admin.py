import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from sqlalchemy import select
from database import User, Deposit, Campaign, SupportTicket, get_db
from services.token_service import DepositService, AdminService, TokenService
from config import ADMIN_ID

logger = logging.getLogger(__name__)

def is_admin(user_id: int) -> bool:
    """Check if user is admin"""
    return user_id == ADMIN_ID

async def admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show admin statistics"""
    user = update.effective_user
    
    if not is_admin(user.id):
        await update.message.reply_text("❌ Unauthorized")
        return
    
    stats = await AdminService.get_stats()
    
    message = (
        f"📊 <b>Platform Statistics</b>\n\n"
        f"👥 Total Users: {stats['total_users']}\n"
        f"📢 Active Campaigns: {stats['active_campaigns']}\n"
        f"💰 Total Tokens in Circulation: {stats['total_tokens_in_circulation']}\n"
        f"📋 Total Completed Tasks: {stats['total_completed_tasks']}\n"
        f"💎 Platform Earnings: {stats['platform_earnings']} tokens\n"
        f"⏳ Pending Deposits: {stats['pending_deposits']}"
    )
    
    await update.message.reply_text(message, parse_mode="HTML")

async def show_pending_deposits(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show pending deposits"""
    user = update.effective_user
    
    if not is_admin(user.id):
        await update.message.reply_text("❌ Unauthorized")
        return
    
    deposits = await DepositService.get_pending_deposits()
    
    if not deposits:
        await update.message.reply_text("✅ No pending deposits")
        return
    
    db = await get_db()
    async with await db.get_session() as session:
        deposit_list = []
        for deposit in deposits:
            user_stmt = select(User).where(User.id == deposit.user_id)
            user_result = await session.execute(user_stmt)
            user_obj = user_result.scalars().first()
            
            deposit_list.append(
                f"💳 <b>ID: {deposit.id}</b>\n"
                f"   User: {user_obj.username or f'User {user_obj.telegram_id}'}\n"
                f"   Amount: {deposit.amount} tokens\n"
                f"   TxID: {deposit.txid}\n"
                f"   Created: {deposit.created_at.strftime('%d/%m/%Y %H:%M')}\n"
            )
    
    message = (
        f"⏳ <b>Pending Deposits ({len(deposits)})</b>\n\n"
        + "\n".join(deposit_list) +
        f"\n\n/approve_deposit <id> - Approve\n"
        f"/reject_deposit <id> - Reject"
    )
    
    await update.message.reply_text(message, parse_mode="HTML")

async def approve_deposit_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Approve deposit command"""
    user = update.effective_user
    
    if not is_admin(user.id):
        await update.message.reply_text("❌ Unauthorized")
        return
    
    if not context.args:
        await update.message.reply_text("Usage: /approve_deposit <deposit_id>")
        return
    
    try:
        deposit_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ Invalid deposit ID")
        return
    
    result = await DepositService.approve_deposit(deposit_id)
    
    if result['success']:
        await update.message.reply_text(
            f"✅ {result['message']}\n"
            f"User: {result['user_telegram_id']}\n"
            f"Amount: {result['amount']} tokens"
        )
        
        # Notify user
        try:
            await context.bot.send_message(
                chat_id=result['user_telegram_id'],
                text=f"✅ Your deposit of {result['amount']} tokens has been approved!"
            )
        except Exception as e:
            logger.error(f"Failed to notify user: {e}")
    else:
        await update.message.reply_text(f"❌ {result['message']}")

async def reject_deposit_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Reject deposit command"""
    user = update.effective_user
    
    if not is_admin(user.id):
        await update.message.reply_text("❌ Unauthorized")
        return
    
    if not context.args:
        await update.message.reply_text("Usage: /reject_deposit <deposit_id>")
        return
    
    try:
        deposit_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ Invalid deposit ID")
        return
    
    result = await DepositService.reject_deposit(deposit_id)
    
    if result['success']:
        await update.message.reply_text(f"✅ {result['message']}")
    else:
        await update.message.reply_text(f"❌ {result['message']}")

async def pause_campaign_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Pause campaign command"""
    user = update.effective_user
    
    if not is_admin(user.id):
        await update.message.reply_text("❌ Unauthorized")
        return
    
    if not context.args:
        await update.message.reply_text("Usage: /pause_campaign <campaign_id>")
        return
    
    try:
        campaign_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ Invalid campaign ID")
        return
    
    db = await get_db()
    async with await db.get_session() as session:
        campaign_stmt = select(Campaign).where(Campaign.id == campaign_id)
        campaign_result = await session.execute(campaign_stmt)
        campaign = campaign_result.scalars().first()
        
        if not campaign:
            await update.message.reply_text("❌ Campaign not found")
            return
        
        campaign.status = "paused"
        await session.commit()
    
    await update.message.reply_text(f"✅ Campaign {campaign_id} paused")

async def resume_campaign_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Resume campaign command"""
    user = update.effective_user
    
    if not is_admin(user.id):
        await update.message.reply_text("❌ Unauthorized")
        return
    
    if not context.args:
        await update.message.reply_text("Usage: /resume_campaign <campaign_id>")
        return
    
    try:
        campaign_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ Invalid campaign ID")
        return
    
    db = await get_db()
    async with await db.get_session() as session:
        campaign_stmt = select(Campaign).where(Campaign.id == campaign_id)
        campaign_result = await session.execute(campaign_stmt)
        campaign = campaign_result.scalars().first()
        
        if not campaign:
            await update.message.reply_text("❌ Campaign not found")
            return
        
        campaign.status = "active"
        await session.commit()
    
    await update.message.reply_text(f"✅ Campaign {campaign_id} resumed")

async def broadcast_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Broadcast message to all users"""
    user = update.effective_user
    
    if not is_admin(user.id):
        await update.message.reply_text("❌ Unauthorized")
        return
    
    if not context.args:
        await update.message.reply_text("Usage: /broadcast <message>")
        return
    
    message = " ".join(context.args)
    
    db = await get_db()
    async with await db.get_session() as session:
        users_stmt = select(User)
        users_result = await session.execute(users_stmt)
        users = users_result.scalars().all()
    
    sent = 0
    failed = 0
    
    for user_obj in users:
        try:
            await context.bot.send_message(
                chat_id=user_obj.telegram_id,
                text=f"📢 <b>Announcement</b>\n\n{message}",
                parse_mode="HTML"
            )
            sent += 1
        except Exception as e:
            logger.error(f"Failed to send message to {user_obj.telegram_id}: {e}")
            failed += 1
    
    await update.message.reply_text(
        f"✅ Broadcast complete\n"
        f"Sent: {sent}\n"
        f"Failed: {failed}"
    )

async def reply_support_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Reply to support ticket command"""
    user = update.effective_user
    
    if not is_admin(user.id):
        await update.message.reply_text("❌ Unauthorized")
        return
    
    if len(context.args) < 2:
        await update.message.reply_text("Usage: /reply <ticket_id> <message>")
        return
    
    try:
        ticket_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ Invalid ticket ID")
        return
    
    reply_message = " ".join(context.args[1:])
    
    db = await get_db()
    async with await db.get_session() as session:
        ticket_stmt = select(SupportTicket).where(SupportTicket.id == ticket_id)
        ticket_result = await session.execute(ticket_stmt)
        ticket = ticket_result.scalars().first()
        
        if not ticket:
            await update.message.reply_text("❌ Ticket not found")
            return
        
        ticket.admin_reply = reply_message
        ticket.status = "closed"
        await session.commit()
        
        user_id = ticket.user.telegram_id
    
    # Notify user
    try:
        await context.bot.send_message(
            chat_id=user_id,
            text=f"📩 <b>Support Reply</b>\n\n{reply_message}",
            parse_mode="HTML"
        )
    except Exception as e:
        logger.error(f"Failed to notify user: {e}")
    
    await update.message.reply_text(f"✅ Reply sent to ticket {ticket_id}")
