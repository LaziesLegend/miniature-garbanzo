import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ChatMember
from telegram.ext import ContextTypes
from telegram.error import TelegramError
from sqlalchemy import select
from database import get_db, CompletedTask, Campaign
from services.token_service import TokenService, CampaignService

logger = logging.getLogger(__name__)

async def earn_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show earn menu"""
    keyboard = [
        [InlineKeyboardButton("🔎 Available Tasks", callback_data="available_tasks"),
         InlineKeyboardButton("📊 My Completed Tasks", callback_data="my_tasks")],
        [InlineKeyboardButton("⬅️ Back", callback_data="home_menu")],
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    message = (
        "💰 <b>Earn Tokens</b>\n\n"
        "🔎 <b>Available Tasks:</b>\n"
        "Join channels and complete tasks to earn tokens\n\n"
        "⚠️ You cannot complete your own campaigns\n"
        "⚠️ Each task can only be completed once per user"
    )
    
    if update.callback_query:
        await update.callback_query.edit_message_text(message, parse_mode="HTML", reply_markup=reply_markup)
    else:
        await update.message.reply_text(message, parse_mode="HTML", reply_markup=reply_markup)

async def show_available_tasks(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show available tasks"""
    user = update.effective_user
    
    campaigns = await CampaignService.get_active_campaigns(user.id)
    
    if not campaigns:
        keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="earn_menu")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        message = "❌ No available tasks at the moment."
        await update.callback_query.edit_message_text(message, reply_markup=reply_markup)
        return
    
    # Store campaigns in context for later use
    context.user_data['campaigns'] = {c.id: c for c in campaigns}
    
    # Show first campaign
    await show_campaign_detail(update, context, campaigns[0].id)

async def show_campaign_detail(update: Update, context: ContextTypes.DEFAULT_TYPE, campaign_id: int) -> None:
    """Show campaign details"""
    campaigns = context.user_data.get('campaigns', {})
    campaign = campaigns.get(campaign_id)
    
    if not campaign:
        campaign = await CampaignService.get_campaign_by_id(campaign_id)
        if not campaign:
            await update.callback_query.edit_message_text("❌ Campaign not found")
            return
        context.user_data['campaigns'] = {campaign_id: campaign}
    
    # Get campaign creator name
    db = await get_db()
    async with await db.get_session() as session:
        creator_stmt = select(campaign.__class__).where(campaign.__class__.id == campaign_id)
        result = await session.execute(creator_stmt)
        campaign_data = result.scalars().first()
        creator_name = campaign_data.creator.username or "Anonymous"
    
    message = (
        f"📢 <b>Campaign Details</b>\n\n"
        f"👤 <b>Creator:</b> {creator_name}\n"
        f"📱 <b>Channel:</b> @{campaign.channel_username}\n"
        f"👥 <b>Remaining Slots:</b> {campaign.remaining_slots}\n"
        f"💰 <b>Reward:</b> 100 tokens\n\n"
        f"<b>Steps:</b>\n"
        f"1️⃣ Join the channel\n"
        f"2️⃣ Click 'Join & Verify'\n"
        f"3️⃣ Get verified and earn 100 tokens"
    )
    
    keyboard = [
        [InlineKeyboardButton("🔗 Join Channel", url=f"https://t.me/{campaign.channel_username}")],
        [InlineKeyboardButton("✅ Verify", callback_data=f"verify_task_{campaign_id}")],
        [InlineKeyboardButton("⬅️ Back", callback_data="available_tasks")],
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(message, parse_mode="HTML", reply_markup=reply_markup)
    else:
        await update.message.reply_text(message, parse_mode="HTML", reply_markup=reply_markup)

async def verify_task(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Verify task completion"""
    query = update.callback_query
    user = query.from_user
    campaign_id = int(query.data.split("_")[-1])
    
    # Get campaign
    campaign = await CampaignService.get_campaign_by_id(campaign_id)
    if not campaign:
        await query.answer("❌ Campaign not found", show_alert=True)
        return
    
    try:
        # Check if user joined channel
        chat_member = await context.bot.get_chat_member(f"@{campaign.channel_username}", user.id)
        
        # Check membership status
        if chat_member.status not in [ChatMember.MEMBER, ChatMember.ADMINISTRATOR, ChatMember.CREATOR]:
            await query.answer(
                "❌ Please join the channel first!",
                show_alert=True
            )
            return
        
        # Complete task
        result = await TokenService.complete_task(user.id, campaign_id)
        
        if result['success']:
            await query.answer(
                f"✅ Task completed! You earned {result['tokens_earned']} tokens",
                show_alert=True
            )
            
            # Show updated tasks
            await show_available_tasks(update, context)
        else:
            await query.answer(
                f"❌ {result['message']}",
                show_alert=True
            )
    
    except TelegramError as e:
        logger.error(f"Error verifying task: {e}")
        await query.answer(
            "❌ Error verifying membership. Please make sure the channel username is correct.",
            show_alert=True
        )

async def show_completed_tasks(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show user's completed tasks"""
    user = update.effective_user
    
    db = await get_db()
    async with await db.get_session() as session:
        # Get user
        from database import User
        user_stmt = select(User).where(User.telegram_id == user.id)
        user_result = await session.execute(user_stmt)
        user_obj = user_result.scalars().first()
        
        if not user_obj:
            await update.callback_query.edit_message_text("❌ User not found")
            return
        
        # Get completed tasks
        tasks_stmt = select(CompletedTask).where(CompletedTask.user_id == user_obj.id)
        tasks_result = await session.execute(tasks_stmt)
        tasks = tasks_result.scalars().all()
    
    if not tasks:
        keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="earn_menu")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        message = "📊 You haven't completed any tasks yet."
        await update.callback_query.edit_message_text(message, reply_markup=reply_markup)
        return
    
    task_list = "\n".join([
        f"✅ Campaign #{task.campaign_id} - {task.completed_at.strftime('%d/%m/%Y')}"
        for task in tasks
    ])
    
    keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="earn_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    message = (
        f"📊 <b>Completed Tasks</b>\n\n"
        f"Total: {len(tasks)}\n"
        f"Total Earnings: {len(tasks) * 100} tokens\n\n"
        f"{task_list}"
    )
    
    await update.callback_query.edit_message_text(message, parse_mode="HTML", reply_markup=reply_markup)
