import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from services.token_service import DepositService
from config import UPI_ID, UPI_NAME

logger = logging.getLogger(__name__)

DEPOSIT_AMOUNT = 1
DEPOSIT_TXID = 2

async def deposit_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show deposit menu"""
    keyboard = [
        [InlineKeyboardButton("💳 UPI Deposit", callback_data="upi_deposit")],
        [InlineKeyboardButton("⬅️ Back", callback_data="home_menu")],
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    message = (
        "💳 <b>Deposit Tokens</b>\n\n"
        "📌 <b>Deposit Methods:</b>\n"
        "• 💳 UPI - Fast manual deposit\n\n"
        "💡 <b>How it works:</b>\n"
        "1. Select a deposit method\n"
        "2. Enter the amount\n"
        "3. Send payment\n"
        "4. Submit transaction ID for verification\n"
        "5. Admin will approve and add tokens"
    )
    
    if update.callback_query:
        await update.callback_query.edit_message_text(message, parse_mode="HTML", reply_markup=reply_markup)
    else:
        await update.message.reply_text(message, parse_mode="HTML", reply_markup=reply_markup)

async def start_upi_deposit(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Start UPI deposit flow"""
    query = update.callback_query
    
    message = (
        f"💰 <b>UPI Deposit</b>\n\n"
        f"📱 <b>UPI ID:</b> <code>{UPI_ID}</code>\n"
        f"👤 <b>Name:</b> {UPI_NAME}\n\n"
        f"1️⃣ <b>Enter amount to deposit:</b>\n"
        f"(Minimum: 100 tokens)"
    )
    
    keyboard = [[InlineKeyboardButton("⬅️ Cancel", callback_data="deposit_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(message, parse_mode="HTML", reply_markup=reply_markup)
    
    return DEPOSIT_AMOUNT

async def receive_deposit_amount(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Receive deposit amount"""
    if update.callback_query:
        if update.callback_query.data == "deposit_menu":
            await deposit_menu(update, context)
            return ConversationHandler.END
    
    try:
        amount = int(update.message.text.strip())
        
        if amount < 100:
            await update.message.reply_text("❌ Minimum deposit is 100 tokens")
            return DEPOSIT_AMOUNT
        
        if amount > 1000000:
            await update.message.reply_text("❌ Maximum deposit is 1,000,000 tokens")
            return DEPOSIT_AMOUNT
        
        context.user_data['deposit_amount'] = amount
        
        message = (
            f"✅ Amount: <b>{amount} tokens</b>\n\n"
            f"📱 Please complete the UPI payment:\n\n"
            f"🔗 <code>{UPI_ID}</code>\n"
            f"Amount: ₹{amount}\n\n"
            f"After payment, enter your <b>Transaction ID (UPI Ref ID)</b>\n"
            f"Format: Usually found in your bank app"
        )
        
        keyboard = [[InlineKeyboardButton("⬅️ Cancel", callback_data="deposit_menu")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(message, parse_mode="HTML", reply_markup=reply_markup)
        
        return DEPOSIT_TXID
    
    except ValueError:
        await update.message.reply_text("❌ Please enter a valid number")
        return DEPOSIT_AMOUNT

async def receive_deposit_txid(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Receive transaction ID"""
    if update.callback_query:
        if update.callback_query.data == "deposit_menu":
            await deposit_menu(update, context)
            return ConversationHandler.END
    
    user = update.effective_user
    txid = update.message.text.strip().upper()
    amount = context.user_data.get('deposit_amount', 0)
    
    # Validate txid
    if not txid or len(txid) < 5 or len(txid) > 50:
        await update.message.reply_text("❌ Invalid transaction ID. Please check and try again.")
        return DEPOSIT_TXID
    
    # Create deposit
    result = await DepositService.create_deposit(user.id, amount, txid)
    
    if result['success']:
        message = (
            f"✅ <b>Deposit Request Submitted!</b>\n\n"
            f"💰 <b>Amount:</b> {amount} tokens\n"
            f"🔗 <b>Transaction ID:</b> {txid}\n"
            f"📊 <b>Status:</b> ⏳ Pending\n\n"
            f"Admin will verify and approve your payment.\n"
            f"You'll receive a notification once it's approved!"
        )
        
        keyboard = [[InlineKeyboardButton("⬅️ Back to Home", callback_data="home_menu")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(message, parse_mode="HTML", reply_markup=reply_markup)
        
        logger.info(f"Deposit request created: user={user.id}, amount={amount}, txid={txid}")
    else:
        await update.message.reply_text(f"❌ {result['message']}")
        return DEPOSIT_TXID
    
    return ConversationHandler.END
