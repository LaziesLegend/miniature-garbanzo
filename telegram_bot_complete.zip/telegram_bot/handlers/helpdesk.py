import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from sqlalchemy import select
from database import User, SupportTicket, get_db

logger = logging.getLogger(__name__)

SUPPORT_MESSAGE = 1

async def helpdesk_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show help desk menu"""
    keyboard = [
        [InlineKeyboardButton("📩 Contact Support", callback_data="contact_support"),
         InlineKeyboardButton("❓ FAQ", callback_data="faq_menu")],
        [InlineKeyboardButton("⬅️ Back", callback_data="home_menu")],
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    message = (
        "🆘 <b>Help Desk</b>\n\n"
        "💡 <b>Need assistance?</b>\n"
        "• 📩 Contact our support team\n"
        "• ❓ Check FAQ for common questions"
    )
    
    if update.callback_query:
        await update.callback_query.edit_message_text(message, parse_mode="HTML", reply_markup=reply_markup)
    else:
        await update.message.reply_text(message, parse_mode="HTML", reply_markup=reply_markup)

async def show_faq(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show FAQ"""
    query = update.callback_query
    
    message = (
        "❓ <b>Frequently Asked Questions</b>\n\n"
        "<b>Q: How do I earn tokens?</b>\n"
        "A: Complete campaign tasks by joining channels and verifying membership.\n\n"
        "<b>Q: How much does it cost to create a campaign?</b>\n"
        "A: 115 tokens per member slot. (Creators pay 115, completers earn 100)\n\n"
        "<b>Q: What's a referral bonus?</b>\n"
        "A: When someone you refer completes their first task, you earn 10 tokens.\n\n"
        "<b>Q: How do I deposit tokens?</b>\n"
        "A: Use the Deposit menu and send UPI payment. Admin will verify.\n\n"
        "<b>Q: Can I undo a deposit?</b>\n"
        "A: Contact support if you made a mistake.\n\n"
        "<b>Q: How long does verification take?</b>\n"
        "A: Usually instant, but may take up to 24 hours for deposits.\n\n"
        "<b>Q: Is there a minimum/maximum withdrawal?</b>\n"
        "A: Contact support for withdrawal details."
    )
    
    keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="helpdesk_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(message, parse_mode="HTML", reply_markup=reply_markup)

async def start_contact_support(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Start support ticket creation"""
    query = update.callback_query
    
    message = (
        "📩 <b>Contact Support</b>\n\n"
        "Please describe your issue in detail. "
        "Our support team will get back to you soon."
    )
    
    keyboard = [[InlineKeyboardButton("⬅️ Cancel", callback_data="helpdesk_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(message, parse_mode="HTML", reply_markup=reply_markup)
    
    return SUPPORT_MESSAGE

async def receive_support_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Receive support message"""
    if update.callback_query:
        if update.callback_query.data == "helpdesk_menu":
            await helpdesk_menu(update, context)
            return ConversationHandler.END
    
    user = update.effective_user
    message_text = update.message.text
    
    if not message_text or len(message_text) < 10:
        await update.message.reply_text("❌ Please provide at least 10 characters describing your issue.")
        return SUPPORT_MESSAGE
    
    db = await get_db()
    async with await db.get_session() as session:
        # Get user
        user_stmt = select(User).where(User.telegram_id == user.id)
        user_result = await session.execute(user_stmt)
        user_obj = user_result.scalars().first()
        
        if not user_obj:
            await update.message.reply_text("❌ User not found")
            return ConversationHandler.END
        
        # Create support ticket
        ticket = SupportTicket(
            user_id=user_obj.id,
            message=message_text,
            status="open"
        )
        session.add(ticket)
        await session.commit()
        ticket_id = ticket.id
    
    response = (
        f"✅ <b>Support Ticket Created!</b>\n\n"
        f"🎫 <b>Ticket ID:</b> {ticket_id}\n"
        f"📊 <b>Status:</b> ⏳ Open\n\n"
        f"Our support team will review your message and respond soon.\n"
        f"You can check your ticket status using the ticket ID."
    )
    
    keyboard = [[InlineKeyboardButton("⬅️ Back to Home", callback_data="home_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(response, parse_mode="HTML", reply_markup=reply_markup)
    
    logger.info(f"Support ticket created: id={ticket_id}, user={user.id}")
    
    return ConversationHandler.END
