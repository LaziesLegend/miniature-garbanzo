# Telegram Token Economy Bot

A production-ready Telegram bot implementing a token-based campaign marketplace with comprehensive token economy, user system, and admin controls.

## Features

### 🏠 User Features
- **Earn System**: Complete campaigns and earn 100 tokens per task
- **Campaign Creation**: Create campaigns with custom member slots (115 tokens per slot)
- **Deposit System**: Add tokens via UPI with admin verification
- **Referral Program**: Earn 10 tokens for each user you refer who completes their first task
- **Profile Dashboard**: View balance, statistics, and activity
- **Help Desk**: Contact support and access FAQ

### 💰 Token Economy
- **Creator Cost**: 115 tokens per member slot
- **Completer Reward**: 100 tokens per task completion
- **Platform Margin**: 15 tokens per task (15% fee)
- **Referral Bonus**: 10 tokens per referred user's first task

### 👨‍💼 Admin Features
- View platform statistics
- Approve/reject deposits
- Pause/resume campaigns
- Broadcast messages to all users
- Reply to support tickets

## Architecture

```
/bot
├── main.py                 # Main bot application
├── config.py              # Configuration and constants
├── database.py            # SQLAlchemy models and database setup
├── requirements.txt       # Python dependencies
├── handlers/
│   ├── start.py          # /start command and main menu
│   ├── home.py           # Home menu navigation
│   ├── earn.py           # Task completion and earning
│   ├── campaign.py       # Campaign creation
│   ├── deposit.py        # Deposit management
│   ├── referral.py       # Referral system
│   ├── profile.py        # User profile
│   ├── helpdesk.py       # Support and FAQ
│   └── admin.py          # Admin commands
└── services/
    └── token_service.py   # Business logic for tokens, campaigns, deposits
```

## Installation

### 1. Install Python Dependencies

```bash
pip install -r requirements.txt
```

### 2. Update Configuration

Edit `config.py` with your values:

```python
BOT_TOKEN = "your_bot_token_here"
ADMIN_ID = your_admin_telegram_id
UPI_ID = "your_upi@handle"
BOT_USERNAME = "your_bot_username"
```

### 3. Run the Bot

```bash
python main.py
```

## Database

The bot uses SQLite by default (auto-created on startup). For PostgreSQL, update `DATABASE_URL` in `config.py`:

```python
DATABASE_URL = "postgresql+asyncpg://user:password@localhost/bot_db"
```

### Database Schema

The bot automatically creates these tables:

1. **users** - User data and balances
2. **campaigns** - Campaign information
3. **completed_tasks** - Task completion records
4. **deposits** - Deposit requests
5. **support_tickets** - Help desk tickets

## User Guide

### Getting Started
1. Send `/start` to the bot
2. You'll receive a unique referral code
3. Use the main menu buttons to navigate

### Earning Tokens

**💰 Earn Menu:**
- **Available Tasks**: See all campaigns you can join
  - Join the channel
  - Click "Verify" to confirm membership
  - Earn 100 tokens on verification
  
- **Completed Tasks**: View tasks you've already completed

### Creating Campaigns

**📢 Create Campaign Menu:**
1. Click "Create New Campaign"
2. Enter Telegram channel username
3. Enter number of member slots
4. Review costs (115 tokens per slot)
5. Confirm and launch

### Depositing Tokens

**💳 Deposit Menu:**
1. Click "Deposit"
2. Choose UPI option
3. Send payment using provided UPI ID
4. Submit transaction ID
5. Admin will verify and approve
6. Tokens added to your balance

### Referral System

**👥 Referral Menu:**
- View your referral link
- Share with friends
- Earn 10 tokens when they complete their first task
- See list of all referrals

### Profile

**👤 Profile Menu:**
- View current balance
- Total earned/spent statistics
- Active campaigns count
- Completed tasks count
- Referral statistics

## Admin Commands

### View Statistics
```
/stats
```
Shows total users, active campaigns, tokens in circulation, and platform earnings.

### Manage Deposits
```
/pending
```
View all pending deposit requests.

```
/approve_deposit <deposit_id>
```
Approve a deposit and add tokens to user.

```
/reject_deposit <deposit_id>
```
Reject a deposit request.

### Manage Campaigns
```
/pause_campaign <campaign_id>
```
Pause an active campaign.

```
/resume_campaign <campaign_id>
```
Resume a paused campaign.

### Communication
```
/broadcast <message>
```
Send message to all users.

```
/reply <ticket_id> <message>
```
Reply to a support ticket.

## Navigation

Every menu includes:
- ⬅️ Back button to return to previous menu
- 🏠 Home button to return to main menu
- No message flooding - uses inline buttons where possible
- Edit instead of duplicate messages

## Security Features

- ✅ Input validation on all user inputs
- ✅ Prevent negative balances
- ✅ Prevent double task completion
- ✅ Prevent users from completing own campaigns
- ✅ Duplicate transaction ID prevention
- ✅ Async database transactions
- ✅ Admin-only command verification

## Error Handling

- Comprehensive error logging
- User-friendly error messages
- Graceful fallback on API errors
- Database transaction rollback on failure

## Token Economy Flow

```
User Creates Campaign (pays 115 tokens)
         ↓
Campaign appears in Available Tasks
         ↓
User Joins Channel & Completes Task
         ↓
Bot Verifies Membership
         ↓
User receives 100 tokens
Platform keeps 15 tokens
         ↓
If referred user's first task:
Referrer gets 10 bonus tokens
```

## Troubleshooting

### Bot doesn't start
- Check BOT_TOKEN in config.py
- Verify internet connection
- Check logs for errors

### Database issues
- Delete `bot_database.db` to reset
- Bot will auto-create on restart
- Check DATABASE_URL setting

### Verification fails
- Ensure channel username is correct
- Bot must have access to the channel
- User must be joined to the channel

### Deposits not processing
- Admin must use `/pending` to see requests
- Use `/approve_deposit <id>` to process
- User will get notification when approved

## Customization

### Change token values
Edit `config.py`:
```python
CAMPAIGN_CREATOR_COST = 115
TASK_COMPLETER_REWARD = 100
PLATFORM_MARGIN = 15
REFERRAL_BONUS = 10
```

### Change UPI details
Edit `config.py`:
```python
UPI_ID = "your_upi@handle"
UPI_NAME = "Your Name"
```

### Add more deposit methods
Edit `handlers/deposit.py` to add cryptocurrency or other payment methods.

## Performance Tips

- Use PostgreSQL for production (better than SQLite)
- Enable logging to file for debugging
- Regular database backups
- Monitor admin stats regularly

## Support

For issues or questions:
1. Check the FAQ in the Help Desk menu
2. Contact admin via Support tickets
3. Check logs: `main.py` creates detailed logs

## License

This bot is provided as-is for private use.

## Database Backup

```bash
# SQLite
cp bot_database.db bot_database.backup.db

# PostgreSQL
pg_dump bot_db > backup.sql
```

---

**Version**: 1.0.0  
**Last Updated**: 2025  
**Python**: 3.11+  
**Dependencies**: See requirements.txt
