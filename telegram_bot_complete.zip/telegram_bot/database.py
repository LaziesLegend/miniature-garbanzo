import logging
from datetime import datetime
from sqlalchemy import (
    create_engine, Column, Integer, String, Float, DateTime, 
    Boolean, ForeignKey, Index, select, and_, or_
)
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import declarative_base, relationship
from sqlalchemy.pool import StaticPool
import asyncio
from config import DATABASE_URL

logger = logging.getLogger(__name__)

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True)
    telegram_id = Column(Integer, unique=True, nullable=False, index=True)
    username = Column(String(255), nullable=True)
    balance = Column(Integer, default=0)
    referral_code = Column(String(50), unique=True, nullable=False, index=True)
    referred_by = Column(Integer, nullable=True)
    total_earned = Column(Integer, default=0)
    total_spent = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    campaigns = relationship("Campaign", back_populates="creator", foreign_keys="Campaign.creator_id")
    completed_tasks = relationship("CompletedTask", back_populates="user", foreign_keys="CompletedTask.user_id")
    deposits = relationship("Deposit", back_populates="user")
    support_tickets = relationship("SupportTicket", back_populates="user")

class Campaign(Base):
    __tablename__ = "campaigns"
    
    id = Column(Integer, primary_key=True)
    creator_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    channel_username = Column(String(255), nullable=False)
    total_slots = Column(Integer, nullable=False)
    remaining_slots = Column(Integer, nullable=False)
    status = Column(String(20), default="active")  # active, paused, completed
    created_at = Column(DateTime, default=datetime.utcnow)
    
    creator = relationship("User", back_populates="campaigns", foreign_keys=[creator_id])
    completed_tasks = relationship("CompletedTask", back_populates="campaign")

class CompletedTask(Base):
    __tablename__ = "completed_tasks"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    campaign_id = Column(Integer, ForeignKey("campaigns.id"), nullable=False, index=True)
    completed_at = Column(DateTime, default=datetime.utcnow)
    
    user = relationship("User", back_populates="completed_tasks", foreign_keys=[user_id])
    campaign = relationship("Campaign", back_populates="completed_tasks")
    
    __table_args__ = (
        Index('ix_user_campaign', 'user_id', 'campaign_id', unique=True),
    )

class Deposit(Base):
    __tablename__ = "deposits"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    amount = Column(Integer, nullable=False)
    txid = Column(String(100), nullable=False, index=True)
    status = Column(String(20), default="pending")  # pending, approved, rejected
    created_at = Column(DateTime, default=datetime.utcnow)
    
    user = relationship("User", back_populates="deposits")

class SupportTicket(Base):
    __tablename__ = "support_tickets"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    message = Column(String(1000), nullable=False)
    status = Column(String(20), default="open")  # open, closed
    admin_reply = Column(String(1000), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    user = relationship("User", back_populates="support_tickets")

# Database Engine Setup
async def init_db():
    """Initialize database and create tables"""
    # Convert sqlite:// to sqlite+aiosqlite://
    db_url = DATABASE_URL
    if db_url.startswith("sqlite://"):
        db_url = db_url.replace("sqlite://", "sqlite+aiosqlite:///")
    
    engine = create_async_engine(
        db_url,
        echo=False,
        future=True,
        pool_pre_ping=True,
        connect_args={"timeout": 30, "check_same_thread": False} if "sqlite" in db_url else {}
    )
    
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    return engine

# Session Factory
async def get_session_factory(engine):
    """Get async session factory"""
    return async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

class Database:
    def __init__(self, engine, session_factory):
        self.engine = engine
        self.session_factory = session_factory
    
    async def get_session(self):
        """Get a new database session"""
        return self.session_factory()
    
    async def close(self):
        """Close database engine"""
        await self.engine.dispose()

# Global database instance
db_instance = None

async def get_db():
    """Get database instance"""
    return db_instance

async def init_database():
    """Initialize database globally"""
    global db_instance
    engine = await init_db()
    session_factory = await get_session_factory(engine)
    db_instance = Database(engine, session_factory)
    logger.info("Database initialized successfully")

async def close_database():
    """Close database globally"""
    global db_instance
    if db_instance:
        await db_instance.close()
        logger.info("Database closed")
