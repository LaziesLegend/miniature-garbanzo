# Bot Menu Structure & Flow

## Main Menu Structure

```
┌─────────────────────────────────────────────┐
│           🏠 MAIN MENU                      │
├─────────────────────────────────────────────┤
│ [🏠 Home] [💰 Earn]                         │
│ [📢 Create Campaign] [💳 Deposit]           │
│ [👥 Referral] [🆘 Help Desk]                │
│ [👤 Profile]                                │
└─────────────────────────────────────────────┘
```

---

## 💰 Earn Menu Flow

```
EARN MENU
├─ 🔎 Available Tasks
│  ├─ Task 1: @channel1
│  │  ├─ 🔗 Join Channel
│  │  ├─ ✅ Verify (checks membership)
│  │  │  └─ ✅ Task Completed! +100 tokens
│  │  └─ ⬅️ Back
│  │
│  ├─ Task 2: @channel2
│  │  └─ ...
│  │
│  └─ ⬅️ Back to Earn Menu
│
├─ 📊 My Completed Tasks
│  ├─ Task #1 - Completed 01/02/2025
│  ├─ Task #2 - Completed 01/02/2025
│  └─ ⬅️ Back
│
└─ ⬅️ Back to Home
```

---

## 📢 Campaign Creation Flow

```
CREATE CAMPAIGN
├─ Step 1: Channel Username
│  ├─ Input: "mychannel"
│  └─ Next ➜
│
├─ Step 2: Number of Members
│  ├─ Input: "10"
│  ├─ Calculation: 10 × 115 = 1,150 tokens
│  └─ Next ➜
│
├─ Step 3: Confirmation
│  ├─ Summary:
│  │  ├─ Channel: @mychannel
│  │  ├─ Slots: 10
│  │  └─ Cost: 1,150 tokens
│  │
│  ├─ ✅ Confirm
│  │  └─ Campaign Created! ID: 42
│  │
│  └─ ❌ Cancel
│
└─ 📋 View My Campaigns
   ├─ 🟢 @channel1 - Slots: 8/10
   ├─ 🟢 @channel2 - Slots: 0/5 (Complete)
   └─ 🔴 @channel3 - Slots: 3/3 (Paused)
```

---

## 💳 Deposit Flow

```
DEPOSIT MENU
├─ 💳 UPI Deposit
│  │
│  ├─ Step 1: Amount
│  │  ├─ Input: "500"
│  │  └─ Min: 100, Max: 1,000,000
│  │
│  ├─ Step 2: UPI Details
│  │  ├─ UPI ID: dummy@paytm
│  │  ├─ Name: Bot Support
│  │  └─ Amount: ₹500
│  │
│  ├─ Step 3: Transaction ID
│  │  ├─ Input: "102254789541"
│  │  └─ Status: Pending ⏳
│  │
│  └─ Admin Reviews
│     ├─ /approve_deposit 1
│     │  └─ ✅ Approved! +500 tokens
│     │
│     └─ /reject_deposit 1
│        └─ ❌ Rejected
│
└─ ⬅️ Back to Home
```

---

## 👥 Referral System

```
REFERRAL MENU
├─ 📊 Statistics
│  ├─ Total Referrals: 5
│  ├─ Total Earnings: 50 tokens (5 × 10)
│  └─ Referral Link: https://t.me/bot?start=ABC123XY
│
├─ 📋 Referral List
│  ├─ 👤 username1 - Joined 01/02/2025
│  ├─ 👤 username2 - Joined 30/01/2025
│  ├─ 👤 User 12345 - Joined 28/01/2025
│  └─ ...
│
├─ 📋 Copy Link
│  └─ Link copied to clipboard
│
└─ ⬅️ Back to Home
```

### Deep Link Example
```
User A shares: https://t.me/your_bot?start=ABC123XY
User B clicks link
User B account created with referred_by = User A
User B completes first task
User A gets +10 tokens automatically
```

---

## 👤 Profile Menu

```
PROFILE MENU
┌──────────────────────────────────────┐
│ 👤 USER PROFILE                      │
├──────────────────────────────────────┤
│ ID: 123456789                        │
│ Username: @myusername                │
│                                      │
│ 💰 Current Balance: 500 tokens       │
│ 📈 Total Earned: 5,200 tokens        │
│ 📉 Total Spent: 4,700 tokens         │
│                                      │
│ 📢 Active Campaigns: 2               │
│ ✅ Completed Tasks: 52               │
│ 👥 Referrals: 5                      │
│ 💎 Referral Earnings: 50 tokens      │
└──────────────────────────────────────┘

⬅️ Back to Home
```

---

## 🆘 Help Desk Flow

```
HELP DESK
├─ 📩 Contact Support
│  ├─ Input: "I can't verify my task"
│  ├─ Validation: Min 10 characters
│  └─ Created: Ticket #42
│     └─ Status: ⏳ Open
│
│  Admin sees:
│  /reply 42 "Check if channel is correct"
│  └─ ✅ Reply sent to user
│
├─ ❓ FAQ
│  ├─ Q: How do I earn tokens?
│  │  └─ A: Complete tasks in campaigns
│  │
│  ├─ Q: How much does it cost?
│  │  └─ A: 115 tokens per slot
│  │
│  ├─ Q: What's referral bonus?
│  │  └─ A: 10 tokens per first task
│  │
│  └─ ... (7 total FAQs)
│
└─ ⬅️ Back to Home
```

---

## 🔐 Admin Commands

```
ADMIN FUNCTIONS
├─ /stats
│  ├─ Total Users: 1,234
│  ├─ Active Campaigns: 42
│  ├─ Tokens in Circulation: 123,456
│  ├─ Completed Tasks: 5,000
│  ├─ Platform Earnings: 75,000 tokens
│  └─ Pending Deposits: 3
│
├─ /pending
│  ├─ ID: 1 | Amount: 500 | User: @john
│  ├─ ID: 2 | Amount: 1000 | User: @jane
│  └─ ID: 3 | Amount: 250 | User: User123
│
├─ /approve_deposit 1
│  └─ ✅ Deposit approved, tokens added
│
├─ /reject_deposit 2
│  └─ ❌ Deposit rejected
│
├─ /pause_campaign 5
│  └─ 🔴 Campaign paused
│
├─ /resume_campaign 5
│  └─ 🟢 Campaign resumed
│
├─ /broadcast Hello everyone!
│  └─ 📢 Sent to 1,234 users
│
└─ /reply 42 "Thanks for your question"
   └─ 📩 Reply sent to user
```

---

## 🔄 Complete User Journey

```
1. NEW USER JOINS
   │
   ├─ /start
   │  └─ Account created
   │     ├─ Balance: 0 tokens
   │     ├─ Referral Code: ABC123XY
   │     └─ Main Menu displayed
   │
   └─ [Option A: Earn Tokens] OR [Option B: Referred User]
      │
      ├─ [A] Go to Earn
      │     ├─ See available campaigns
      │     ├─ Join channel @testchannel
      │     ├─ Verify membership
      │     └─ ✅ Get 100 tokens
      │        └─ Balance: 100 tokens
      │
      └─ [B] Was referred (User A)
            └─ User A gets +10 tokens
               └─ User A: 0 + 10 = 10 tokens

2. GROW BALANCE
   │
   ├─ Complete more tasks
   │  └─ Balance: 100 + 100 + 100 = 300 tokens
   │
   └─ Or deposit via UPI
      ├─ Request: +500 tokens
      ├─ Admin approves
      └─ Balance: 300 + 500 = 800 tokens

3. CREATE CAMPAIGN
   │
   ├─ Click Create Campaign
   ├─ Channel: @mychannel
   ├─ Slots: 5
   ├─ Cost: 5 × 115 = 575 tokens
   ├─ ✅ Campaign created
   │
   └─ Balance: 800 - 575 = 225 tokens
      └─ Campaign has 5 slots available

4. OTHERS COMPLETE CAMPAIGN
   │
   ├─ User 2 completes task
   │  ├─ User 2: +100 tokens
   │  ├─ Platform: +15 tokens
   │  └─ Campaign slots: 4 remaining
   │
   ├─ User 3 completes task
   │  ├─ User 3: +100 tokens
   │  ├─ Platform: +15 tokens
   │  └─ Campaign slots: 3 remaining
   │
   └─ ... repeat until all slots filled
      └─ Campaign status: COMPLETED

5. GROWTH
   │
   └─ Keep earning, creating, and referring
      └─ Over time: balance grows significantly
```

---

## 📊 Token Distribution Example

```
SCENARIO: Campaign with 5 slots

Campaign Creator (User A):
  Pays: 5 × 115 = 575 tokens
  
Task Completers (Users B, C, D, E, F):
  Each earns: 100 tokens per task
  Total: 5 × 100 = 500 tokens
  
Platform Earnings:
  Per task: 15 tokens
  Total: 5 × 15 = 75 tokens
  
Verify: 575 = 500 + 75 ✅

REFERRAL BONUS:
  If all 5 users were referred by User A:
  User A gets: 5 × 10 = 50 additional tokens
  
FINAL BALANCE:
  User A: -575 (campaign cost) + 50 (referral) = -525
  (Recovered 50 tokens from referrals)
```

---

## 🎯 Navigation Guarantees

Every screen has:
```
┌─────────────────────────────────┐
│ CONTENT HERE                    │
│                                 │
│ [⬅️ Back] [🏠 Home]             │
└─────────────────────────────────┘
```

Features:
- ✅ No dead ends
- ✅ Always return to previous menu
- ✅ Quick access to home
- ✅ No message duplication
- ✅ Proper callback handling
- ✅ Edit messages instead of new ones

---

## 🔄 Status Indicators

```
Campaign Status:
  🟢 Active - Available for tasks
  🔴 Paused - Cannot complete tasks
  ⚫ Completed - All slots filled

Deposit Status:
  ⏳ Pending - Waiting admin review
  ✅ Approved - Tokens added
  ❌ Rejected - Not processed

Task Status:
  🔓 Available - Can complete
  ✅ Completed - Already done
  🚫 Ineligible - Creator/already done

Membership Status:
  ✅ Joined - Can verify
  ❌ Not Joined - Join first
```

---

## 📱 Button Types

```
TEXT BUTTONS (Main Menu):
[🏠 Home] [💰 Earn]
[📢 Create] [💳 Deposit]

INLINE BUTTONS (Submenus):
[🔎 Available Tasks]
[📊 My Completed Tasks]
[⬅️ Back] [🏠 Home]

LINK BUTTONS:
[🔗 Join Channel] - Opens https://t.me/channel

CALLBACK BUTTONS:
All buttons use callback_data for handling
No message reloads, just edits
```

---

This completes the bot's user interface and experience flow! 🎉
