# 🚀 MASTER SETUP GUIDE - ALL PLATFORMS

## 📦 YOU HAVE: `telegram_bot_complete.zip`

This single file contains everything you need!

---

## 📱 FOR ANDROID PHONE (RECOMMENDED)

### Install Termux App First
1. Open **Google Play Store**
2. Search **"Termux"**
3. Install by **Fredrik Fornwall**

### Copy-Paste This Entire Command:

```bash
apt update && apt upgrade -y && apt install python3 git wget zip unzip -y && mkdir -p ~/bot && cd ~/bot && unzip telegram_bot_complete.zip && cd telegram_bot/telegram_bot && pip install --upgrade pip --quiet && pip install -r requirements.txt --quiet && echo "✓ Setup complete! Bot ready to run." && echo "Run this to start: python main.py"
```

### Then Run:
```bash
python main.py
```

**That's it! Your bot is running! 🎉**

---

## 💻 FOR WINDOWS PC

### Quick Setup (One Click)

1. **Extract the ZIP file** to a folder
2. **Double-click** `setup.bat` file
3. It will:
   - Check Python
   - Install dependencies
   - Show success message

### Or Use Command Prompt:

1. Open **Command Prompt** (Win+R, type `cmd`)
2. Navigate to bot folder:
```cmd
cd path\to\telegram_bot_complete
```

3. Copy-paste this:
```cmd
cd telegram_bot && pip install -r requirements.txt && python main.py
```

---

## 🍎 FOR MAC

### Open Terminal (Cmd+Space, type "Terminal")

```bash
# Install Homebrew if needed
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install Python3
brew install python3

# Navigate to bot
cd ~/Downloads/telegram_bot_complete/telegram_bot/telegram_bot

# Install dependencies
pip3 install -r requirements.txt

# Run bot
python3 main.py
```

---

## 🐧 FOR LINUX (Ubuntu/Debian)

### One Command Setup:

```bash
cd ~/telegram_bot_complete/telegram_bot/telegram_bot && python3 -m venv venv && source venv/bin/activate && pip install -r requirements.txt && python3 main.py
```

### Or Step-by-Step:

```bash
# Extract
unzip telegram_bot_complete.zip

# Navigate
cd telegram_bot/telegram_bot

# Install
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Run
python3 main.py
```

---

## 🚀 QUICKEST POSSIBLE SETUP

### If you already have Python 3 installed:

#### Windows:
```cmd
cd telegram_bot\telegram_bot && pip install -r requirements.txt && python main.py
```

#### Mac/Linux/Termux:
```bash
cd telegram_bot/telegram_bot && pip install -r requirements.txt && python main.py
```

---

## ✅ VERIFY SETUP IS WORKING

When you see this in terminal, bot is running:
```
INFO:telegram.ext._application:Application started
INFO:root:Starting bot...
INFO:root:Database initialized successfully
```

Then:
1. Open **Telegram**
2. Find your bot
3. Send `/start`
4. **Bot responds!** ✓

---

## 🎯 STEP-BY-STEP FOR BEGINNERS

### Step 1: Get the Files
- Download `telegram_bot_complete.zip`
- Extract it to a folder

### Step 2: Open Terminal/Command Prompt
- **Windows**: Win+R → `cmd`
- **Mac**: Cmd+Space → `Terminal`
- **Linux**: Ctrl+Alt+T
- **Android**: Download Termux app

### Step 3: Navigate to Folder
```bash
cd path/to/telegram_bot_complete
cd telegram_bot
cd telegram_bot
```

### Step 4: Install Requirements
```bash
pip install -r requirements.txt
```
*(Takes 3-5 minutes)*

### Step 5: Run Bot
```bash
python main.py
```

### Step 6: Test Bot
- Open Telegram
- Send `/start` to bot
- See the response!

---

## 🔧 TROUBLESHOOTING

### "python: command not found"
```bash
# Try python3
python3 main.py
```

### "pip: command not found"
```bash
# Try pip3
pip3 install -r requirements.txt
```

### "ModuleNotFoundError"
```bash
# Reinstall packages
pip install -r requirements.txt --force-reinstall --no-cache-dir
```

### "Permission denied"
```bash
# On Mac/Linux
chmod +x main.py
python main.py
```

### "Database is locked"
```bash
# Delete database
rm bot_database.db
python main.py
```

### Installation too slow
```bash
# Install without cache
pip install -r requirements.txt --no-cache-dir
```

---

## 🛠️ BEFORE RUNNING

Update `config.py` in the `telegram_bot` folder:

Change these two lines:
```python
UPI_ID = "dummy@paytm"          # → Your UPI ID
BOT_USERNAME = "YourBotUsername" # → Your bot name
```

Keep these unchanged (already configured):
```python
BOT_TOKEN = "8438773973:AAHzZUXMjUw6whaZI9pG7wr3IWGj30xiFww"
ADMIN_ID = 8301300209
```

---

## ⏸️ STOP BOT

Press: **Ctrl + C**

---

## 🔄 RESTART BOT

```bash
# Ctrl + C (stop)
python main.py  # (restart)
```

---

## 📊 MONITOR BOT

### View running processes
```bash
ps aux | grep main.py
```

### Check database
```bash
sqlite3 bot_database.db ".tables"
```

### View logs (if saved)
```bash
tail -f bot.log
```

---

## 🎓 AFTER SETUP

### To see all features:
- Read `START_HERE.md`
- Read `PHONE_SETUP_GUIDE.md` (for mobile)
- Read `TERMINAL_COMMANDS.md` (for detailed commands)

### Admin commands:
From your admin Telegram account:
```
/stats              - See statistics
/pending            - See pending deposits
/approve_deposit 1  - Approve deposit
/broadcast message  - Send to all users
```

---

## 📱 PHONE-SPECIFIC

### Keep bot running on Android:

```bash
# Install screen
apt install screen

# Run in background
screen -S mybot
python main.py

# Detach: Ctrl+A then D
# Reattach: screen -r mybot
```

### Keep phone awake:
- Settings → Display → Sleep (30 min)
- Settings → Battery → Battery Saver (OFF)

---

## 🔐 IMPORTANT

**Never share:**
- `config.py` file
- Bot token
- UPI credentials
- Admin ID

**Backup regularly:**
```bash
cp bot_database.db bot_database.backup.db
```

---

## ✨ MINIMAL COMMAND (COPY-PASTE)

### For Phone (Termux):
```bash
apt update && apt install python3 zip unzip pip -y && cd ~ && unzip telegram_bot_complete.zip && cd telegram_bot/telegram_bot && pip install -r requirements.txt && python main.py
```

### For Desktop:
Navigate to folder, then:
```bash
pip install -r requirements.txt && python main.py
```

---

## 📋 FINAL CHECKLIST

Before running:
- ☑️ Python installed
- ☑️ ZIP extracted
- ☑️ In correct directory
- ☑️ requirements.txt found
- ☑️ config.py updated
- ☑️ Internet connected

---

## 🎉 SUCCESS!

When bot starts, you see:
```
Application started
Starting bot...
Database initialized successfully
```

Then test with `/start` on Telegram!

---

## 📞 QUICK HELP

| Problem | Solution |
|---------|----------|
| Python not found | Install Python 3.11+ |
| pip not found | Use pip3 or reinstall Python |
| Module not found | Run `pip install -r requirements.txt` |
| Bot not responding | Check internet, restart bot |
| Database locked | Delete bot_database.db |
| Too slow | Use `--no-cache-dir` flag |

---

## 🚀 YOU'RE READY!

Choose your platform:
- **Phone?** → `PHONE_SETUP_GUIDE.md`
- **Desktop?** → Copy commands from above
- **More details?** → `TERMINAL_COMMANDS.md`

---

**Your bot will be live in 5 minutes! 🎉**

Questions? Check the documentation files included in your ZIP!
