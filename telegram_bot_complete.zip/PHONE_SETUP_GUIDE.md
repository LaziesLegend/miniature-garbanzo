# 📱 RUN BOT ON ANDROID PHONE (Termux Guide)

## 🎯 COMPLETE STEP-BY-STEP GUIDE FOR BEGINNERS

### What You'll Need
- ✅ Android phone
- ✅ Termux app (free)
- ✅ Internet connection
- ✅ The `telegram_bot_complete.zip` file

---

## STEP 1️⃣: INSTALL TERMUX ON YOUR PHONE

### Download Termux
1. Open **Google Play Store**
2. Search for **"Termux"**
3. Download the app by **Fredrik Fornwall**
4. Install it

### Open Termux
- Tap the Termux app icon
- You'll see a black terminal screen

---

## STEP 2️⃣: UPDATE TERMUX

Copy and paste this into Termux (long-press to paste):

```bash
apt update && apt upgrade -y
```

Press **Enter**. This may take a few minutes.

---

## STEP 3️⃣: INSTALL REQUIRED TOOLS

Copy and paste this:

```bash
apt install python3 git wget zip unzip -y
```

Press **Enter**. Wait for installation to complete.

---

## STEP 4️⃣: CREATE BOT DIRECTORY

Copy and paste this:

```bash
mkdir -p ~/bot
cd ~/bot
```

Press **Enter**.

---

## STEP 5️⃣: GET THE BOT FILES

### Option A: If you have the ZIP file on your phone

Copy this command (replace filename if needed):

```bash
# Copy from Downloads folder (if file is there)
cp /sdcard/Download/telegram_bot_complete.zip .
```

Then extract it:

```bash
unzip telegram_bot_complete.zip
```

### Option B: Download directly from GitHub

```bash
# If you have it on GitHub
git clone [your-repo-url]
cd telegram_bot
```

---

## STEP 6️⃣: NAVIGATE TO BOT FOLDER

Copy and paste:

```bash
cd telegram_bot
cd telegram_bot
```

Press **Enter**.

Check the files:

```bash
ls -la
```

You should see:
- `main.py`
- `config.py`
- `requirements.txt`
- `handlers/`
- `services/`

---

## STEP 7️⃣: INSTALL PYTHON PACKAGES

Copy and paste:

```bash
pip install -r requirements.txt
```

**⏰ This takes 5-10 minutes. Be patient!**

You'll see installation progress. Wait for it to say "Successfully installed..."

---

## STEP 8️⃣: UPDATE CONFIGURATION (IMPORTANT!)

Edit the config file:

```bash
nano config.py
```

Look for these lines and update them:

```python
UPI_ID = "dummy@paytm"          # Change to your UPI ID
BOT_USERNAME = "YourBotUsername" # Change to your bot username
```

To edit in nano:
1. Find the line with cursor (down arrow key)
2. Long-press and select the text
3. Delete it
4. Type your new value

Save and exit:
- Press `Ctrl + X`
- Press `Y` (yes)
- Press `Enter`

---

## STEP 9️⃣: RUN THE BOT! 🎉

Copy and paste:

```bash
python main.py
```

Press **Enter**.

### You should see:
```
INFO:telegram.ext._application:Application started
INFO:root:Starting bot...
INFO:root:Database initialized successfully
```

**Congratulations! Your bot is running! 🚀**

---

## STEP 10️⃣: TEST THE BOT

1. Open **Telegram** on your phone
2. Search for your bot
3. Send `/start`
4. You should see the bot respond!

---

## ⏹️ STOP THE BOT

When running, press: **Ctrl + C**

---

## 🔄 RESTART THE BOT

Press **Ctrl + C** to stop, then:

```bash
python main.py
```

To start again.

---

## 🎯 KEEP BOT RUNNING IN BACKGROUND

After starting the bot normally, press:

**Ctrl + A** then **D**

This detaches the bot. You can close Termux or use it for other commands.

To see the bot again:

```bash
screen -r botname
```

---

## 📱 TERMUX TIPS FOR PHONE

### Copy Text
- Long-press to select
- Long-press again to copy

### Paste Text
- Long-press in terminal
- Select "Paste"

### Keyboard
- Swipe from left edge to show extra keys
- Or use Ctrl, Alt, etc. from the keyboard

### Common Shortcuts
- `Ctrl + C` - Stop running command
- `Ctrl + A` - Go to start of line
- `Ctrl + E` - Go to end of line
- `Ctrl + L` - Clear screen
- Up arrow - Previous command

### Check Bot Status
```bash
ps aux | grep main.py
```

If running, you'll see the process listed.

---

## 🆘 COMMON ISSUES ON PHONE

### Issue 1: "No module named 'telegram'"
```bash
pip install python-telegram-bot --upgrade
```

### Issue 2: "ModuleNotFoundError"
```bash
# Try installing all again
pip install -r requirements.txt --no-cache-dir
```

### Issue 3: "Permission denied"
```bash
chmod +x main.py
python main.py
```

### Issue 4: Storage Issues
```bash
# Check available space
df -h

# Clear cache
apt clean
```

### Issue 5: Database locked
```bash
rm bot_database.db
python main.py
```

---

## 📊 MONITOR BOT ON PHONE

### View real-time logs
The logs show in the terminal automatically while bot runs.

### Check database
```bash
# See all tables
sqlite3 bot_database.db ".tables"

# Count users
sqlite3 bot_database.db "SELECT COUNT(*) FROM users;"
```

---

## 🔐 PHONE SECURITY TIPS

### Protect your database
```bash
# Backup database
cp bot_database.db bot_database.backup.db

# List backups
ls -la *.backup.db
```

### Protect your config
- Don't share your config.py file
- Don't show your bot token to anyone
- Don't share your UPI credentials

---

## ⚡ KEEP BOT RUNNING FOREVER

### Option 1: Using Screen (Easiest)

First time:
```bash
apt install screen
screen -S mybot
python main.py
```

Detach: **Ctrl + A**, then **D**

Next time:
```bash
screen -r mybot
```

### Option 2: Keep Phone Awake
- Go to Settings → Battery → Battery Saver (OFF)
- Go to Settings → Display → Sleep (set to 30 minutes)
- Go to Settings → Developer Options → Stay Awake (ON)

### Option 3: Use Autostart (Advanced)
```bash
apt install termux-api
# Then set up boot script
```

---

## 📈 USEFUL COMMANDS

### View running processes
```bash
ps aux | grep python
```

### View directory
```bash
ls -la
```

### Go back to home
```bash
cd ~
```

### Go back one folder
```bash
cd ..
```

### Show current location
```bash
pwd
```

### Create new folder
```bash
mkdir newfolder
```

### Delete file
```bash
rm filename
```

### Delete folder
```bash
rm -rf foldername
```

---

## 🎮 MANAGING THE BOT

### While bot is running:
- Users can interact with it on Telegram
- Each interaction is processed
- Database stores all data

### Admin commands:
From **your admin Telegram account**:
- `/stats` - See platform statistics
- `/pending` - See pending deposits
- `/approve_deposit 1` - Approve a deposit
- etc.

---

## 🚨 EMERGENCY STOP

If anything goes wrong:

```bash
# Ctrl + C (stop bot)
# or
# Ctrl + D (exit Termux)
```

Restart fresh:
```bash
python main.py
```

---

## ✅ CHECKLIST BEFORE RUNNING

- ☑️ Termux installed
- ☑️ Python3 installed (`python3 --version`)
- ☑️ Files extracted (`ls telegram_bot/`)
- ☑️ In correct directory (`pwd`)
- ☑️ Dependencies installed (`pip list | grep telegram`)
- ☑️ Config updated (UPI_ID, BOT_USERNAME)
- ☑️ Bot token in config is correct

---

## 📞 QUICK COMMANDS TO COPY

### Complete setup in one command:
```bash
apt update && apt install python3 zip unzip -y && mkdir ~/bot && cd ~/bot && unzip telegram_bot_complete.zip && cd telegram_bot/telegram_bot && pip install -r requirements.txt && python main.py
```

### Just run bot (after setup):
```bash
cd ~/bot/telegram_bot/telegram_bot && python main.py
```

### Stop and restart:
```bash
# Ctrl + C
python main.py
```

---

## 🎓 LEARNING

**If you want to understand the code:**
- Read `README.md` in the bot folder
- Read `QUICK_REFERENCE.md` for developer tips
- Check `MENU_STRUCTURE.md` for how bot works

---

## 🎉 SUCCESS INDICATORS

When you run `python main.py`, you should see:

```
INFO:telegram.ext._application:Application started
INFO:root:Starting bot...
INFO:root:Database initialized successfully
```

Then go to Telegram and send `/start` to your bot. You should get a response!

---

## 🆘 NEED HELP?

### Bot not responding:
- Check internet connection
- Check bot token in config.py
- Check bot is running (it should show messages in terminal)
- Restart the bot

### Installation failing:
- Update Termux first: `apt update && apt upgrade`
- Clear cache: `apt clean`
- Try again: `pip install -r requirements.txt --no-cache-dir`

### Phone getting hot:
- This is normal while installing
- Check if bot is still running: `ps aux | grep main.py`
- If not, restart it

---

## 📱 PHONE-SPECIFIC TIPS

### If screen locks:
- Bot still runs in background
- Just reopen Termux and check: `screen -ls`

### If you want notifications:
- Telegram app will notify you of new messages
- Bot processes them automatically

### Backup important:
```bash
# Before doing anything risky
cp bot_database.db backup_$(date +%s).db
```

---

## 🏁 YOU'RE ALL SET!

Your Telegram bot is now running on your Android phone! 🎉

**Next steps:**
1. Share the bot link with friends
2. Monitor with `/stats` command
3. Approve deposits with `/approve_deposit`
4. Keep phone powered and internet on

**Enjoy! 🚀**

---

## 📱 FINAL COMMAND FOR YOUR PHONE

Just copy and paste this ONE TIME:

```bash
apt update && apt upgrade -y && apt install python3 git wget zip unzip -y && mkdir -p ~/bot && cd ~/bot && unzip telegram_bot_complete.zip 2>/dev/null || echo "Place zip file first" && cd telegram_bot/telegram_bot && pip install -r requirements.txt && echo "Setup complete! Run: python main.py"
```

Then run:
```bash
python main.py
```

That's it! Your bot is live! 🎉
