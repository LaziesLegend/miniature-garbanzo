#!/bin/bash

# Telegram Bot - Quick Start Script
# This script automatically sets up and runs the bot

echo "╔════════════════════════════════════════════════════╗"
echo "║   🤖 TELEGRAM TOKEN BOT - AUTOMATIC SETUP 🤖      ║"
echo "╚════════════════════════════════════════════════════╝"
echo ""

# Check if Python is installed
echo "✓ Checking Python installation..."
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 not found. Please install Python 3.11+"
    exit 1
fi

PYTHON_VERSION=$(python3 --version)
echo "✓ Found: $PYTHON_VERSION"
echo ""

# Check if requirements.txt exists
if [ ! -f "telegram_bot/requirements.txt" ]; then
    echo "❌ requirements.txt not found!"
    echo "Make sure you're in the correct directory with extracted files"
    exit 1
fi

# Create virtual environment (optional)
echo "💾 Setting up environment..."
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
    echo "✓ Virtual environment activated"
fi

# Navigate to telegram_bot directory
cd telegram_bot || exit 1

# Install dependencies
echo ""
echo "📦 Installing dependencies..."
echo "This may take a few minutes..."
pip install --upgrade pip --quiet
pip install -r requirements.txt --quiet

if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies"
    exit 1
fi

echo "✓ Dependencies installed successfully"
echo ""

# Check config
echo "⚙️  Checking configuration..."
if grep -q "dummy@paytm" config.py; then
    echo "⚠️  WARNING: UPI_ID still set to 'dummy@paytm'"
    echo "   Please update config.py with your actual UPI ID"
fi

if grep -q "YourBotUsername" config.py; then
    echo "⚠️  WARNING: BOT_USERNAME still set to 'YourBotUsername'"
    echo "   Please update config.py with your actual bot username"
fi

echo ""
echo "╔════════════════════════════════════════════════════╗"
echo "║          ✨ SETUP COMPLETE! ✨                    ║"
echo "╚════════════════════════════════════════════════════╝"
echo ""
echo "📝 Configuration Status:"
echo "   • Python: ✓"
echo "   • Dependencies: ✓"
echo "   • Database: Will auto-create on start"
echo ""
echo "🚀 Ready to run! Execute:"
echo "   python main.py"
echo ""
echo "💡 Tips:"
echo "   • The bot creates bot_database.db automatically"
echo "   • Press Ctrl+C to stop the bot"
echo "   • Check logs for any errors"
echo ""
