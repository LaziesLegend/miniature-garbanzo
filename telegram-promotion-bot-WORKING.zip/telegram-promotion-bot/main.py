import logging
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    ConversationHandler,
    filters
)

from config import BOT_TOKEN, ADMIN_ID
from database import Database
from monitoring import monitor_user_tasks
from handlers.start import start_command
from handlers.menu import get_main_menu
from handlers.wallet import balance_callback, transactions_callback
from handlers.campaign import (
    create_campaign_callback,
    campaign_members_selected,
    campaign_channel_received,
    my_campaigns_callback,
    cancel_campaign,
    CAMPAIGN_MEMBERS,
    CAMPAIGN_CHANNEL
)
from handlers.deposit import (
    deposit_callback,
    deposit_amount_received,
    deposit_method_selected,
    deposit_network_selected,
    deposit_proof_received,
    cancel_deposit,
    DEPOSIT_AMOUNT,
    DEPOSIT_METHOD,
    DEPOSIT_NETWORK,
    DEPOSIT_PROOF
)
from handlers.referral import referral_callback
from handlers.earning import (
    earning_menu_callback,
    join_earn_callback,
    join_task_callback,
    verify_join_callback,
    my_tasks_callback,
    daily_bonus_callback,
    gamble_callback,
    gamble_bet_callback
)
from handlers.admin import (
    admin_panel_callback,
    admin_stats_callback,
    admin_deposits_callback,
    admin_approve_deposit,
    admin_reject_deposit,
    admin_add_tokens_start,
    admin_add_tokens_process,
    admin_broadcast_start,
    admin_broadcast_process,
    admin_reset_db_confirm,
    admin_reset_db_execute,
    ADMIN_ADD_TOKENS,
    ADMIN_BROADCAST
)

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

async def main_menu_callback(update: Update, context):
    """Return to main menu"""
    query = update.callback_query
    await query.answer()
    
    text = "🏠 <b>Main Menu</b>\n\nChoose an option:"
    
    await query.edit_message_text(
        text,
        reply_markup=get_main_menu(query.from_user.id),
        parse_mode='HTML'
    )

async def handle_keyboard_buttons(update: Update, context):
    """Handle keyboard button presses"""
    text = update.message.text
    user_id = update.effective_user.id
    
    # Map keyboard buttons to callback handlers
    if text == "💰 Balance":
        # Simulate callback query for balance
        from handlers.wallet import balance_callback
        # Create a mock update with callback query
        await update.message.reply_text("Loading balance...", parse_mode='HTML')
        # Get balance directly
        from database import Database
        db = Database()
        balance = db.get_user_balance(user_id)
        
        balance_text = f"""
💰 <b>Your Wallet Balance</b>

Current Balance: <b>{balance} tokens</b>

You can use tokens to create promotion campaigns.
Need more tokens? Use the Deposit button!
"""
        await update.message.reply_text(
            balance_text,
            reply_markup=get_back_button(),
            parse_mode='HTML'
        )
    
    elif text == "🚀 Create Promotion":
        await update.message.reply_text(
            "🚀 <b>Create Campaign</b>\n\nPlease use the inline button to create a campaign.",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🚀 Start Campaign", callback_data="create_campaign")
            ]]),
            parse_mode='HTML'
        )
    
    elif text == "📊 My Campaigns":
        from database import Database
        db = Database()
        campaigns = db.get_user_campaigns(user_id)
        
        if not campaigns:
            campaigns_text = "📊 <b>My Campaigns</b>\n\nYou haven't created any campaigns yet."
        else:
            campaigns_text = "📊 <b>My Campaigns</b>\n\n"
            
            for camp in campaigns[:10]:
                status_emoji = {
                    'active': '🟢',
                    'completed': '✅',
                    'pending': '🟡',
                    'cancelled': '❌'
                }.get(camp['status'], '⚪')
                
                campaigns_text += f"{status_emoji} <b>Campaign #{camp['id']}</b>\n"
                campaigns_text += f"Channel: {camp['channel_link']}\n"
                campaigns_text += f"Members: {camp['delivered_members']}/{camp['target_members']}\n"
                campaigns_text += f"Status: {camp['status'].capitalize()}\n"
                campaigns_text += f"Created: {camp['created_at'][:10]}\n\n"
        
        await update.message.reply_text(
            campaigns_text,
            reply_markup=get_back_button(),
            parse_mode='HTML'
        )
    
    elif text == "💳 Deposit Tokens":
        await update.message.reply_text(
            "💳 <b>Deposit Tokens</b>\n\nClick below to start deposit process:",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("💳 Start Deposit", callback_data="deposit")
            ]]),
            parse_mode='HTML'
        )
    
    elif text == "👥 Referral":
        from database import Database
        from config import REFERRAL_BONUS
        db = Database()
        
        bot_username = context.bot.username
        referral_link = f"https://t.me/{bot_username}?start={user_id}"
        
        referral_count = db.get_referral_count(user_id)
        total_earned = referral_count * REFERRAL_BONUS
        
        referral_text = f"""
👥 <b>Referral Program</b>

Invite friends and earn {REFERRAL_BONUS} tokens for each referral!

<b>Your Stats:</b>
• Total Referrals: {referral_count}
• Tokens Earned: {total_earned}

<b>Your Referral Link:</b>
<code>{referral_link}</code>

<i>Tap to copy the link and share with friends!</i>

💡 <b>How it works:</b>
1. Share your referral link
2. Friend joins using your link
3. You get {REFERRAL_BONUS} tokens instantly!
"""
        
        await update.message.reply_text(
            referral_text,
            reply_markup=get_back_button(),
            parse_mode='HTML'
        )
    
    elif text == "📜 Transactions":
        from database import Database
        db = Database()
        
        transactions = db.get_user_transactions(user_id, limit=10)
        
        if not transactions:
            trans_text = "📜 <b>Transaction History</b>\n\nNo transactions yet."
        else:
            trans_text = "📜 <b>Recent Transactions</b>\n\n"
            
            for trans in transactions:
                trans_type = trans['type'].capitalize()
                amount = trans['amount']
                desc = trans['description']
                timestamp = trans['timestamp'][:16]
                
                if trans['type'] in ['deposit', 'bonus', 'admin_adjustment']:
                    amount_str = f"+{amount}"
                else:
                    amount_str = f"-{amount}"
                
                trans_text += f"• {trans_type}: {amount_str} tokens\n"
                trans_text += f"  {desc}\n"
                trans_text += f"  <i>{timestamp}</i>\n\n"
        
        await update.message.reply_text(
            trans_text,
            reply_markup=get_back_button(),
            parse_mode='HTML'
        )
    
    elif text == "🎯 Earning":
        await update.message.reply_text(
            "🎯 <b>Earning Menu</b>\n\nClick below to see earning options:",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("💰 Earn Tokens", callback_data="earning_menu")
            ]]),
            parse_mode='HTML'
        )

async def error_handler(update: Update, context):
    """Handle errors"""
    logger.error(f"Update {update} caused error {context.error}")
    
    try:
        if update.effective_message:
            await update.effective_message.reply_text(
                "❌ An error occurred. Please try again or contact support."
            )
    except:
        pass

def main():
    """Start the bot"""
    # Initialize database
    db = Database()
    logger.info("Database initialized")
    
    # Create application
    app = Application.builder().token(BOT_TOKEN).build()
    
    # Campaign conversation handler
    campaign_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(create_campaign_callback, pattern='^create_campaign$')],
        states={
            CAMPAIGN_MEMBERS: [
                CallbackQueryHandler(campaign_members_selected, pattern='^campaign_members_'),
                CallbackQueryHandler(cancel_campaign, pattern='^main_menu$')
            ],
            CAMPAIGN_CHANNEL: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, campaign_channel_received)
            ]
        },
        fallbacks=[CallbackQueryHandler(cancel_campaign, pattern='^main_menu$')],
        allow_reentry=True
    )
    
    # Deposit conversation handler
    deposit_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(deposit_callback, pattern='^deposit$')],
        states={
            DEPOSIT_AMOUNT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, deposit_amount_received),
                CallbackQueryHandler(cancel_deposit, pattern='^main_menu$')
            ],
            DEPOSIT_METHOD: [
                CallbackQueryHandler(deposit_method_selected, pattern='^deposit_method_'),
                CallbackQueryHandler(cancel_deposit, pattern='^main_menu$')
            ],
            DEPOSIT_NETWORK: [
                CallbackQueryHandler(deposit_network_selected, pattern='^deposit_network_'),
                CallbackQueryHandler(deposit_callback, pattern='^deposit$')
            ],
            DEPOSIT_PROOF: [
                MessageHandler(
                    (filters.TEXT | filters.PHOTO) & ~filters.COMMAND, 
                    deposit_proof_received
                )
            ]
        },
        fallbacks=[CallbackQueryHandler(cancel_deposit, pattern='^main_menu$')],
        allow_reentry=True
    )
    
    # Admin add tokens handler
    admin_add_tokens_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(admin_add_tokens_start, pattern='^admin_add_tokens$')],
        states={
            ADMIN_ADD_TOKENS: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, admin_add_tokens_process)
            ]
        },
        fallbacks=[],
        allow_reentry=True
    )
    
    # Admin broadcast handler
    admin_broadcast_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(admin_broadcast_start, pattern='^admin_broadcast$')],
        states={
            ADMIN_BROADCAST: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, admin_broadcast_process)
            ]
        },
        fallbacks=[],
        allow_reentry=True
    )
    
    # Add handlers
    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(campaign_handler)
    app.add_handler(deposit_handler)
    app.add_handler(admin_add_tokens_handler)
    app.add_handler(admin_broadcast_handler)
    
    # Keyboard button handler (must be before callback handlers)
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND, 
        handle_keyboard_buttons
    ))
    
    # Callback query handlers
    app.add_handler(CallbackQueryHandler(main_menu_callback, pattern='^main_menu$'))
    app.add_handler(CallbackQueryHandler(balance_callback, pattern='^balance$'))
    app.add_handler(CallbackQueryHandler(transactions_callback, pattern='^transactions$'))
    app.add_handler(CallbackQueryHandler(my_campaigns_callback, pattern='^my_campaigns$'))
    app.add_handler(CallbackQueryHandler(referral_callback, pattern='^referral$'))
    
    # Earning handlers
    app.add_handler(CallbackQueryHandler(earning_menu_callback, pattern='^earning_menu$'))
    app.add_handler(CallbackQueryHandler(join_earn_callback, pattern='^earn_join$'))
    app.add_handler(CallbackQueryHandler(join_task_callback, pattern='^join_task_'))
    app.add_handler(CallbackQueryHandler(verify_join_callback, pattern='^verify_join_'))
    app.add_handler(CallbackQueryHandler(my_tasks_callback, pattern='^earn_my_tasks$'))
    app.add_handler(CallbackQueryHandler(daily_bonus_callback, pattern='^earn_daily$'))
    app.add_handler(CallbackQueryHandler(gamble_callback, pattern='^earn_gamble$'))
    app.add_handler(CallbackQueryHandler(gamble_bet_callback, pattern='^gamble_bet_'))
    
    # Admin handlers
    app.add_handler(CallbackQueryHandler(admin_panel_callback, pattern='^admin_panel$'))
    app.add_handler(CallbackQueryHandler(admin_stats_callback, pattern='^admin_stats$'))
    app.add_handler(CallbackQueryHandler(admin_deposits_callback, pattern='^admin_deposits$'))
    app.add_handler(CallbackQueryHandler(admin_approve_deposit, pattern='^admin_approve_'))
    app.add_handler(CallbackQueryHandler(admin_reject_deposit, pattern='^admin_reject_'))
    app.add_handler(CallbackQueryHandler(admin_reset_db_confirm, pattern='^admin_reset_db$'))
    app.add_handler(CallbackQueryHandler(admin_reset_db_execute, pattern='^admin_reset_confirmed$'))
    
    # Error handler
    app.add_error_handler(error_handler)
    
    # Start bot
    logger.info("Bot started successfully!")
    logger.info(f"Admin ID: {ADMIN_ID}")
    logger.info("Background monitoring enabled (runs every 6 hours)")
    
    # Start monitoring in background using job queue
    from telegram.ext import JobQueue
    
    async def start_monitoring_job(context):
        """Job to run monitoring task"""
        await monitor_user_tasks(context)
    
    # Schedule monitoring job to run every 6 hours
    app.job_queue.run_repeating(
        start_monitoring_job,
        interval=21600,  # 6 hours in seconds
        first=60  # Start after 60 seconds
    )
    
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
