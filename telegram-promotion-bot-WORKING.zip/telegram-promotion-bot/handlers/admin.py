from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from database import Database
from handlers.menu import get_back_button, get_main_menu
from config import ADMIN_ID
import logging

logger = logging.getLogger(__name__)

# Conversation states
ADMIN_ADD_TOKENS, ADMIN_DEDUCT_TOKENS, ADMIN_BROADCAST, ADMIN_DELETE_USER = range(4)

def is_admin(user_id: int) -> bool:
    """Check if user is admin"""
    return user_id == ADMIN_ID

async def admin_panel_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show admin panel"""
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        await query.answer("❌ Unauthorized", show_alert=True)
        return
    
    db = Database()
    
    # Get statistics
    total_users = db.get_total_users()
    total_campaigns = db.get_total_campaigns()
    total_revenue = db.get_total_revenue()
    pending_deposits = len(db.get_pending_deposits())
    
    keyboard = [
        [
            InlineKeyboardButton("💰 Add Tokens", callback_data="admin_add_tokens"),
            InlineKeyboardButton("➖ Deduct Tokens", callback_data="admin_deduct_tokens")
        ],
        [
            InlineKeyboardButton("✅ Approve Deposits", callback_data="admin_deposits"),
            InlineKeyboardButton("📊 Statistics", callback_data="admin_stats")
        ],
        [
            InlineKeyboardButton("📢 Broadcast", callback_data="admin_broadcast"),
            InlineKeyboardButton("🗑️ Delete User", callback_data="admin_delete_user")
        ],
        [
            InlineKeyboardButton("⚠️ Reset DB", callback_data="admin_reset_db"),
            InlineKeyboardButton("🔙 Back", callback_data="main_menu")
        ]
    ]
    
    text = f"""
⚙️ <b>Admin Panel</b>

<b>Platform Statistics:</b>
👥 Total Users: {total_users}
📊 Total Campaigns: {total_campaigns}
💰 Total Revenue: {total_revenue} tokens
⏳ Pending Deposits: {pending_deposits}

Choose an action:
"""
    
    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def admin_stats_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show detailed statistics"""
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        return
    
    db = Database()
    
    total_users = db.get_total_users()
    total_campaigns = db.get_total_campaigns()
    total_revenue = db.get_total_revenue()
    
    text = f"""
📊 <b>Detailed Statistics</b>

<b>Users:</b>
• Total Registered: {total_users}

<b>Campaigns:</b>
• Total Created: {total_campaigns}

<b>Revenue:</b>
• Platform Fees Collected: {total_revenue} tokens

<b>System Status:</b>
✅ All systems operational
"""
    
    keyboard = [[InlineKeyboardButton("🔙 Back to Admin", callback_data="admin_panel")]]
    
    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def admin_deposits_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show pending deposits"""
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        return
    
    db = Database()
    deposits = db.get_pending_deposits()
    
    if not deposits:
        text = "✅ No pending deposits!"
        keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="admin_panel")]]
    else:
        text = "⏳ <b>Pending Deposits</b>\n\n"
        keyboard = []
        
        for dep in deposits[:10]:
            text += f"ID: #{dep['id']} | User: {dep['user_id']}\n"
            text += f"Amount: {dep['amount']} tokens | Method: {dep['method']}\n"
            text += f"Proof: {dep['tx_hash']}\n\n"
            
            keyboard.append([
                InlineKeyboardButton(
                    f"✅ Approve #{dep['id']}", 
                    callback_data=f"admin_approve_{dep['id']}"
                ),
                InlineKeyboardButton(
                    f"❌ Reject #{dep['id']}", 
                    callback_data=f"admin_reject_{dep['id']}"
                )
            ])
        
        keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="admin_panel")])
    
    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def admin_approve_deposit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Approve deposit"""
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        return
    
    deposit_id = int(query.data.split('_')[-1])
    db = Database()
    
    deposit = db.get_deposit(deposit_id)
    
    if not deposit:
        await query.answer("❌ Deposit not found", show_alert=True)
        return
    
    if deposit['status'] != 'pending':
        await query.answer("❌ Deposit already processed", show_alert=True)
        return
    
    # Approve deposit
    db.update_deposit_status(deposit_id, 'approved')
    db.update_user_tokens(deposit['user_id'], deposit['amount'])
    db.add_transaction(
        deposit['user_id'],
        'deposit',
        deposit['amount'],
        f"Deposit #{deposit_id} approved"
    )
    
    # Notify user
    try:
        await context.bot.send_message(
            chat_id=deposit['user_id'],
            text=f"✅ Your deposit of {deposit['amount']} tokens has been approved!"
        )
    except Exception as e:
        logger.error(f"Failed to notify user: {e}")
    
    await query.answer("✅ Deposit approved!", show_alert=True)
    
    # Refresh deposits list
    await admin_deposits_callback(update, context)

async def admin_reject_deposit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Reject deposit"""
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        return
    
    deposit_id = int(query.data.split('_')[-1])
    db = Database()
    
    deposit = db.get_deposit(deposit_id)
    
    if not deposit:
        await query.answer("❌ Deposit not found", show_alert=True)
        return
    
    if deposit['status'] != 'pending':
        await query.answer("❌ Deposit already processed", show_alert=True)
        return
    
    # Reject deposit
    db.update_deposit_status(deposit_id, 'rejected')
    
    # Notify user
    try:
        await context.bot.send_message(
            chat_id=deposit['user_id'],
            text=f"❌ Your deposit request #{deposit_id} has been rejected. Please contact support."
        )
    except Exception as e:
        logger.error(f"Failed to notify user: {e}")
    
    await query.answer("❌ Deposit rejected!", show_alert=True)
    
    # Refresh deposits list
    await admin_deposits_callback(update, context)

async def admin_add_tokens_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start add tokens process"""
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        return
    
    text = """
💰 <b>Add Tokens to User</b>

Send message in format:
<code>user_id amount</code>

Example: <code>123456789 1000</code>
"""
    
    await query.edit_message_text(text, parse_mode='HTML')
    
    return ADMIN_ADD_TOKENS

async def admin_add_tokens_process(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Process add tokens"""
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END
    
    try:
        parts = update.message.text.strip().split()
        user_id = int(parts[0])
        amount = int(parts[1])
        
        db = Database()
        db.update_user_tokens(user_id, amount)
        db.add_transaction(
            user_id,
            'admin_adjustment',
            amount,
            f"Admin added {amount} tokens"
        )
        
        await update.message.reply_text(
            f"✅ Added {amount} tokens to user {user_id}",
            reply_markup=get_back_button()
        )
        
        # Notify user
        try:
            await context.bot.send_message(
                chat_id=user_id,
                text=f"🎁 Admin added {amount} tokens to your account!"
            )
        except:
            pass
        
    except Exception as e:
        await update.message.reply_text(
            f"❌ Error: {str(e)}\n\nFormat: user_id amount",
            reply_markup=get_back_button()
        )
    
    return ConversationHandler.END

async def admin_broadcast_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start broadcast"""
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        return
    
    text = """
📢 <b>Broadcast Message</b>

Send the message you want to broadcast to all users:
"""
    
    await query.edit_message_text(text, parse_mode='HTML')
    
    return ADMIN_BROADCAST

async def admin_broadcast_process(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Process broadcast"""
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END
    
    message_text = update.message.text
    db = Database()
    
    # Get all users
    conn = db.get_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT user_id FROM users')
    users = cursor.fetchall()
    conn.close()
    
    success_count = 0
    fail_count = 0
    
    await update.message.reply_text("📢 Broadcasting...")
    
    for (user_id,) in users:
        try:
            await context.bot.send_message(chat_id=user_id, text=message_text)
            success_count += 1
        except Exception as e:
            fail_count += 1
            logger.error(f"Failed to send to {user_id}: {e}")
    
    await update.message.reply_text(
        f"✅ Broadcast complete!\n\nSuccess: {success_count}\nFailed: {fail_count}",
        reply_markup=get_back_button()
    )
    
    return ConversationHandler.END

async def admin_reset_db_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Confirm database reset"""
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        return
    
    keyboard = [
        [
            InlineKeyboardButton("⚠️ YES, RESET", callback_data="admin_reset_confirmed"),
            InlineKeyboardButton("❌ Cancel", callback_data="admin_panel")
        ]
    ]
    
    text = """
⚠️ <b>WARNING: Database Reset</b>

This will DELETE ALL DATA:
• All users
• All campaigns
• All transactions
• All deposits
• All referrals

Are you absolutely sure?
"""
    
    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def admin_reset_db_execute(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Execute database reset"""
    query = update.callback_query
    await query.answer()
    
    if not is_admin(query.from_user.id):
        return
    
    db = Database()
    db.reset_database()
    
    await query.edit_message_text(
        "✅ Database has been reset!",
        reply_markup=get_back_button()
    )
