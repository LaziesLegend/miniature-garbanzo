from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from database import Database
from handlers.menu import get_back_button
from config import ADMIN_ID, USDT_TRC20_ADDRESS, USDT_ERC20_ADDRESS, BTC_ADDRESS, BNB_ADDRESS
import logging

logger = logging.getLogger(__name__)

# Conversation states
DEPOSIT_AMOUNT, DEPOSIT_METHOD, DEPOSIT_NETWORK, DEPOSIT_PROOF = range(4)

# Anti-duplicate submission
depositing_users = set()

async def deposit_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start deposit process"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    
    # Anti-duplicate check
    if user_id in depositing_users:
        await query.answer("⚠️ Deposit in progress...", show_alert=True)
        return DEPOSIT_AMOUNT
    
    depositing_users.add(user_id)
    
    text = """
💳 <b>Deposit Tokens</b>

Enter the amount of tokens you want to deposit:

<i>Minimum: 100 tokens</i>
"""
    
    keyboard = [[InlineKeyboardButton("🔙 Cancel", callback_data="main_menu")]]
    
    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )
    
    return DEPOSIT_AMOUNT

async def deposit_amount_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle deposit amount"""
    user_id = update.effective_user.id
    
    try:
        amount = int(update.message.text.strip())
        
        if amount < 100:
            await update.message.reply_text(
                "❌ Minimum deposit is 100 tokens. Please try again:"
            )
            return DEPOSIT_AMOUNT
        
        context.user_data['deposit_amount'] = amount
        
        # Method selection with crypto options
        keyboard = [
            [InlineKeyboardButton("💳 UPI", callback_data="deposit_method_upi")],
            [InlineKeyboardButton("💎 USDT (Tether)", callback_data="deposit_method_usdt")],
            [InlineKeyboardButton("₿ Bitcoin (BTC)", callback_data="deposit_method_btc")],
            [InlineKeyboardButton("🔶 Binance Coin (BNB)", callback_data="deposit_method_bnb")],
            [InlineKeyboardButton("🔙 Cancel", callback_data="main_menu")]
        ]
        
        text = f"""
💳 <b>Deposit {amount} Tokens</b>

Select payment method:
"""
        
        await update.message.reply_text(
            text,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='HTML'
        )
        
        return DEPOSIT_METHOD
        
    except ValueError:
        await update.message.reply_text(
            "❌ Invalid amount. Please enter a number:"
        )
        return DEPOSIT_AMOUNT

async def deposit_method_selected(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle payment method selection"""
    query = update.callback_query
    await query.answer()
    
    method = query.data.split('_')[-1].upper()
    context.user_data['deposit_method'] = method
    
    amount = context.user_data.get('deposit_amount', 0)
    
    if method == 'UPI':
        payment_info = """
<b>UPI Payment Details:</b>

UPI ID: <code>payment@upi</code>
Name: Promotion Bot

Send payment and upload screenshot.
"""
        await query.edit_message_text(
            f"💳 <b>Deposit {amount} Tokens</b>\nMethod: UPI\n\n{payment_info}\n\nAfter payment, send your transaction proof (screenshot):",
            parse_mode='HTML'
        )
        return DEPOSIT_PROOF
        
    elif method == 'USDT':
        # Show network selection for USDT
        keyboard = [
            [InlineKeyboardButton("TRC20 (Tron)", callback_data="deposit_network_trc20")],
            [InlineKeyboardButton("ERC20 (Ethereum)", callback_data="deposit_network_erc20")],
            [InlineKeyboardButton("🔙 Back", callback_data="deposit")]
        ]
        
        text = f"""
💎 <b>USDT Deposit - {amount} Tokens</b>

Select network:

<b>TRC20</b> - Lower fees (Recommended)
<b>ERC20</b> - Ethereum network
"""
        await query.edit_message_text(
            text,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='HTML'
        )
        return DEPOSIT_NETWORK
        
    elif method == 'BTC':
        payment_info = f"""
<b>Bitcoin Payment Details:</b>

BTC Address: <code>{BTC_ADDRESS}</code>

⚠️ Send only BTC to this address
⏱ Confirmation: 1-3 blocks (~10-30 min)

After payment, send your transaction hash (TXID):
"""
        await query.edit_message_text(
            f"₿ <b>Deposit {amount} Tokens</b>\nMethod: Bitcoin\n\n{payment_info}",
            parse_mode='HTML'
        )
        context.user_data['deposit_network'] = 'BTC'
        return DEPOSIT_PROOF
        
    elif method == 'BNB':
        payment_info = f"""
<b>Binance Coin Payment Details:</b>

BNB Address (BEP20): <code>{BNB_ADDRESS}</code>

⚠️ Use BEP20 network (Binance Smart Chain)
⏱ Confirmation: ~3 seconds

After payment, send your transaction hash (TXID):
"""
        await query.edit_message_text(
            f"🔶 <b>Deposit {amount} Tokens</b>\nMethod: BNB\n\n{payment_info}",
            parse_mode='HTML'
        )
        context.user_data['deposit_network'] = 'BNB-BEP20'
        return DEPOSIT_PROOF

async def deposit_network_selected(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle USDT network selection"""
    query = update.callback_query
    await query.answer()
    
    network = query.data.split('_')[-1].upper()
    context.user_data['deposit_network'] = f"USDT-{network}"
    
    amount = context.user_data.get('deposit_amount', 0)
    
    if network == 'TRC20':
        address = USDT_TRC20_ADDRESS
        network_name = "TRC20 (Tron Network)"
        fee_info = "Fee: ~1 USDT"
    else:  # ERC20
        address = USDT_ERC20_ADDRESS
        network_name = "ERC20 (Ethereum Network)"
        fee_info = "Fee: Higher (check current gas)"
    
    payment_info = f"""
<b>USDT Payment Details</b>

Network: {network_name}
Address: <code>{address}</code>

{fee_info}
⏱ Confirmation: 1-5 minutes

After payment, send your transaction hash (TXID):
"""
    
    await query.edit_message_text(
        f"💎 <b>Deposit {amount} Tokens</b>\n\n{payment_info}",
        parse_mode='HTML'
    )
    
    return DEPOSIT_PROOF

async def deposit_proof_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle deposit proof submission"""
    user_id = update.effective_user.id
    db = Database()
    
    amount = context.user_data.get('deposit_amount')
    method = context.user_data.get('deposit_method')
    network = context.user_data.get('deposit_network', method)
    
    # Get proof (text or photo)
    if update.message.photo:
        tx_hash = "Screenshot submitted"
        # Get the largest photo
        photo = update.message.photo[-1]
        context.user_data['deposit_photo'] = photo.file_id
    else:
        tx_hash = update.message.text.strip()
    
    # Create full method string
    full_method = f"{method}"
    if network and network != method:
        full_method = network
    
    # Create deposit request
    deposit_id = db.create_deposit(user_id, full_method, amount, tx_hash)
    
    text = f"""
✅ <b>Deposit Request Submitted</b>

Deposit ID: #{deposit_id}
Amount: {amount} tokens
Method: {full_method}
Proof: {"📸 Screenshot" if update.message.photo else "✍️ Transaction ID"}
Status: ⏳ Pending Admin Review

Your deposit will be reviewed by admin.
You'll be notified once it's approved!

💡 Tip: Screenshot deposits are usually verified faster!
"""
    
    await update.message.reply_text(
        text,
        reply_markup=get_back_button(),
        parse_mode='HTML'
    )
    
    # Notify admin with photo if available
    try:
        admin_text = f"""
🔔 <b>New Deposit Request</b>

Deposit ID: #{deposit_id}
User ID: {user_id}
Username: @{update.effective_user.username or 'N/A'}
Name: {update.effective_user.first_name}
Amount: {amount} tokens
Method: {full_method}
Proof: {tx_hash}

📸 Screenshot: {"Yes" if update.message.photo else "No"}

Use Admin Panel to approve/reject.
"""
        
        if 'deposit_photo' in context.user_data:
            await context.bot.send_photo(
                chat_id=ADMIN_ID,
                photo=context.user_data['deposit_photo'],
                caption=admin_text,
                parse_mode='HTML'
            )
        else:
            await context.bot.send_message(
                chat_id=ADMIN_ID,
                text=admin_text,
                parse_mode='HTML'
            )
    except Exception as e:
        logger.error(f"Failed to notify admin: {e}")
    
    depositing_users.discard(user_id)
    context.user_data.clear()
    
    return ConversationHandler.END

async def cancel_deposit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancel deposit process"""
    query = update.callback_query
    user_id = query.from_user.id
    
    depositing_users.discard(user_id)
    context.user_data.clear()
    
    return ConversationHandler.END
