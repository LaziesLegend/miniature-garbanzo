from telegram import Update, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import ContextTypes
from database import Database
from handlers.menu import get_main_menu, get_main_keyboard
from config import REFERRAL_BONUS, BOT_NAME, BOT_LOGO_URL
import logging

logger = logging.getLogger(__name__)

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command with referral tracking"""
    user = update.effective_user
    db = Database()
    
    # Check for referral code
    referrer_id = None
    if context.args and len(context.args) > 0:
        try:
            referrer_id = int(context.args[0])
            # Prevent self-referral
            if referrer_id == user.id:
                referrer_id = None
        except ValueError:
            logger.warning(f"Invalid referral code: {context.args[0]}")
    
    # Check if user already exists
    existing_user = db.get_user(user.id)
    
    if not existing_user:
        # New user registration
        success = db.add_user(user.id, user.username, referrer_id)
        
        if success and referrer_id:
            # Process referral bonus
            referrer = db.get_user(referrer_id)
            if referrer:
                db.update_user_tokens(referrer_id, REFERRAL_BONUS)
                db.add_referral(referrer_id, user.id, REFERRAL_BONUS)
                db.add_transaction(
                    referrer_id, 
                    'bonus', 
                    REFERRAL_BONUS, 
                    f'Referral bonus for user {user.id}'
                )
                
                # Notify referrer
                try:
                    await context.bot.send_message(
                        chat_id=referrer_id,
                        text=f"🎉 New referral! You earned {REFERRAL_BONUS} tokens!"
                    )
                except Exception as e:
                    logger.error(f"Failed to notify referrer: {e}")
    
    # Welcome message with logo
    welcome_text = f"""
👋 <b>Welcome to {BOT_NAME}!</b>

Hello {user.first_name}! 

This bot helps you promote your Telegram channels and groups.

💡 <b>How it works:</b>
• Deposit tokens to your wallet
• Create promotion campaigns
• Get real members to your channel
• Track your campaign progress

💰 <b>Pricing:</b>
• 115 tokens per member
• Minimum 5 members per campaign

🎁 <b>Referral Program:</b>
Earn {REFERRAL_BONUS} tokens for each friend you refer!

Choose an option below to get started:
"""
    
    # Send logo if URL is configured
    try:
        if BOT_LOGO_URL and BOT_LOGO_URL != "https://i.imgur.com/your-logo.png":
            await update.message.reply_photo(
                photo=BOT_LOGO_URL,
                caption=welcome_text,
                reply_markup=get_main_keyboard(),
                parse_mode='HTML'
            )
        else:
            # No logo, send text with keyboard
            await update.message.reply_text(
                welcome_text,
                reply_markup=get_main_keyboard(),
                parse_mode='HTML'
            )
    except Exception as e:
        logger.error(f"Error sending logo: {e}")
        # Fallback to text only
        await update.message.reply_text(
            welcome_text,
            reply_markup=get_main_keyboard(),
            parse_mode='HTML'
        )
