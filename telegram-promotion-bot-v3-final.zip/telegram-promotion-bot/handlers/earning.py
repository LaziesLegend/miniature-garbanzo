from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import Database
from handlers.menu import get_back_button
from config import JOIN_REWARD, DAILY_BONUS, GAMBLE_WIN_MULTIPLIER, GAMBLE_WIN_CHANCE
import logging
import random
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

async def earning_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show earning options"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    db = Database()
    
    # Check if suspended
    if db.is_user_suspended(user_id):
        await query.edit_message_text(
            "🚫 <b>Account Suspended</b>\n\nYour account has been suspended for violating terms.",
            parse_mode='HTML'
        )
        return
    
    keyboard = [
        [InlineKeyboardButton("🎯 Join & Earn", callback_data="earn_join")],
        [InlineKeyboardButton("🎁 Daily Bonus", callback_data="earn_daily")],
        [InlineKeyboardButton("🎲 Lucky Spin", callback_data="earn_gamble")],
        [InlineKeyboardButton("📋 My Tasks", callback_data="earn_my_tasks")],
        [InlineKeyboardButton("🔙 Back to Menu", callback_data="main_menu")]
    ]
    
    text = f"""
💰 <b>Earn Tokens</b>

Choose how you want to earn tokens:

🎯 <b>Join & Earn</b> - Join channels and earn {JOIN_REWARD} tokens
🎁 <b>Daily Bonus</b> - Get {DAILY_BONUS} tokens daily
🎲 <b>Lucky Spin</b> - Try your luck!
📋 <b>My Tasks</b> - Track your active tasks

⚠️ <b>Important:</b>
Stay in channels for 3 days or face penalties!
"""
    
    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def join_earn_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show available channels to join"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    db = Database()
    
    # Get available campaigns
    campaigns = db.get_available_earning_campaigns()
    
    if not campaigns:
        text = "😔 <b>No Tasks Available</b>\n\nCheck back later for new earning opportunities!"
        keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="earning_menu")]]
    else:
        text = "🎯 <b>Join & Earn Tasks</b>\n\nJoin these channels to earn tokens:\n\n"
        keyboard = []
        
        for camp in campaigns[:10]:  # Show max 10
            # Check if user already joined
            already_joined = db.check_user_already_joined(user_id, camp['id'])
            
            if not already_joined:
                remaining = camp['target_members'] - camp['delivered_members']
                text += f"📢 Campaign #{camp['id']}\n"
                text += f"Channel: {camp['channel_link']}\n"
                text += f"Reward: {JOIN_REWARD} tokens\n"
                text += f"Spots left: {remaining}\n\n"
                
                keyboard.append([
                    InlineKeyboardButton(
                        f"Join Campaign #{camp['id']} - Earn {JOIN_REWARD} 💎",
                        callback_data=f"join_task_{camp['id']}"
                    )
                ])
        
        if not keyboard:
            text = "✅ <b>All Caught Up!</b>\n\nYou've joined all available campaigns."
            keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="earning_menu")]]
        else:
            text += "⚠️ <b>Remember:</b> Stay for 3 days or lose 90% of your balance!"
            keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="earning_menu")])
    
    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def join_task_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle user joining a task"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    campaign_id = int(query.data.split('_')[-1])
    
    db = Database()
    
    # Get campaign details
    campaign = db.get_campaign(campaign_id)
    
    if not campaign:
        await query.answer("❌ Campaign not found", show_alert=True)
        return
    
    # Check if already joined
    if db.check_user_already_joined(user_id, campaign_id):
        await query.answer("⚠️ You already joined this campaign", show_alert=True)
        return
    
    # Create keyboard with channel link
    keyboard = [
        [InlineKeyboardButton("📢 Join Channel", url=campaign['channel_link'])],
        [InlineKeyboardButton("✅ I Joined", callback_data=f"verify_join_{campaign_id}")],
        [InlineKeyboardButton("🔙 Back", callback_data="earn_join")]
    ]
    
    text = f"""
📢 <b>Join Channel Task</b>

Campaign ID: #{campaign_id}
Channel: {campaign['channel_link']}
Reward: {JOIN_REWARD} tokens

<b>Instructions:</b>
1. Click "Join Channel" button
2. Join the channel
3. Click "I Joined" to verify

⚠️ <b>Important Warning:</b>
You MUST stay in the channel for <b>3 days</b>!

If you leave before 3 days:
• Your account will be suspended
• 90% of your wallet balance will be deducted
• You'll lose all pending rewards

This is automatically monitored!
"""
    
    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def verify_join_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Verify user joined the channel"""
    query = update.callback_query
    user_id = query.from_user.id
    campaign_id = int(query.data.split('_')[-1])
    
    db = Database()
    campaign = db.get_campaign(campaign_id)
    
    if not campaign:
        await query.answer("❌ Campaign not found", show_alert=True)
        return
    
    # Try to check if user is actually in the channel
    channel_username = campaign['channel_link'].replace('@', '').replace('https://t.me/', '')
    
    try:
        # Try to get chat member status
        member = await context.bot.get_chat_member(f"@{channel_username}", user_id)
        
        if member.status in ['member', 'administrator', 'creator']:
            # User is actually in the channel
            task_id = db.add_user_task(user_id, campaign_id, campaign['channel_link'])
            
            if task_id:
                db.verify_user_task(task_id)
                db.update_user_tokens(user_id, JOIN_REWARD)
                db.mark_task_rewarded(task_id)
                db.increment_campaign_members(campaign_id)
                db.add_transaction(
                    user_id,
                    'bonus',
                    JOIN_REWARD,
                    f'Joined campaign #{campaign_id}'
                )
                
                await query.answer("✅ Verified! Tokens added!", show_alert=True)
                
                text = f"""
✅ <b>Task Completed!</b>

Campaign: #{campaign_id}
Reward: {JOIN_REWARD} tokens credited!

⚠️ <b>Remember:</b>
Stay in the channel for 3 days!

Leaving early will result in:
• Account suspension
• 90% balance deduction

We'll check automatically after 3 days.
"""
                
                keyboard = [[InlineKeyboardButton("🎯 More Tasks", callback_data="earn_join")]]
                
                await query.edit_message_text(
                    text,
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode='HTML'
                )
            else:
                await query.answer("❌ Error recording task", show_alert=True)
        else:
            await query.answer("❌ Please join the channel first!", show_alert=True)
    
    except Exception as e:
        logger.error(f"Error verifying join: {e}")
        # If we can't check, trust the user but record it
        task_id = db.add_user_task(user_id, campaign_id, campaign['channel_link'])
        
        if task_id:
            db.verify_user_task(task_id)
            db.update_user_tokens(user_id, JOIN_REWARD)
            db.mark_task_rewarded(task_id)
            db.increment_campaign_members(campaign_id)
            db.add_transaction(
                user_id,
                'bonus',
                JOIN_REWARD,
                f'Joined campaign #{campaign_id}'
            )
            
            await query.answer("✅ Tokens added! Stay for 3 days!", show_alert=True)
            
            text = f"""
✅ <b>Task Recorded!</b>

Reward: {JOIN_REWARD} tokens credited!

⚠️ <b>Warning:</b>
You must stay in the channel for 3 days.
We'll verify membership automatically.

Leaving early = Account suspension + 90% balance loss!
"""
            
            keyboard = [[InlineKeyboardButton("🎯 More Tasks", callback_data="earn_join")]]
            await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='HTML')

async def my_tasks_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user's active tasks"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    db = Database()
    
    tasks = db.get_user_active_tasks(user_id)
    
    if not tasks:
        text = "📋 <b>My Tasks</b>\n\nYou don't have any active tasks."
    else:
        text = "📋 <b>My Active Tasks</b>\n\n"
        
        for task in tasks:
            joined_date = datetime.fromisoformat(task['joined_at'])
            days_passed = (datetime.now() - joined_date).days
            days_remaining = 3 - days_passed
            
            if days_remaining > 0:
                status = f"🟡 {days_remaining} days left"
            else:
                status = "✅ Completed"
            
            text += f"Campaign #{task['campaign_id']}\n"
            text += f"Channel: {task['channel_link']}\n"
            text += f"Status: {status}\n"
            text += f"Joined: {task['joined_at'][:10]}\n\n"
    
    keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="earning_menu")]]
    
    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def daily_bonus_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Claim daily bonus"""
    query = update.callback_query
    user_id = query.from_user.id
    
    db = Database()
    
    # Check if already claimed today
    if db.check_daily_bonus_claimed(user_id):
        await query.answer("⚠️ Already claimed today! Come back tomorrow!", show_alert=True)
        return
    
    # Give daily bonus
    db.update_user_tokens(user_id, DAILY_BONUS)
    db.claim_daily_bonus(user_id, DAILY_BONUS)
    db.add_transaction(user_id, 'bonus', DAILY_BONUS, 'Daily bonus')
    
    await query.answer(f"✅ Claimed {DAILY_BONUS} tokens!", show_alert=True)
    
    text = f"""
🎁 <b>Daily Bonus Claimed!</b>

You received: {DAILY_BONUS} tokens

Come back tomorrow for another bonus!
"""
    
    keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="earning_menu")]]
    
    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def gamble_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show gambling interface"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    db = Database()
    
    balance = db.get_user_balance(user_id)
    
    keyboard = [
        [
            InlineKeyboardButton("🎲 Bet 50", callback_data="gamble_bet_50"),
            InlineKeyboardButton("🎲 Bet 100", callback_data="gamble_bet_100")
        ],
        [
            InlineKeyboardButton("🎲 Bet 250", callback_data="gamble_bet_250"),
            InlineKeyboardButton("🎲 Bet 500", callback_data="gamble_bet_500")
        ],
        [InlineKeyboardButton("🔙 Back", callback_data="earning_menu")]
    ]
    
    text = f"""
🎲 <b>Lucky Spin</b>

Your Balance: {balance} tokens

Try your luck! If you win, you get 3X your bet!

⚡️ Quick bets available:
• 50 tokens → Win 150
• 100 tokens → Win 300
• 250 tokens → Win 750
• 500 tokens → Win 1500

Choose your bet:
"""
    
    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def gamble_bet_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Process gambling bet"""
    query = update.callback_query
    user_id = query.from_user.id
    bet_amount = int(query.data.split('_')[-1])
    
    db = Database()
    balance = db.get_user_balance(user_id)
    
    if balance < bet_amount:
        await query.answer(f"❌ Insufficient balance! You need {bet_amount} tokens", show_alert=True)
        return
    
    # Deduct bet
    db.update_user_tokens(user_id, -bet_amount)
    db.add_transaction(user_id, 'campaign', bet_amount, f'Lucky Spin bet: {bet_amount}')
    
    # Determine win/loss (10% win chance, user doesn't know)
    won = random.randint(1, 100) <= GAMBLE_WIN_CHANCE
    
    if won:
        winnings = bet_amount * GAMBLE_WIN_MULTIPLIER
        db.update_user_tokens(user_id, winnings)
        db.add_transaction(user_id, 'bonus', winnings, f'Lucky Spin win: {winnings}')
        db.add_gamble_record(user_id, bet_amount, True, winnings)
        
        await query.answer(f"🎉 YOU WON! +{winnings} tokens!", show_alert=True)
        
        text = f"""
🎉 <b>CONGRATULATIONS!</b>

You bet: {bet_amount} tokens
You won: {winnings} tokens!

Net profit: +{winnings - bet_amount} tokens

New balance: {balance - bet_amount + winnings} tokens

🍀 Lucky you!
"""
    else:
        db.add_gamble_record(user_id, bet_amount, False, 0)
        
        await query.answer(f"😔 Not this time! Lost {bet_amount} tokens", show_alert=True)
        
        text = f"""
😔 <b>Better Luck Next Time!</b>

You bet: {bet_amount} tokens
Result: Lost

New balance: {balance - bet_amount} tokens

Try again? Fortune favors the brave!
"""
    
    keyboard = [
        [InlineKeyboardButton("🎲 Try Again", callback_data="earn_gamble")],
        [InlineKeyboardButton("🔙 Back to Menu", callback_data="earning_menu")]
    ]
    
    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )
