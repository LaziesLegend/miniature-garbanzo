from telegram import Update
from telegram.ext import ContextTypes
from database import Database
from handlers.menu import get_back_button
import logging

logger = logging.getLogger(__name__)

async def balance_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user balance"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    db = Database()
    
    balance = db.get_user_balance(user_id)
    
    text = f"""
💰 <b>Your Wallet Balance</b>

Current Balance: <b>{balance} tokens</b>

You can use tokens to create promotion campaigns.
Need more tokens? Use the Deposit button!
"""
    
    await query.edit_message_text(
        text,
        reply_markup=get_back_button(),
        parse_mode='HTML'
    )

async def transactions_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show transaction history"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    db = Database()
    
    transactions = db.get_user_transactions(user_id, limit=10)
    
    if not transactions:
        text = "📜 <b>Transaction History</b>\n\nNo transactions yet."
    else:
        text = "📜 <b>Recent Transactions</b>\n\n"
        
        for trans in transactions:
            trans_type = trans['type'].capitalize()
            amount = trans['amount']
            desc = trans['description']
            timestamp = trans['timestamp'][:16]  # Format: YYYY-MM-DD HH:MM
            
            # Format amount with +/- sign
            if trans['type'] in ['deposit', 'bonus', 'admin_adjustment']:
                amount_str = f"+{amount}"
            else:
                amount_str = f"-{amount}"
            
            text += f"• {trans_type}: {amount_str} tokens\n"
            text += f"  {desc}\n"
            text += f"  <i>{timestamp}</i>\n\n"
    
    await query.edit_message_text(
        text,
        reply_markup=get_back_button(),
        parse_mode='HTML'
    )
