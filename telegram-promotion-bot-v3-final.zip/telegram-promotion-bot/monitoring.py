"""
Background monitoring system for checking if users left channels early
"""

import asyncio
import logging
from datetime import datetime, timedelta
from telegram.ext import ContextTypes
from database import Database
from config import PENALTY_PERCENTAGE

logger = logging.getLogger(__name__)

async def monitor_user_tasks(context: ContextTypes.DEFAULT_TYPE):
    """
    Background task that runs every 6 hours to check if users left channels early
    """
    db = Database()
    logger.info("Starting user task monitoring...")
    
    try:
        # Get all active tasks
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM user_tasks 
            WHERE verified = 1 AND left_early = 0 AND reward_given = 1
        ''')
        
        tasks = cursor.fetchall()
        conn.close()
        
        for task in tasks:
            task_id, user_id, campaign_id, channel_link, joined_at, verified, reward_given, left_early = task
            
            # Calculate days since joining
            joined_date = datetime.fromisoformat(joined_at)
            days_passed = (datetime.now() - joined_date).days
            
            # Check if user is still in channel (for tasks under 3 days)
            if days_passed < 3:
                channel_username = channel_link.replace('@', '').replace('https://t.me/', '')
                
                try:
                    # Check if user is still member
                    member = await context.bot.get_chat_member(f"@{channel_username}", user_id)
                    
                    if member.status not in ['member', 'administrator', 'creator']:
                        # User left early!
                        logger.warning(f"User {user_id} left campaign {campaign_id} early!")
                        
                        # Get user balance
                        balance = db.get_user_balance(user_id)
                        penalty = int(balance * (PENALTY_PERCENTAGE / 100))
                        
                        # Deduct penalty
                        db.update_user_tokens(user_id, -penalty)
                        db.mark_task_left_early(task_id)
                        db.suspend_user(user_id, f"Left campaign #{campaign_id} before 3 days")
                        db.add_transaction(
                            user_id,
                            'campaign',
                            penalty,
                            f'Penalty for leaving campaign #{campaign_id} early'
                        )
                        
                        # Notify user
                        try:
                            await context.bot.send_message(
                                chat_id=user_id,
                                text=f"""
🚫 <b>ACCOUNT SUSPENDED</b>

You left a channel before completing 3 days!

Campaign: #{campaign_id}
Channel: {channel_link}

<b>Penalties Applied:</b>
• Account suspended
• {penalty} tokens deducted (90% of balance)

This is a violation of our terms.
Contact admin for appeal.
""",
                                parse_mode='HTML'
                            )
                        except Exception as e:
                            logger.error(f"Failed to notify user {user_id}: {e}")
                
                except Exception as e:
                    logger.error(f"Error checking membership for user {user_id}: {e}")
                    # If we can't check, assume they're still there
                    continue
        
        logger.info(f"Monitoring completed. Checked {len(tasks)} tasks.")
    
    except Exception as e:
        logger.error(f"Error in monitoring task: {e}")

async def start_monitoring(application):
    """Start the monitoring background task"""
    # Run every 6 hours
    while True:
        try:
            await monitor_user_tasks(application.bot)
            await asyncio.sleep(21600)  # 6 hours
        except Exception as e:
            logger.error(f"Error in monitoring loop: {e}")
            await asyncio.sleep(3600)  # Retry in 1 hour on error
