import logging
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, 
    MessageHandler, ConversationHandler, filters, ContextTypes
)

import config
from database import Database
from handlers.menu import get_main_menu, get_main_keyboard, get_back_button
from handlers.start import start_command
from handlers.wallet import balance_handler, transactions_handler
from handlers.referral import referral_handler

# Campaign handlers
from handlers.campaign import (
    campaign_start, campaign_type_selected, custom_reward_received,
    members_selected, instructions_received, link_received, 
    boost_choice, boost_amount_received, my_campaigns_handler,
    cancel_campaign,
    CAMPAIGN_TYPE, CAMPAIGN_CUSTOM_REWARD, CAMPAIGN_MEMBERS, 
    CAMPAIGN_LINK, CAMPAIGN_BOOST, CAMPAIGN_INSTRUCTIONS
)

# Earning handlers
from handlers.earning import (
    earning_menu, join_earn_list, join_campaign, verify_join,
    daily_bonus_handler, gambling_menu_handler, gamble_quick,
    my_tasks_handler
)

# Deposit handlers
from handlers.deposit import (
    deposit_start, deposit_amount_handler, deposit_method_handler,
    deposit_network_handler, deposit_proof_handler, cancel_deposit,
    DEPOSIT_AMOUNT, DEPOSIT_METHOD, DEPOSIT_NETWORK, DEPOSIT_PROOF
)

# Admin handlers
from handlers.admin import (
    admin_panel, admin_deposits_handler, approve_deposit_handler,
    admin_add_tokens_start, admin_add_tokens_handler,
    admin_broadcast_start, admin_broadcast_handler,
    admin_stats_handler, cancel_admin,
    ADMIN_ADD_TOKENS, ADMIN_BROADCAST
)

# Setup logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

async def main_menu_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Return to main menu"""
    query = update.callback_query
    await query.answer()
    
    await query.edit_message_text(
        "🏠 <b>Main Menu</b>\n\nChoose an option:",
        reply_markup=get_main_menu(query.from_user.id),
        parse_mode='HTML'
    )

async def keyboard_button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle keyboard button presses"""
    text = update.message.text
    user_id = update.effective_user.id
    db = Database()
    
    if text == "💰 Balance":
        user = db.get_user(user_id)
        level_info = config.USER_LEVELS[user['level']]
        
        await update.message.reply_text(
            f"""
💰 <b>Your Balance</b>

Balance: <b>{user['tokens']} tokens</b>
Level: {level_info['name']}
Trust Score: {user['trust_score']}/100
""",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("📊 Full Stats", callback_data="balance")
            ]]),
            parse_mode='HTML'
        )
    
    elif text == "🚀 Create Campaign":
        await update.message.reply_text(
            "🚀 <b>Create Campaign</b>\n\nClick below to start:",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("➕ New Campaign", callback_data="create_campaign")
            ]]),
            parse_mode='HTML'
        )
    
    elif text == "🎯 Earning":
        user = db.get_user(user_id)
        await update.message.reply_text(
            f"""
💰 <b>Earning Center</b>

Balance: {user['tokens']} tokens

Choose how to earn:
""",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🎯 Join & Earn", callback_data="earning_menu")]
            ]),
            parse_mode='HTML'
        )
    
    elif text == "💳 Deposit":
        await update.message.reply_text(
            "💳 <b>Deposit Tokens</b>\n\nClick to start:",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("💰 Deposit Now", callback_data="deposit")
            ]]),
            parse_mode='HTML'
        )
    
    elif text == "👥 Referral":
        bot_username = context.bot.username
        link = f"https://t.me/{bot_username}?start={user_id}"
        count = db.get_referral_count(user_id)
        
        await update.message.reply_text(
            f"""
👥 <b>Referral Program</b>

Link: <code>{link}</code>
Referrals: {count}
Earned: {count * config.REFERRAL_BONUS_L1} tokens

Tap to copy and share!
""",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("📊 Full Info", callback_data="referral")
            ]]),
            parse_mode='HTML'
        )
    
    elif text == "📊 My Campaigns":
        await update.message.reply_text(
            "📊 <b>My Campaigns</b>\n\nView your campaigns:",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("📋 View All", callback_data="my_campaigns")
            ]]),
            parse_mode='HTML'
        )
    
    elif text == "🎁 Daily Bonus":
        await update.message.reply_text(
            "🎁 <b>Daily Bonus</b>\n\nClaim your bonus:",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🎁 Claim Now", callback_data="daily_bonus")
            ]]),
            parse_mode='HTML'
        )
    
    elif text == "🎲 Play Game":
        balance = db.get_user_balance(user_id)
        await update.message.reply_text(
            f"""
🎲 <b>Lucky Game</b>

Balance: {balance} tokens

Win up to {config.GAMBLE_WIN_MULTIPLIER}x!
""",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🎲 Play Now", callback_data="gambling_menu")
            ]]),
            parse_mode='HTML'
        )

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    """Log errors"""
    logger.error(f"Exception: {context.error}", exc_info=context.error)

def main():
    """Start the bot"""
    # Initialize database
    db = Database()
    logger.info("Database initialized")
    
    # Create application
    app = Application.builder().token(config.BOT_TOKEN).build()
    
    # Campaign conversation handler
    campaign_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(campaign_start, pattern='^create_campaign$')],
        states={
            CAMPAIGN_TYPE: [
                CallbackQueryHandler(campaign_type_selected, pattern='^camptype_'),
                CallbackQueryHandler(cancel_campaign, pattern='^main_menu$')
            ],
            CAMPAIGN_CUSTOM_REWARD: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, custom_reward_received)
            ],
            CAMPAIGN_MEMBERS: [
                CallbackQueryHandler(members_selected, pattern='^campmem_'),
                CallbackQueryHandler(cancel_campaign, pattern='^main_menu$')
            ],
            CAMPAIGN_LINK: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, link_received)
            ],
            CAMPAIGN_INSTRUCTIONS: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, instructions_received)
            ],
            CAMPAIGN_BOOST: [
                CallbackQueryHandler(boost_choice, pattern='^boost_'),
                MessageHandler(filters.TEXT & ~filters.COMMAND, boost_amount_received)
            ]
        },
        fallbacks=[CallbackQueryHandler(cancel_campaign, pattern='^main_menu$')],
        allow_reentry=True
    )
    
    # Deposit conversation handler
    deposit_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(deposit_start, pattern='^deposit$')],
        states={
            DEPOSIT_AMOUNT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, deposit_amount_handler),
                CallbackQueryHandler(cancel_deposit, pattern='^main_menu$')
            ],
            DEPOSIT_METHOD: [
                CallbackQueryHandler(deposit_method_handler, pattern='^dep_method_'),
                CallbackQueryHandler(cancel_deposit, pattern='^main_menu$')
            ],
            DEPOSIT_NETWORK: [
                CallbackQueryHandler(deposit_network_handler, pattern='^dep_net_'),
                CallbackQueryHandler(deposit_start, pattern='^deposit$')
            ],
            DEPOSIT_PROOF: [
                MessageHandler((filters.TEXT | filters.PHOTO) & ~filters.COMMAND, deposit_proof_handler)
            ]
        },
        fallbacks=[CallbackQueryHandler(cancel_deposit, pattern='^main_menu$')],
        allow_reentry=True
    )
    
    # Admin conversation handlers
    admin_add_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(admin_add_tokens_start, pattern='^admin_add$')],
        states={
            ADMIN_ADD_TOKENS: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, admin_add_tokens_handler)
            ]
        },
        fallbacks=[CallbackQueryHandler(cancel_admin, pattern='^admin_panel$')],
        allow_reentry=True
    )
    
    admin_broadcast_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(admin_broadcast_start, pattern='^admin_broadcast$')],
        states={
            ADMIN_BROADCAST: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, admin_broadcast_handler)
            ]
        },
        fallbacks=[CallbackQueryHandler(cancel_admin, pattern='^admin_panel$')],
        allow_reentry=True
    )
    
    # Add handlers
    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(campaign_conv)
    app.add_handler(deposit_conv)
    app.add_handler(admin_add_conv)
    app.add_handler(admin_broadcast_conv)
    
    # Keyboard button handler (must be before callback handlers)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, keyboard_button_handler))
    
    # Callback handlers
    app.add_handler(CallbackQueryHandler(main_menu_handler, pattern='^main_menu$'))
    app.add_handler(CallbackQueryHandler(balance_handler, pattern='^balance$'))
    app.add_handler(CallbackQueryHandler(transactions_handler, pattern='^transactions$'))
    app.add_handler(CallbackQueryHandler(referral_handler, pattern='^referral$'))
    app.add_handler(CallbackQueryHandler(my_campaigns_handler, pattern='^my_campaigns$'))
    
    # Earning handlers
    app.add_handler(CallbackQueryHandler(earning_menu, pattern='^earning_menu$'))
    app.add_handler(CallbackQueryHandler(join_earn_list, pattern='^earn_join$'))
    app.add_handler(CallbackQueryHandler(join_campaign, pattern='^join_camp_'))
    app.add_handler(CallbackQueryHandler(verify_join, pattern='^verify_'))
    app.add_handler(CallbackQueryHandler(daily_bonus_handler, pattern='^daily_bonus$'))
    app.add_handler(CallbackQueryHandler(gambling_menu_handler, pattern='^gambling_menu$'))
    app.add_handler(CallbackQueryHandler(gamble_quick, pattern=r'^gamble_\d+$'))
    app.add_handler(CallbackQueryHandler(my_tasks_handler, pattern='^my_tasks$'))
    
    # Admin handlers
    app.add_handler(CallbackQueryHandler(admin_panel, pattern='^admin_panel$'))
    app.add_handler(CallbackQueryHandler(admin_deposits_handler, pattern='^admin_deposits$'))
    app.add_handler(CallbackQueryHandler(approve_deposit_handler, pattern='^approve_dep_'))
    app.add_handler(CallbackQueryHandler(admin_stats_handler, pattern='^admin_stats$'))
    
    # Error handler
    app.add_error_handler(error_handler)
    
    # Start bot
    logger.info("=" * 50)
    logger.info("🚀 BOT STARTED SUCCESSFULLY!")
    logger.info(f"Bot Name: {config.BOT_NAME}")
    logger.info(f"Admin ID: {config.ADMIN_ID}")
    logger.info(f"Support: {config.SUPPORT_CONTACT}")
    logger.info("=" * 50)
    
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
