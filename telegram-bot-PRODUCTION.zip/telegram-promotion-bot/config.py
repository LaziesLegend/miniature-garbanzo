import os
from dotenv import load_dotenv

load_dotenv()

# ==================== BOT CREDENTIALS ====================
BOT_TOKEN = os.getenv('BOT_TOKEN', '8438773973:AAHzZUXMjUw6whaZI9pG7wr3IWGj30xiFww')
ADMIN_ID = int(os.getenv('ADMIN_ID', '8301300209'))

# ==================== BOT BRANDING ====================
BOT_NAME = "Promotion Bot"
BOT_LOGO_URL = "https://i.imgur.com/your-logo.png"
SUPPORT_CONTACT = "@holabrooo"

# ==================== CRYPTO WALLETS ====================
USDT_TRC20_ADDRESS = "TYourUSDTAddressHere"
USDT_ERC20_ADDRESS = "0xYourUSDTERC20AddressHere"
BTC_ADDRESS = "bc1YourBitcoinAddressHere"
BNB_ADDRESS = "0xYourBNBAddressHere"

# ==================== TOKEN ECONOMY ====================
# Dynamic pricing (admin can change)
JOIN_REWARD = 100              # What users earn per join
ADVERTISER_COST = 115          # What advertisers pay per member
PLATFORM_FEE = 15              # Platform profit per member (auto-calculated)
MIN_CAMPAIGN_SIZE = 5          # Minimum members per campaign

# ==================== REFERRAL SYSTEM ====================
REFERRAL_BONUS_L1 = 10         # Level 1 referral bonus
REFERRAL_BONUS_L2 = 3          # Level 2 referral bonus (referral's referral)
REFERRAL_DEPOSIT_BONUS = 50    # Bonus if referral makes deposit

# ==================== DAILY & BONUSES ====================
DAILY_BONUS = 100              # Daily login bonus
DAILY_BONUS_STREAK = {         # Streak bonuses
    7: 200,   # 7 days streak
    30: 1000  # 30 days streak
}

# ==================== GAMBLE SYSTEM ====================
GAMBLE_WIN_MULTIPLIER = 3      # Win = 3x bet
GAMBLE_WIN_CHANCE = 10         # 10% win chance (hidden from users)
MIN_GAMBLE_BET = 10
MAX_GAMBLE_BET = 1000

# ==================== CUSTOM CAMPAIGNS ====================
CUSTOM_CAMPAIGN_TAX = 15       # 15% tax on custom campaigns
CUSTOM_CAMPAIGN_MIN_BID = 500  # Minimum reward per task

# ==================== USER LEVEL SYSTEM ====================
USER_LEVELS = {
    1: {"name": "Bronze", "joins": 0, "reward_boost": 0},
    2: {"name": "Silver", "joins": 50, "reward_boost": 5},
    3: {"name": "Gold", "joins": 200, "reward_boost": 10},
    4: {"name": "Platinum", "joins": 500, "reward_boost": 15},
    5: {"name": "Diamond", "joins": 1000, "reward_boost": 20}
}

# ==================== ANTI-CHEAT ====================
MIN_TRUST_SCORE = 20           # Below this = banned
INITIAL_TRUST_SCORE = 100
TRUST_SCORE_PENALTIES = {
    "fake_join": -10,
    "fast_leave": -15,
    "spam": -20,
    "duplicate": -25
}
TRUST_SCORE_REWARDS = {
    "successful_join": 2,
    "deposit": 10,
    "complete_campaign": 5
}

# ==================== CHANNEL MONITORING ====================
MINIMUM_STAY_DAYS = 3          # Must stay in channel 3 days
PENALTY_PERCENTAGE = 90        # 90% balance deduction for early leave
MONITORING_INTERVAL = 21600    # Check every 6 hours (seconds)

# ==================== DEPOSIT BONUSES ====================
DEPOSIT_BONUSES = {
    1000: 5,   # 5% bonus on 1000+ deposit
    5000: 10,  # 10% bonus on 5000+ deposit
    10000: 15  # 15% bonus on 10000+ deposit
}

# ==================== RATE LIMITING ====================
MAX_JOINS_PER_DAY = 50         # Max joins user can do per day
MAX_CAMPAIGNS_PER_DAY = 10     # Max campaigns user can create per day
COOLDOWN_BETWEEN_JOINS = 30    # Seconds between joins

# ==================== WITHDRAWAL (Future) ====================
MIN_WITHDRAWAL = 1000
WITHDRAWAL_FEE_PERCENT = 5
MAX_WITHDRAWAL_PER_DAY = 10000

# ==================== BOOST SYSTEM ====================
BOOST_MULTIPLIER = 1.5         # Campaign visibility boost

# ==================== VALIDATION ====================
if not BOT_TOKEN or BOT_TOKEN == 'your_bot_token_here':
    raise ValueError("BOT_TOKEN must be set in .env file")
if not ADMIN_ID:
    raise ValueError("ADMIN_ID must be set in .env file")

# Auto-calculate platform fee
PLATFORM_FEE = ADVERTISER_COST - JOIN_REWARD
