# 🚀 Advanced Telegram Promotion Bot

**Production-ready bot with 50+ features, token economy, and intelligent anti-fraud system.**

## ✨ Features Overview

### 🎯 Core Systems
- ✅ **Token Economy** - Virtual currency with dynamic pricing
- ✅ **Multi-Campaign Types** - Channel, Bot, Custom tasks
- ✅ **Join & Earn** - Users earn tokens by completing tasks
- ✅ **Smart Verification** - Auto-check channel membership
- ✅ **Anti-Cheat System** - Trust scores, rate limiting, fraud detection
- ✅ **Level System** - Users level up with reward boosts
- ✅ **Deposit System** - UPI + Crypto (USDT/BTC/BNB) with bonuses
- ✅ **Referral Program** - 2-level referrals with bonuses
- ✅ **Daily Bonuses** - Streak rewards
- ✅ **Gambling System** - Lucky game with configurable odds
- ✅ **Admin Panel** - Full control dashboard
- ✅ **Custom Tasks** - Screenshot verification workflows
- ✅ **Campaign Boost** - Priority listing system
- ✅ **Keyboard Buttons** - Easy navigation
- ✅ **Transaction History** - Complete audit trail

### 💰 Token Economy
```
User earns: 100 tokens (base) + level boost
Advertiser pays: 115 tokens
Platform fee: 15 tokens
```

### 🎮 User Levels
| Level | Name | Joins Required | Boost |
|-------|------|----------------|-------|
| 1 | Bronze | 0 | 0% |
| 2 | Silver | 50 | +5% |
| 3 | Gold | 200 | +10% |
| 4 | Platinum | 500 | +15% |
| 5 | Diamond | 1000 | +20% |

### 👥 Referral Rewards
- Level 1 (Direct): 10 tokens
- Level 2 (Indirect): 3 tokens
- Deposit bonus: +50 tokens

### 💳 Deposit Bonuses
- 1000+ tokens: +5%
- 5000+ tokens: +10%
- 10000+ tokens: +15%

## 🚀 Quick Start

### 1. Installation

```bash
# Extract
unzip telegram-promotion-bot.zip
cd telegram-promotion-bot

# Install dependencies
pip3 install -r requirements.txt --user

# Or with break-system-packages
pip3 install -r requirements.txt --break-system-packages
```

### 2. Configuration

The bot is already configured with your credentials!

Edit `config.py` to add your crypto addresses:

```python
USDT_TRC20_ADDRESS = "TYourAddress"
USDT_ERC20_ADDRESS = "0xYourAddress"
BTC_ADDRESS = "bc1YourAddress"
BNB_ADDRESS = "0xYourAddress"
```

Optional: Add bot logo in `config.py`:
```python
BOT_LOGO_URL = "https://i.imgur.com/your-logo.png"
```

### 3. Run

```bash
python3 main.py
```

You should see:
```
🚀 BOT STARTED SUCCESSFULLY!
Bot Name: Promotion Bot
Admin ID: 8301300209
Support: @holabrooo
```

## 📋 Campaign Types

### 📢 Channel/Group Join
- Users join your channel/group
- Auto-verification via Telegram API
- Cost: 115 tokens/member
- Users earn: 100+ tokens

### 🤖 Bot Start
- Users start your bot
- Tracked automatically
- Same pricing as channel

### ✏️ Custom Tasks
- YOU set the reward (min 500 tokens)
- Users complete custom instructions
- Screenshot verification
- You approve/reject submissions
- 15% platform fee

## 🎯 How Users Earn

### Join & Earn
1. Browse available campaigns
2. Join channel/bot
3. Click verify
4. Earn tokens instantly!
5. **Must stay 3 days or lose 90% balance**

### Daily Bonus
- Base: 100 tokens/day
- Streak bonuses:
  - 7 days: +200 tokens
  - 30 days: +1000 tokens

### Play Game
- Bet any amount
- Win = 3x multiplier
- 10% win chance (secret)

### Referrals
- Share link
- Earn per referral
- 2-level system

## 🛡️ Anti-Fraud System

### Trust Score
- Starts at: 100
- Fake join: -10
- Fast leave: -15
- Successful join: +2
- Deposit: +10
- Below 20: Auto-banned

### 3-Day Rule
- Users must stay in channels 3 days
- Monitored every 6 hours
- Leave early = 90% balance loss + ban

### Rate Limiting
- Max 50 joins/day
- Max 10 campaigns/day
- 30s cooldown between joins

## ⚙️ Admin Panel

### Features
- 💳 Approve deposits
- ➕ Add/deduct tokens
- 📢 Broadcast messages
- 📊 Platform statistics
- 🔒 Ban users
- ✏️ Review custom tasks
- 🔄 System management

### Quick Commands
```
Add tokens: user_id amount
Example: 123456789 1000
```

## 💳 Deposit Methods

### UPI (India)
- Upload screenshot
- Manual approval

### USDT
- TRC20 (low fees ~1 USDT)
- ERC20 (higher fees)
- TX hash or screenshot

### Bitcoin
- BTC main network
- TX hash required

### BNB
- BEP20 network
- Fast confirmation

## 📊 Platform Economics

### Revenue Model
```
Per member joined:
User earns: 100 tokens
Advertiser pays: 115 tokens
Platform keeps: 15 tokens
```

### Custom Campaign Example
```
User sets: 500 token reward
Platform fee: 75 tokens (15%)
Total cost: 575 tokens
```

## 🎮 User Journey

### New User
1. /start → Auto-register
2. See welcome + logo
3. Get keyboard buttons
4. Explore features

### Earning
1. Click "🎯 Earning"
2. Browse campaigns (sorted by boost)
3. Join channel/complete task
4. Verify
5. Earn tokens!
6. Level up

### Creating Campaign
1. Click "🚀 Create Campaign"
2. Choose type (Channel/Bot/Custom)
3. Set details
4. Optional: Boost for priority
5. Pay with tokens
6. Track progress

## 🔧 Customization

All settings in `config.py`:

```python
# Economy
JOIN_REWARD = 100
ADVERTISER_COST = 115
PLATFORM_FEE = 15

# Gamble
GAMBLE_WIN_MULTIPLIER = 3
GAMBLE_WIN_CHANCE = 10  # 10%

# Anti-cheat
MIN_TRUST_SCORE = 20
MINIMUM_STAY_DAYS = 3
PENALTY_PERCENTAGE = 90

# Custom campaigns
CUSTOM_CAMPAIGN_MIN_BID = 500
CUSTOM_CAMPAIGN_TAX = 15
```

## 📁 Project Structure

```
telegram-promotion-bot/
├── main.py              # Main bot file
├── config.py            # All settings
├── database.py          # Database operations
├── requirements.txt     # Dependencies
├── .env                 # Credentials
├── handlers/
│   ├── start.py         # Start + referrals
│   ├── menu.py          # Menus
│   ├── campaign.py      # Campaign creation
│   ├── earning.py       # Join & earn
│   ├── deposit.py       # Deposits
│   ├── wallet.py        # Balance
│   ├── referral.py      # Referrals
│   └── admin.py         # Admin panel
└── README.md
```

## 🐛 Troubleshooting

### Bot won't start
```bash
# Check Python version
python3 --version  # Need 3.10+

# Reinstall dependencies
pip3 install -r requirements.txt --force-reinstall
```

### Database errors
```bash
# Delete and recreate
rm bot_database.db
python3 main.py  # Auto-creates new DB
```

### Buttons not working
- Restart bot
- Send /start again
- Check logs for errors

## 🚀 Deployment

### Local/VPS
```bash
# Background with screen
screen -S bot
python3 main.py
# Detach: Ctrl+A then D

# Reattach
screen -r bot
```

### Cloud (Railway/Render/Heroku)
1. Push to GitHub
2. Connect repo
3. Set environment variables
4. Deploy!

## 📈 Scaling

For high traffic:
1. Switch SQLite → PostgreSQL
2. Add Redis caching
3. Use webhooks instead of polling
4. Separate worker processes

## 🔐 Security

- ✅ Environment variables for secrets
- ✅ SQL injection prevention
- ✅ Input validation
- ✅ Admin-only commands
- ✅ Rate limiting
- ✅ Trust score system
- ✅ Transaction logging

## 💡 Tips

1. **Set realistic prices** - Balance user earnings vs revenue
2. **Monitor trust scores** - Ban fraudsters quickly
3. **Approve deposits fast** - Better user experience
4. **Use boost system** - Higher revenue from advertisers
5. **Promote referrals** - Viral growth

## 📞 Support

Contact: @holabrooo
Admin ID: 8301300209

## 🎉 You're Ready!

Your bot has everything needed for a professional promotion platform. Just add your crypto addresses and launch!

**Start earning! 🚀**
