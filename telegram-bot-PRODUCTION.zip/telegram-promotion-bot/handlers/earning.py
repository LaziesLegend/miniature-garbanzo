from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import Database
from handlers.menu import get_back_button
import config
import logging
import random
from datetime import datetime

logger = logging.getLogger(__name__)

async def earning_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Earning menu"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    db = Database()
    
    if db.is_user_banned(user_id):
        await query.edit_message_text("🚫 Account banned", reply_markup=get_back_button())
        return
    
    user = db.get_user(user_id)
    
    keyboard = [
        [InlineKeyboardButton("🎯 Join & Earn", callback_data="earn_join")],
        [InlineKeyboardButton("🎁 Daily Bonus", callback_data="daily_bonus")],
        [InlineKeyboardButton("🎲 Play Game", callback_data="gambling_menu")],
        [InlineKeyboardButton("📋 My Tasks", callback_data="my_tasks")],
        [InlineKeyboardButton("🔙 Back", callback_data="main_menu")]
    ]
    
    await query.edit_message_text(
        f"""
💰 <b>Earn Tokens</b>

Your Stats:
• Balance: {user['tokens']} tokens
• Level: {config.USER_LEVELS[user['level']]['name']}
• Joins today: {user['total_joins']}

Ways to earn:
🎯 Join campaigns - {config.JOIN_REWARD}+ tokens each
🎁 Daily bonus - {config.DAILY_BONUS} tokens
🎲 Play game - Win up to {config.GAMBLE_WIN_MULTIPLIER}x!

⚠️ <b>Rules:</b>
Stay in channels 3 days or lose 90% balance!

Choose:
""",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def join_earn_list(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show available campaigns"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    db = Database()
    
    campaigns = db.get_available_campaigns(exclude_user_id=user_id)
    
    if not campaigns:
        await query.edit_message_text(
            "😔 <b>No tasks available</b>\n\nCheck back later!",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="earning_menu")]]),
            parse_mode='HTML'
        )
        return
    
    text = "🎯 <b>Available Tasks</b>\n\n"
    keyboard = []
    
    types = {'channel': '📢', 'bot': '🤖', 'custom': '✏️'}
    
    for camp in campaigns[:10]:
        if db.has_user_joined_campaign(user_id, camp['id']):
            continue
        
        emoji = types.get(camp['campaign_type'], '📢')
        remaining = camp['target_members'] - camp['delivered_members']
        
        text += f"{emoji} <b>Campaign #{camp['id']}</b>\n"
        text += f"Type: {camp['campaign_type'].capitalize()}\n"
        text += f"Reward: {camp['join_reward']} tokens\n"
        text += f"Spots: {remaining}\n"
        
        if camp.get('boost_amount', 0) > 0:
            text += f"💎 Boosted!\n"
        
        text += "\n"
        
        keyboard.append([InlineKeyboardButton(
            f"{emoji} Join #{camp['id']} - Earn {camp['join_reward']} 💰",
            callback_data=f"join_camp_{camp['id']}"
        )])
    
    if not keyboard:
        text = "✅ You've joined all available campaigns!"
        keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="earning_menu")]]
    else:
        text += f"⚠️ Stay 3 days or lose 90% balance!"
        keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="earning_menu")])
    
    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def join_campaign(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Join a campaign"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    campaign_id = int(query.data.split('_')[-1])
    
    db = Database()
    
    if db.has_user_joined_campaign(user_id, campaign_id):
        await query.answer("⚠️ Already joined!", show_alert=True)
        return
    
    campaign = db.get_campaign(campaign_id)
    if not campaign:
        await query.answer("❌ Campaign not found", show_alert=True)
        return
    
    if campaign['campaign_type'] == 'custom':
        # Custom task - show instructions
        keyboard = [
            [InlineKeyboardButton("📤 Submit Task", callback_data=f"submit_custom_{campaign_id}")],
            [InlineKeyboardButton("🔙 Back", callback_data="earn_join")]
        ]
        
        await query.edit_message_text(
            f"""
✏️ <b>Custom Task #{campaign_id}</b>

Reward: {campaign['join_reward']} tokens

<b>Instructions:</b>
{campaign.get('custom_instructions', 'No instructions')}

Complete the task and submit screenshot:
""",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='HTML'
        )
        
        context.user_data['pending_custom_campaign'] = campaign_id
        return
    
    # Standard join
    keyboard = [
        [InlineKeyboardButton("📢 Join Now", url=campaign['channel_link'])],
        [InlineKeyboardButton("✅ I Joined - Verify", callback_data=f"verify_{campaign_id}")],
        [InlineKeyboardButton("🔙 Back", callback_data="earn_join")]
    ]
    
    type_name = "Channel/Group" if campaign['campaign_type'] == 'channel' else "Bot"
    
    await query.edit_message_text(
        f"""
🎯 <b>Join {type_name}</b>

Campaign: #{campaign_id}
Link: {campaign['channel_link']}
Reward: {campaign['join_reward']} tokens

<b>Steps:</b>
1. Click "Join Now"
2. Join the {campaign['campaign_type']}
3. Click "I Joined"

⚠️ <b>WARNING:</b>
Must stay 3 days!
Leave early = 90% balance loss + ban!
""",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def verify_join(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Verify campaign join"""
    query = update.callback_query
    user_id = query.from_user.id
    campaign_id = int(query.data.split('_')[1])
    
    db = Database()
    campaign = db.get_campaign(campaign_id)
    
    if not campaign:
        await query.answer("❌ Campaign not found", show_alert=True)
        return
    
    if db.has_user_joined_campaign(user_id, campaign_id):
        await query.answer("⚠️ Already joined!", show_alert=True)
        return
    
    # Try to verify membership
    channel_link = campaign['channel_link']
    channel_id = channel_link.replace('@', '').replace('https://t.me/', '')
    
    verified = False
    try:
        member = await context.bot.get_chat_member(f"@{channel_id}", user_id)
        if member.status in ['member', 'administrator', 'creator']:
            verified = True
    except:
        # Can't verify, trust user but record
        verified = True
        logger.warning(f"Could not verify join for user {user_id} campaign {campaign_id}")
    
    if verified:
        # Calculate reward with level boost
        user = db.get_user(user_id)
        level_boost = config.USER_LEVELS[user['level']]['reward_boost']
        reward = campaign['join_reward'] + int(campaign['join_reward'] * level_boost / 100)
        
        # Add join record
        join_id = db.add_campaign_join(campaign_id, user_id)
        
        # Give reward
        db.update_user_tokens(user_id, reward)
        db.mark_join_rewarded(join_id)
        db.increment_campaign_members(campaign_id)
        
        # Update stats
        db.add_transaction(user_id, 'earning', reward, f'Campaign #{campaign_id}')
        
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE users 
            SET total_joins = total_joins + 1, successful_joins = successful_joins + 1
            WHERE user_id = ?
        ''', (user_id,))
        conn.commit()
        conn.close()
        
        # Update level
        new_level = db.update_user_level(user_id)
        
        # Update trust score
        db.update_trust_score(user_id, config.TRUST_SCORE_REWARDS['successful_join'])
        
        await query.answer(f"✅ Verified! +{reward} tokens!", show_alert=True)
        
        level_up_msg = f"\n\n🎉 Level up! Now {config.USER_LEVELS[new_level]['name']}!" if new_level and new_level > user['level'] else ""
        
        await query.edit_message_text(
            f"""
✅ <b>Join Verified!</b>

Campaign: #{campaign_id}
Reward: {reward} tokens
{'Bonus: ' + str(int(campaign['join_reward'] * level_boost / 100)) if level_boost > 0 else ''}

⚠️ <b>Remember:</b>
Stay 3 days or lose 90% balance!

Balance: {user['tokens'] + reward} tokens{level_up_msg}
""",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🎯 More Tasks", callback_data="earn_join")]]),
            parse_mode='HTML'
        )
    else:
        await query.answer("❌ Please join first!", show_alert=True)

async def daily_bonus_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Daily bonus"""
    query = update.callback_query
    user_id = query.from_user.id
    
    db = Database()
    
    if not db.can_claim_daily_bonus(user_id):
        await query.answer("⚠️ Already claimed today!", show_alert=True)
        return
    
    user = db.get_user(user_id)
    
    # Calculate streak
    streak = user['daily_streak']
    if user['last_daily_bonus']:
        last = datetime.fromisoformat(user['last_daily_bonus'])
        days_ago = (datetime.now() - last).days
        
        if days_ago == 1:
            streak += 1  # Continue streak
        elif days_ago > 1:
            streak = 1  # Reset streak
    else:
        streak = 1
    
    # Base bonus
    bonus = config.DAILY_BONUS
    
    # Streak bonuses
    extra = 0
    for days, streak_bonus in config.DAILY_BONUS_STREAK.items():
        if streak >= days:
            extra = streak_bonus
    
    total_bonus = bonus + extra
    
    # Give bonus
    db.update_user_tokens(user_id, total_bonus)
    db.claim_daily_bonus(user_id, total_bonus, streak)
    db.add_transaction(user_id, 'bonus', total_bonus, f'Daily bonus (streak: {streak})')
    
    await query.answer(f"✅ +{total_bonus} tokens!", show_alert=True)
    
    await query.edit_message_text(
        f"""
🎁 <b>Daily Bonus Claimed!</b>

Bonus: {bonus} tokens
Streak: {streak} days
{'Streak bonus: +' + str(extra) if extra > 0 else ''}
<b>Total: {total_bonus} tokens</b>

Balance: {user['tokens'] + total_bonus} tokens

Come back tomorrow for {streak + 1} day streak!
""",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="earning_menu")]]),
        parse_mode='HTML'
    )

async def gambling_menu_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Gambling menu"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    db = Database()
    
    user = db.get_user(user_id)
    
    keyboard = [
        [
            InlineKeyboardButton("🎲 Quick: 50", callback_data="gamble_50"),
            InlineKeyboardButton("🎲 Quick: 100", callback_data="gamble_100")
        ],
        [
            InlineKeyboardButton("🎲 Quick: 250", callback_data="gamble_250"),
            InlineKeyboardButton("🎲 Quick: 500", callback_data="gamble_500")
        ],
        [InlineKeyboardButton("💎 Custom Bet", callback_data="gamble_custom")],
        [InlineKeyboardButton("🔙 Back", callback_data="earning_menu")]
    ]
    
    await query.edit_message_text(
        f"""
🎲 <b>Lucky Game</b>

Balance: {user['tokens']} tokens

Try your luck!
Win = {config.GAMBLE_WIN_MULTIPLIER}x your bet!

Examples:
• Bet 100 → Win 300
• Bet 500 → Win 1500

Choose bet amount:
""",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def gamble_quick(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Quick gamble"""
    query = update.callback_query
    user_id = query.from_user.id
    bet = int(query.data.split('_')[1])
    
    db = Database()
    balance = db.get_user_balance(user_id)
    
    if balance < bet:
        await query.answer(f"❌ Need {bet} tokens!", show_alert=True)
        return
    
    # Deduct bet
    db.update_user_tokens(user_id, -bet)
    db.add_transaction(user_id, 'gambling', bet, f'Game bet: {bet}')
    
    # Determine win (secret 10% chance)
    won = random.randint(1, 100) <= config.GAMBLE_WIN_CHANCE
    
    if won:
        winnings = bet * config.GAMBLE_WIN_MULTIPLIER
        db.update_user_tokens(user_id, winnings)
        db.add_transaction(user_id, 'bonus', winnings, f'Game win: {winnings}')
        db.add_gamble_record(user_id, bet, True, winnings)
        db.update_trust_score(user_id, 1)
        
        await query.answer(f"🎉 WON! +{winnings}!", show_alert=True)
        
        await query.edit_message_text(
            f"""
🎉 <b>YOU WON!</b>

Bet: {bet} tokens
Won: {winnings} tokens
Profit: +{winnings - bet} tokens

New balance: {balance - bet + winnings} tokens

🍀 Lucky you!
""",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🎲 Play Again", callback_data="gambling_menu")],
                [InlineKeyboardButton("🔙 Main Menu", callback_data="main_menu")]
            ]),
            parse_mode='HTML'
        )
    else:
        db.add_gamble_record(user_id, bet, False, 0)
        
        await query.answer(f"😔 Lost {bet}", show_alert=True)
        
        await query.edit_message_text(
            f"""
😔 <b>Better Luck Next Time!</b>

Bet: {bet} tokens
Lost: -{bet} tokens

Balance: {balance - bet} tokens

Try again? Fortune changes!
""",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🎲 Try Again", callback_data="gambling_menu")],
                [InlineKeyboardButton("🔙 Main Menu", callback_data="main_menu")]
            ]),
            parse_mode='HTML'
        )

async def my_tasks_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user's active tasks"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    db = Database()
    
    conn = db.get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT cj.*, c.campaign_type, c.channel_link, c.join_reward
        FROM campaign_joins cj
        JOIN campaigns c ON cj.campaign_id = c.id
        WHERE cj.user_id = ? AND cj.left_early = 0
        ORDER BY cj.joined_at DESC
        LIMIT 10
    ''', (user_id,))
    tasks = cursor.fetchall()
    conn.close()
    
    if not tasks:
        await query.edit_message_text(
            "📋 <b>My Tasks</b>\n\nNo active tasks.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="earning_menu")]]),
            parse_mode='HTML'
        )
        return
    
    text = "📋 <b>My Active Tasks</b>\n\n"
    
    for task in tasks:
        joined = datetime.fromisoformat(task['joined_at'])
        days_ago = (datetime.now() - joined).days
        days_left = config.MINIMUM_STAY_DAYS - days_ago
        
        if days_left > 0:
            status = f"🟡 {days_left} days left"
        else:
            status = "✅ Completed"
        
        text += f"Campaign #{task['campaign_id']}\n"
        text += f"Type: {task['campaign_type']}\n"
        text += f"Reward: {task['join_reward']} tokens\n"
        text += f"Status: {status}\n"
        text += f"Joined: {task['joined_at'][:10]}\n\n"
    
    text += "⚠️ Stay 3 days to keep your balance!"
    
    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="earning_menu")]]),
        parse_mode='HTML'
    )
