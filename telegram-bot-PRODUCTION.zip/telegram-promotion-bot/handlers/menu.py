from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
import config

def get_main_keyboard():
    """Main keyboard buttons"""
    keyboard = [
        [KeyboardButton("💰 Balance"), KeyboardButton("🚀 Create Campaign")],
        [KeyboardButton("🎯 Earning"), KeyboardButton("💳 Deposit")],
        [KeyboardButton("👥 Referral"), KeyboardButton("📊 My Campaigns")],
        [KeyboardButton("🎁 Daily Bonus"), KeyboardButton("🎲 Play Game")],
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def get_main_menu(user_id: int) -> InlineKeyboardMarkup:
    """Inline menu"""
    keyboard = [
        [
            InlineKeyboardButton("💰 Balance", callback_data="balance"),
            InlineKeyboardButton("🚀 Campaign", callback_data="create_campaign")
        ],
        [
            InlineKeyboardButton("🎯 Earning", callback_data="earning_menu"),
            InlineKeyboardButton("💳 Deposit", callback_data="deposit")
        ],
        [
            InlineKeyboardButton("👥 Referral", callback_data="referral"),
            InlineKeyboardButton("📊 My Campaigns", callback_data="my_campaigns")
        ],
        [
            InlineKeyboardButton("🎁 Daily Bonus", callback_data="daily_bonus"),
            InlineKeyboardButton("🎲 Play Game", callback_data="gambling_menu")
        ]
    ]
    
    if user_id == config.ADMIN_ID:
        keyboard.append([InlineKeyboardButton("⚙️ Admin Panel", callback_data="admin_panel")])
    
    return InlineKeyboardMarkup(keyboard)

def get_back_button() -> InlineKeyboardMarkup:
    """Back button"""
    return InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="main_menu")]])

def get_cancel_button() -> InlineKeyboardMarkup:
    """Cancel button"""
    return InlineKeyboardMarkup([[InlineKeyboardButton("❌ Cancel", callback_data="main_menu")]])
