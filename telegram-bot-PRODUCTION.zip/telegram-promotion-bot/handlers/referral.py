from telegram import Update
from telegram.ext import ContextTypes
from database import Database
from handlers.menu import get_back_button
import config

async def referral_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Referral system"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    db = Database()
    
    bot_username = context.bot.username
    referral_link = f"https://t.me/{bot_username}?start={user_id}"
    
    ref_count = db.get_referral_count(user_id)
    total_earned = ref_count * config.REFERRAL_BONUS_L1
    
    await query.edit_message_text(
        f"""
👥 <b>Referral Program</b>

<b>Your Referral Link:</b>
<code>{referral_link}</code>

📊 <b>Your Stats:</b>
• Total Referrals: {ref_count}
• Tokens Earned: {total_earned}

💰 <b>Rewards:</b>
• Level 1 (Direct): {config.REFERRAL_BONUS_L1} tokens
• Level 2 (Indirect): {config.REFERRAL_BONUS_L2} tokens
• Deposit Bonus: +{config.REFERRAL_DEPOSIT_BONUS} tokens

🎯 <b>How it works:</b>
1. Share your link
2. Friend joins via link
3. You get {config.REFERRAL_BONUS_L1} tokens instantly!
4. When they refer someone, you get {config.REFERRAL_BONUS_L2} more!
5. If they deposit, you get +{config.REFERRAL_DEPOSIT_BONUS}!

💡 <b>Tip:</b> More referrals = More passive income!

Tap link above to copy and share!
""",
        reply_markup=get_back_button(),
        parse_mode='HTML'
    )
