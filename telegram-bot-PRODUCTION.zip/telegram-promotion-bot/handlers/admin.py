from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from database import Database
from handlers.menu import get_main_menu
import config
import logging

logger = logging.getLogger(__name__)

# States
ADMIN_ADD_TOKENS, ADMIN_BROADCAST = range(2)

async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Admin panel"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id != config.ADMIN_ID:
        await query.answer("⛔ Admin only!", show_alert=True)
        return
    
    db = Database()
    
    stats = f"""
📊 <b>Platform Statistics</b>

👥 <b>Users:</b>
• Total: {db.get_total_users()}
• Active Today: {db.get_active_users_today()}

🚀 <b>Campaigns:</b>
• Total: {db.get_total_campaigns()}
• Pending Deposits: {len(db.get_pending_deposits())}

💰 <b>Economy:</b>
• Tokens in Circulation: {db.get_tokens_in_circulation()}
• Platform Revenue: {db.get_platform_revenue()}
"""
    
    keyboard = [
        [
            InlineKeyboardButton("💳 Approve Deposits", callback_data="admin_deposits"),
            InlineKeyboardButton("📊 Full Stats", callback_data="admin_stats")
        ],
        [
            InlineKeyboardButton("➕ Add Tokens", callback_data="admin_add"),
            InlineKeyboardButton("➖ Deduct Tokens", callback_data="admin_deduct")
        ],
        [
            InlineKeyboardButton("📢 Broadcast", callback_data="admin_broadcast"),
            InlineKeyboardButton("🔒 Ban User", callback_data="admin_ban")
        ],
        [
            InlineKeyboardButton("✏️ Custom Tasks", callback_data="admin_custom"),
            InlineKeyboardButton("🔄 Reset System", callback_data="admin_reset")
        ],
        [InlineKeyboardButton("🔙 Back", callback_data="main_menu")]
    ]
    
    await query.edit_message_text(
        stats,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def admin_deposits_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show pending deposits"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id != config.ADMIN_ID:
        return
    
    db = Database()
    deposits = db.get_pending_deposits()
    
    if not deposits:
        await query.edit_message_text(
            "💳 <b>Pending Deposits</b>\n\nNo pending deposits.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="admin_panel")]]),
            parse_mode='HTML'
        )
        return
    
    text = "💳 <b>Pending Deposits</b>\n\n"
    keyboard = []
    
    for dep in deposits[:10]:
        text += f"<b>#{dep['id']}</b> - User {dep['user_id']}\n"
        text += f"Amount: {dep['amount']} (+{dep['bonus_amount']} bonus)\n"
        text += f"Method: {dep['method']}\n"
        text += f"Time: {dep['created_at'][:16]}\n\n"
        
        keyboard.append([
            InlineKeyboardButton(f"✅ Approve #{dep['id']}", callback_data=f"approve_dep_{dep['id']}"),
            InlineKeyboardButton(f"❌ Reject #{dep['id']}", callback_data=f"reject_dep_{dep['id']}")
        ])
    
    keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="admin_panel")])
    
    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def approve_deposit_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Approve deposit"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id != config.ADMIN_ID:
        return
    
    deposit_id = int(query.data.split('_')[-1])
    db = Database()
    
    deposit = db.get_deposit(deposit_id)
    if not deposit:
        await query.answer("❌ Deposit not found", show_alert=True)
        return
    
    total = deposit['amount'] + deposit['bonus_amount']
    
    # Credit tokens
    db.update_user_tokens(deposit['user_id'], total)
    db.approve_deposit(deposit_id)
    db.add_transaction(deposit['user_id'], 'deposit', total, f'Deposit approved #{deposit_id}')
    db.update_trust_score(deposit['user_id'], config.TRUST_SCORE_REWARDS['deposit'])
    
    # Referral deposit bonus
    user = db.get_user(deposit['user_id'])
    if user and user['referred_by']:
        db.update_user_tokens(user['referred_by'], config.REFERRAL_DEPOSIT_BONUS)
        db.add_transaction(user['referred_by'], 'referral', config.REFERRAL_DEPOSIT_BONUS, 
                         f'Referral deposit bonus from {deposit["user_id"]}')
    
    # Notify user
    try:
        await context.bot.send_message(
            deposit['user_id'],
            f"""
✅ <b>Deposit Approved!</b>

Amount: {deposit['amount']} tokens
Bonus: {deposit['bonus_amount']} tokens
<b>Total: {total} tokens credited!</b>

Thank you for your deposit!
""",
            parse_mode='HTML'
        )
    except:
        pass
    
    await query.answer(f"✅ Approved! {total} tokens credited", show_alert=True)
    await admin_deposits_handler(update, context)

async def admin_add_tokens_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start add tokens"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id != config.ADMIN_ID:
        return
    
    await query.edit_message_text(
        """
➕ <b>Add Tokens</b>

Format: <code>user_id amount</code>
Example: <code>123456789 1000</code>

Send command:
""",
        parse_mode='HTML'
    )
    
    return ADMIN_ADD_TOKENS

async def admin_add_tokens_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle add tokens"""
    if update.effective_user.id != config.ADMIN_ID:
        return ConversationHandler.END
    
    try:
        parts = update.message.text.strip().split()
        user_id = int(parts[0])
        amount = int(parts[1])
        
        db = Database()
        db.update_user_tokens(user_id, amount, update_stats=False)
        db.add_transaction(user_id, 'admin_adjustment', amount, 'Admin added tokens')
        db.log_admin_action(config.ADMIN_ID, 'add_tokens', user_id, f'Added {amount} tokens')
        
        await update.message.reply_text(
            f"✅ Added {amount} tokens to user {user_id}",
            reply_markup=get_main_menu(config.ADMIN_ID)
        )
        
        # Notify user
        try:
            await context.bot.send_message(
                user_id,
                f"🎁 Admin credited {amount} tokens to your account!"
            )
        except:
            pass
        
    except:
        await update.message.reply_text("❌ Invalid format. Use: user_id amount")
    
    return ConversationHandler.END

async def admin_broadcast_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start broadcast"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id != config.ADMIN_ID:
        return
    
    await query.edit_message_text(
        """
📢 <b>Broadcast Message</b>

Send the message to broadcast to all users:

(Will be sent to all registered users)
""",
        parse_mode='HTML'
    )
    
    return ADMIN_BROADCAST

async def admin_broadcast_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle broadcast"""
    if update.effective_user.id != config.ADMIN_ID:
        return ConversationHandler.END
    
    message = update.message.text
    db = Database()
    
    conn = db.get_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT user_id FROM users')
    users = cursor.fetchall()
    conn.close()
    
    sent = 0
    failed = 0
    
    for user in users:
        try:
            await context.bot.send_message(user[0], message)
            sent += 1
        except:
            failed += 1
    
    await update.message.reply_text(
        f"""
📢 <b>Broadcast Complete</b>

Sent: {sent}
Failed: {failed}
Total: {len(users)}
""",
        reply_markup=get_main_menu(config.ADMIN_ID),
        parse_mode='HTML'
    )
    
    return ConversationHandler.END

async def admin_stats_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Detailed stats"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id != config.ADMIN_ID:
        return
    
    db = Database()
    
    conn = db.get_connection()
    cursor = conn.cursor()
    
    # Active campaigns
    cursor.execute("SELECT COUNT(*) FROM campaigns WHERE status = 'active'")
    active_camps = cursor.fetchone()[0]
    
    # Today's joins
    cursor.execute("""
        SELECT COUNT(*) FROM campaign_joins 
        WHERE DATE(joined_at) = DATE('now')
    """)
    today_joins = cursor.fetchone()[0]
    
    # Today's revenue
    cursor.execute("""
        SELECT SUM(platform_fee) FROM campaigns 
        WHERE DATE(created_at) = DATE('now')
    """)
    today_revenue = cursor.fetchone()[0] or 0
    
    conn.close()
    
    await query.edit_message_text(
        f"""
📊 <b>Detailed Statistics</b>

👥 <b>Users:</b>
• Total Users: {db.get_total_users()}
• Active Today: {db.get_active_users_today()}

🚀 <b>Campaigns:</b>
• Total: {db.get_total_campaigns()}
• Active Now: {active_camps}

💰 <b>Economy:</b>
• Total Tokens: {db.get_tokens_in_circulation()}
• Total Revenue: {db.get_platform_revenue()}
• Today's Revenue: {today_revenue}

📈 <b>Today:</b>
• Joins: {today_joins}
• Revenue: {today_revenue}
• Deposits: {len(db.get_pending_deposits())}
""",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="admin_panel")]]),
        parse_mode='HTML'
    )

async def cancel_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancel admin operation"""
    return ConversationHandler.END
