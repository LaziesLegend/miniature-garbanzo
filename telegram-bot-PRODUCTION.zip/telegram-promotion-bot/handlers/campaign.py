from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from database import Database
from handlers.menu import get_main_menu, get_back_button
import config
import logging

logger = logging.getLogger(__name__)

# States
CAMPAIGN_TYPE, CAMPAIGN_CUSTOM_REWARD, CAMPAIGN_MEMBERS, CAMPAIGN_LINK, CAMPAIGN_BOOST, CAMPAIGN_INSTRUCTIONS = range(6)

creating = set()

async def campaign_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start campaign creation"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    db = Database()
    
    if db.is_user_banned(user_id):
        await query.edit_message_text("🚫 Your account is banned.", reply_markup=get_back_button())
        return ConversationHandler.END
    
    if user_id in creating:
        await query.answer("⚠️ Already creating campaign", show_alert=True)
        return CAMPAIGN_TYPE
    
    creating.add(user_id)
    
    keyboard = [
        [InlineKeyboardButton("📢 Channel/Group Join", callback_data="camptype_channel")],
        [InlineKeyboardButton("🤖 Bot Start Campaign", callback_data="camptype_bot")],
        [InlineKeyboardButton("✏️ Custom Task (Set Your Reward)", callback_data="camptype_custom")],
        [InlineKeyboardButton("❌ Cancel", callback_data="main_menu")]
    ]
    
    await query.edit_message_text(
        f"""
🚀 <b>Create Campaign</b>

Choose campaign type:

📢 <b>Channel/Group</b> - Users join your channel
   • Cost: {config.ADVERTISER_COST} tokens/member
   • Users earn: {config.JOIN_REWARD} tokens

🤖 <b>Bot Start</b> - Users start your bot
   • Cost: {config.ADVERTISER_COST} tokens/start
   • Users earn: {config.JOIN_REWARD} tokens

✏️ <b>Custom Task</b> - Your own instructions
   • YOU set the reward (min {config.CUSTOM_CAMPAIGN_MIN_BID})
   • {config.CUSTOM_CAMPAIGN_TAX}% platform fee
   • Screenshot verification

💡 Help: {config.SUPPORT_CONTACT}
""",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )
    
    return CAMPAIGN_TYPE

async def campaign_type_selected(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle type selection"""
    query = update.callback_query
    await query.answer()
    
    camp_type = query.data.split('_')[1]
    context.user_data['camp_type'] = camp_type
    
    if camp_type == 'custom':
        await query.edit_message_text(
            f"""
✏️ <b>Custom Task Campaign</b>

Set your reward per completion:

💰 <b>Minimum:</b> {config.CUSTOM_CAMPAIGN_MIN_BID} tokens
📊 <b>Platform Fee:</b> {config.CUSTOM_CAMPAIGN_TAX}%

Example: If you set 500 tokens
• User earns: 500 tokens
• Platform fee: 75 tokens ({config.CUSTOM_CAMPAIGN_TAX}%)
• Total cost per task: 575 tokens

<b>Enter reward amount (whole number only):</b>
""",
            parse_mode='HTML'
        )
        return CAMPAIGN_CUSTOM_REWARD
    else:
        # Show member packages
        keyboard = []
        packages = [5, 10, 25, 50, 100, 250, 500, 1000]
        
        row = []
        for i, count in enumerate(packages):
            cost = count * config.ADVERTISER_COST
            row.append(InlineKeyboardButton(f"{count} ({cost})", callback_data=f"campmem_{count}"))
            if (i + 1) % 2 == 0:
                keyboard.append(row)
                row = []
        if row:
            keyboard.append(row)
        
        keyboard.append([InlineKeyboardButton("❌ Cancel", callback_data="main_menu")])
        
        name = "Channel/Group Join" if camp_type == 'channel' else "Bot Start"
        
        await query.edit_message_text(
            f"""
🚀 <b>{name} Campaign</b>

Select package:

💰 Cost: {config.ADVERTISER_COST} tokens per member
👤 Users earn: {config.JOIN_REWARD} tokens
📊 Minimum: {config.MIN_CAMPAIGN_SIZE} members

Choose:
""",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='HTML'
        )
        
        return CAMPAIGN_MEMBERS

async def custom_reward_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle custom reward input"""
    try:
        reward = int(update.message.text.strip())
        
        if reward < config.CUSTOM_CAMPAIGN_MIN_BID:
            await update.message.reply_text(f"❌ Minimum is {config.CUSTOM_CAMPAIGN_MIN_BID} tokens. Try again:")
            return CAMPAIGN_CUSTOM_REWARD
        
        context.user_data['custom_reward'] = reward
        
        # Show task count options
        keyboard = []
        for count in [5, 10, 20, 50, 100]:
            fee = int(reward * config.CUSTOM_CAMPAIGN_TAX / 100)
            total = count * (reward + fee)
            keyboard.append([InlineKeyboardButton(f"{count} tasks ({total} total)", callback_data=f"campmem_{count}")])
        
        keyboard.append([InlineKeyboardButton("❌ Cancel", callback_data="main_menu")])
        
        await update.message.reply_text(
            f"""
✏️ <b>Custom Campaign</b>

Reward per task: {reward} tokens
Fee per task: {int(reward * config.CUSTOM_CAMPAIGN_TAX / 100)} tokens ({config.CUSTOM_CAMPAIGN_TAX}%)

Select number of tasks:
""",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='HTML'
        )
        
        return CAMPAIGN_MEMBERS
    except:
        await update.message.reply_text("❌ Enter a valid number:")
        return CAMPAIGN_CUSTOM_REWARD

async def members_selected(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle member count selection"""
    query = update.callback_query
    await query.answer()
    
    count = int(query.data.split('_')[1])
    context.user_data['member_count'] = count
    
    camp_type = context.user_data['camp_type']
    
    if camp_type == 'custom':
        reward = context.user_data['custom_reward']
        fee = int(reward * config.CUSTOM_CAMPAIGN_TAX / 100)
        total = count * (reward + fee)
        
        context.user_data['total_cost'] = total
        context.user_data['platform_fee'] = count * fee
        context.user_data['join_reward'] = reward
        
        await query.edit_message_text(
            f"""
✏️ <b>Custom Task Instructions</b>

Tasks: {count}
Reward/task: {reward} tokens
Total cost: {total} tokens

<b>Write your task instructions:</b>

Example:
1. Visit https://example.com
2. Complete signup
3. Upload screenshot of confirmation

Your instructions:
""",
            parse_mode='HTML'
        )
        
        return CAMPAIGN_INSTRUCTIONS
    else:
        total = count * config.ADVERTISER_COST
        context.user_data['total_cost'] = total
        context.user_data['platform_fee'] = count * config.PLATFORM_FEE
        context.user_data['join_reward'] = config.JOIN_REWARD
        
        link_type = "channel/group" if camp_type == 'channel' else "bot"
        
        await query.edit_message_text(
            f"""
📝 <b>Campaign Details</b>

Type: {camp_type.capitalize()}
Members: {count}
Total cost: {total} tokens

Send your {link_type} link:
(Example: @username or https://t.me/username)
""",
            parse_mode='HTML'
        )
        
        return CAMPAIGN_LINK

async def instructions_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle custom instructions"""
    context.user_data['instructions'] = update.message.text.strip()
    context.user_data['link'] = 'custom_task'
    
    return await ask_boost(update, context)

async def link_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle link input"""
    context.user_data['link'] = update.message.text.strip()
    return await ask_boost(update, context)

async def ask_boost(update, context):
    """Ask about boost"""
    keyboard = [
        [InlineKeyboardButton("💎 Yes, Boost Campaign", callback_data="boost_yes")],
        [InlineKeyboardButton("⏭️ No Boost (Free)", callback_data="boost_no")]
    ]
    
    msg = update.message if hasattr(update, 'message') else update
    
    await msg.reply_text(
        """
💎 <b>Campaign Boost</b>

Boost your campaign to show at the TOP of earning list!

📈 <b>How it works:</b>
• Higher boost = Higher position
• Users see your campaign first
• Faster completion

💰 <b>Boost amount:</b>
Pay any amount of tokens for priority

Want to boost?
""",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )
    
    return CAMPAIGN_BOOST

async def boost_choice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle boost choice"""
    query = update.callback_query
    await query.answer()
    
    if query.data == 'boost_yes':
        await query.edit_message_text(
            """
💎 <b>Boost Amount</b>

Enter boost amount in tokens:

Higher boost = Higher priority

Examples:
• 100 tokens = Good boost
• 500 tokens = Top priority
• 1000 tokens = Premium position

Enter amount (or 0 for no boost):
""",
            parse_mode='HTML'
        )
        return CAMPAIGN_BOOST
    else:
        context.user_data['boost'] = 0
        return await finalize_campaign(update, context)

async def boost_amount_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle boost amount"""
    try:
        boost = int(update.message.text.strip())
        if boost < 0:
            await update.message.reply_text("❌ Must be 0 or positive:")
            return CAMPAIGN_BOOST
        
        context.user_data['boost'] = boost
        return await finalize_campaign(update, context)
    except:
        await update.message.reply_text("❌ Enter valid number:")
        return CAMPAIGN_BOOST

async def finalize_campaign(update, context):
    """Create the campaign"""
    user_id = update.effective_user.id if hasattr(update, 'effective_user') else update.callback_query.from_user.id
    db = Database()
    
    camp_type = context.user_data['camp_type']
    count = context.user_data['member_count']
    cost = context.user_data['total_cost']
    fee = context.user_data['platform_fee']
    link = context.user_data['link']
    reward = context.user_data['join_reward']
    boost = context.user_data.get('boost', 0)
    instructions = context.user_data.get('instructions')
    
    total = cost + boost
    balance = db.get_user_balance(user_id)
    
    if balance < total:
        msg = update.message if hasattr(update, 'message') else update.callback_query.message
        await msg.reply_text(
            f"""
❌ <b>Insufficient Balance</b>

Required: {total} tokens
Balance: {balance} tokens
Need: {total - balance} more tokens

Use "💳 Deposit" to add tokens!
""",
            reply_markup=get_back_button(),
            parse_mode='HTML'
        )
        creating.discard(user_id)
        return ConversationHandler.END
    
    # Deduct tokens
    db.update_user_tokens(user_id, -total)
    
    # Create campaign
    campaign_id = db.create_campaign(
        user_id, camp_type, link, count,
        reward, config.ADVERTISER_COST, fee,
        boost, instructions
    )
    
    db.add_transaction(user_id, 'campaign', total, f'Campaign #{campaign_id}')
    db.log_admin_action(user_id, 'create_campaign', campaign_id, f'{camp_type} - {count} members')
    
    types = {'channel': '📢 Channel', 'bot': '🤖 Bot', 'custom': '✏️ Custom'}
    
    msg = update.message if hasattr(update, 'message') else update.callback_query.message
    await msg.reply_text(
        f"""
✅ <b>Campaign Created!</b>

ID: #{campaign_id}
Type: {types.get(camp_type, camp_type)}
Target: {count} {'members' if camp_type != 'custom' else 'tasks'}
Reward/user: {reward} tokens
Cost: {cost} tokens
Boost: {boost} tokens
<b>Total: {total} tokens</b>

Status: 🟢 Active

{'Link: ' + link if camp_type != 'custom' else '✏️ Custom instructions saved'}

{'💎 Boosted! Shows at top!' if boost > 0 else ''}

Track in "📊 My Campaigns"

New balance: {balance - total} tokens
""",
        reply_markup=get_main_menu(user_id),
        parse_mode='HTML'
    )
    
    creating.discard(user_id)
    context.user_data.clear()
    return ConversationHandler.END

async def my_campaigns_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user campaigns"""
    query = update.callback_query
    await query.answer()
    
    db = Database()
    campaigns = db.get_user_campaigns(query.from_user.id)
    
    if not campaigns:
        await query.edit_message_text(
            "📊 <b>My Campaigns</b>\n\nNo campaigns yet.",
            reply_markup=get_back_button(),
            parse_mode='HTML'
        )
        return
    
    text = "📊 <b>My Campaigns</b>\n\n"
    keyboard = []
    
    types = {'channel': '📢', 'bot': '🤖', 'custom': '✏️'}
    statuses = {'active': '🟢', 'completed': '✅', 'cancelled': '❌'}
    
    for c in campaigns[:15]:
        emoji = types.get(c['campaign_type'], '📢')
        status = statuses.get(c['status'], '⚪')
        
        text += f"{status} {emoji} <b>#{c['id']}</b> {c['campaign_type'].capitalize()}\n"
        text += f"Progress: {c['delivered_members']}/{c['target_members']}\n"
        text += f"Reward: {c['join_reward']} tokens\n"
        
        if c.get('boost_amount', 0) > 0:
            text += f"💎 Boost: {c['boost_amount']}\n"
        
        text += f"Status: {c['status']}\n"
        text += f"Created: {c['created_at'][:10]}\n"
        
        if c['campaign_type'] == 'custom' and c['status'] == 'active':
            keyboard.append([InlineKeyboardButton(
                f"📋 Review #{c['id']}", 
                callback_data=f"review_custom_{c['id']}"
            )])
        
        text += "\n"
    
    keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="main_menu")])
    
    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def cancel_campaign(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancel creation"""
    query = update.callback_query
    creating.discard(query.from_user.id)
    context.user_data.clear()
    return ConversationHandler.END
