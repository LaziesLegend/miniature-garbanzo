from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from database import Database
from handlers.menu import get_back_button
import config
import logging

logger = logging.getLogger(__name__)

# States
DEPOSIT_AMOUNT, DEPOSIT_METHOD, DEPOSIT_NETWORK, DEPOSIT_PROOF = range(4)

async def deposit_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start deposit"""
    query = update.callback_query
    await query.answer()
    
    await query.edit_message_text(
        """
💳 <b>Deposit Tokens</b>

Enter amount to deposit:

💰 <b>Bonuses:</b>
• 1000+ tokens: +5%
• 5000+ tokens: +10%
• 10000+ tokens: +15%

<i>Minimum: 100 tokens</i>

Enter amount:
""",
        parse_mode='HTML'
    )
    
    return DEPOSIT_AMOUNT

async def deposit_amount_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle amount input"""
    try:
        amount = int(update.message.text.strip())
        
        if amount < 100:
            await update.message.reply_text("❌ Minimum 100 tokens. Try again:")
            return DEPOSIT_AMOUNT
        
        context.user_data['deposit_amount'] = amount
        
        # Calculate bonus
        bonus = 0
        for threshold, percent in sorted(config.DEPOSIT_BONUSES.items(), reverse=True):
            if amount >= threshold:
                bonus = int(amount * percent / 100)
                break
        
        context.user_data['deposit_bonus'] = bonus
        
        keyboard = [
            [InlineKeyboardButton("💳 UPI (India)", callback_data="dep_method_upi")],
            [InlineKeyboardButton("💎 USDT (Tether)", callback_data="dep_method_usdt")],
            [InlineKeyboardButton("₿ Bitcoin", callback_data="dep_method_btc")],
            [InlineKeyboardButton("🔶 BNB (Binance)", callback_data="dep_method_bnb")],
            [InlineKeyboardButton("❌ Cancel", callback_data="main_menu")]
        ]
        
        bonus_text = f" (+{bonus} bonus!)" if bonus > 0 else ""
        
        await update.message.reply_text(
            f"""
💳 <b>Deposit {amount} tokens{bonus_text}</b>

Select payment method:
""",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='HTML'
        )
        
        return DEPOSIT_METHOD
    except:
        await update.message.reply_text("❌ Enter valid number:")
        return DEPOSIT_AMOUNT

async def deposit_method_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle method selection"""
    query = update.callback_query
    await query.answer()
    
    method = query.data.split('_')[-1].upper()
    context.user_data['deposit_method'] = method
    
    amount = context.user_data['deposit_amount']
    bonus = context.user_data.get('deposit_bonus', 0)
    
    if method == 'UPI':
        await query.edit_message_text(
            f"""
💳 <b>UPI Deposit</b>

Amount: {amount} tokens
Bonus: +{bonus} tokens
Total: {amount + bonus} tokens

<b>Payment Details:</b>
UPI ID: <code>payment@upi</code>
Name: {config.BOT_NAME}

<b>Steps:</b>
1. Send payment to above UPI
2. Take screenshot
3. Upload screenshot here

Send screenshot now:
""",
            parse_mode='HTML'
        )
        context.user_data['deposit_network'] = 'UPI'
        return DEPOSIT_PROOF
    
    elif method == 'USDT':
        keyboard = [
            [InlineKeyboardButton("TRC20 (Low fees)", callback_data="dep_net_trc20")],
            [InlineKeyboardButton("ERC20 (Ethereum)", callback_data="dep_net_erc20")],
            [InlineKeyboardButton("🔙 Back", callback_data="deposit")]
        ]
        
        await query.edit_message_text(
            f"""
💎 <b>USDT Deposit</b>

Amount: {amount} tokens
Bonus: +{bonus} tokens

Select network:
""",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='HTML'
        )
        return DEPOSIT_NETWORK
    
    elif method == 'BTC':
        await query.edit_message_text(
            f"""
₿ <b>Bitcoin Deposit</b>

Amount: {amount} tokens
Bonus: +{bonus} tokens
Total: {amount + bonus} tokens

<b>BTC Address:</b>
<code>{config.BTC_ADDRESS}</code>

⚠️ Send only BTC to this address
⏱ Confirmation: 1-3 blocks

Send transaction hash (TXID):
""",
            parse_mode='HTML'
        )
        context.user_data['deposit_network'] = 'BTC'
        return DEPOSIT_PROOF
    
    elif method == 'BNB':
        await query.edit_message_text(
            f"""
🔶 <b>BNB Deposit</b>

Amount: {amount} tokens
Bonus: +{bonus} tokens
Total: {amount + bonus} tokens

<b>BNB Address (BEP20):</b>
<code>{config.BNB_ADDRESS}</code>

⚠️ Use BEP20 network only!
⏱ Fast confirmation

Send transaction hash:
""",
            parse_mode='HTML'
        )
        context.user_data['deposit_network'] = 'BNB-BEP20'
        return DEPOSIT_PROOF

async def deposit_network_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle USDT network selection"""
    query = update.callback_query
    await query.answer()
    
    network = query.data.split('_')[-1].upper()
    context.user_data['deposit_network'] = f"USDT-{network}"
    
    amount = context.user_data['deposit_amount']
    bonus = context.user_data.get('deposit_bonus', 0)
    
    if network == 'TRC20':
        address = config.USDT_TRC20_ADDRESS
        network_name = "TRC20 (Tron)"
        fee = "~1 USDT"
    else:
        address = config.USDT_ERC20_ADDRESS
        network_name = "ERC20 (Ethereum)"
        fee = "High (check gas)"
    
    await query.edit_message_text(
        f"""
💎 <b>USDT {network_name}</b>

Amount: {amount} tokens
Bonus: +{bonus} tokens
Total: {amount + bonus} tokens

<b>Address:</b>
<code>{address}</code>

Network: {network_name}
Fee: {fee}

Send transaction hash or screenshot:
""",
        parse_mode='HTML'
    )
    
    return DEPOSIT_PROOF

async def deposit_proof_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle proof submission"""
    user_id = update.effective_user.id
    db = Database()
    
    amount = context.user_data['deposit_amount']
    bonus = context.user_data.get('deposit_bonus', 0)
    method = context.user_data['deposit_method']
    network = context.user_data.get('deposit_network', method)
    
    # Get proof
    screenshot_id = None
    tx_hash = None
    
    if update.message.photo:
        screenshot_id = update.message.photo[-1].file_id
        tx_hash = "Screenshot uploaded"
    else:
        tx_hash = update.message.text.strip()
    
    # Create deposit
    deposit_id = db.create_deposit(user_id, network, amount, tx_hash, screenshot_id)
    
    await update.message.reply_text(
        f"""
✅ <b>Deposit Submitted!</b>

ID: #{deposit_id}
Amount: {amount} tokens
Bonus: +{bonus} tokens
<b>Total: {amount + bonus} tokens</b>
Method: {network}
Status: ⏳ Pending

Admin will review and approve.
You'll be notified!

💡 Deposits with screenshots are faster!
""",
        reply_markup=get_back_button(),
        parse_mode='HTML'
    )
    
    # Notify admin
    try:
        if screenshot_id:
            await context.bot.send_photo(
                config.ADMIN_ID,
                screenshot_id,
                caption=f"""
🔔 <b>New Deposit</b>

ID: #{deposit_id}
User: {user_id}
Name: {update.effective_user.first_name}
Amount: {amount} tokens
Bonus: {bonus} tokens
Method: {network}
Proof: Screenshot

Use admin panel to approve.
""",
                parse_mode='HTML'
            )
        else:
            await context.bot.send_message(
                config.ADMIN_ID,
                f"""
🔔 <b>New Deposit</b>

ID: #{deposit_id}
User: {user_id}
Name: {update.effective_user.first_name}
Amount: {amount} tokens
Bonus: {bonus} tokens
Method: {network}
TX: {tx_hash}

Use admin panel to approve.
""",
                parse_mode='HTML'
            )
    except:
        pass
    
    context.user_data.clear()
    return ConversationHandler.END

async def cancel_deposit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancel deposit"""
    context.user_data.clear()
    return ConversationHandler.END
