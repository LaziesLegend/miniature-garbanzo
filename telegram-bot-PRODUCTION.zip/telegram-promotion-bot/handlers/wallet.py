from telegram import Update
from telegram.ext import ContextTypes
from database import Database
from handlers.menu import get_back_button
import config

async def balance_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show balance"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    db = Database()
    
    user = db.get_user(user_id)
    level_info = config.USER_LEVELS[user['level']]
    
    await query.edit_message_text(
        f"""
💰 <b>Your Wallet</b>

Balance: <b>{user['tokens']} tokens</b>

📊 <b>Stats:</b>
• Level: {level_info['name']} (Level {user['level']})
• Total Earned: {user['total_earned']} tokens
• Total Spent: {user['total_spent']} tokens
• Trust Score: {user['trust_score']}/100
• Total Joins: {user['total_joins']}
• Success Rate: {int(user['successful_joins']/max(user['total_joins'], 1)*100)}%

🎁 <b>Level Benefits:</b>
• Reward Boost: +{level_info['reward_boost']}%
• Next Level: {config.USER_LEVELS.get(user['level']+1, {}).get('joins', 'Max')} joins

Need tokens? Use "💳 Deposit"!
""",
        reply_markup=get_back_button(),
        parse_mode='HTML'
    )

async def transactions_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show transactions"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    db = Database()
    
    transactions = db.get_user_transactions(user_id, 15)
    
    if not transactions:
        await query.edit_message_text(
            "📜 <b>Transactions</b>\n\nNo transactions yet.",
            reply_markup=get_back_button(),
            parse_mode='HTML'
        )
        return
    
    text = "📜 <b>Recent Transactions</b>\n\n"
    
    for t in transactions:
        trans_type = t['type'].capitalize()
        amount = t['amount']
        desc = t['description']
        time = t['timestamp'][:16]
        
        if t['type'] in ['earning', 'bonus', 'referral', 'deposit']:
            amount_str = f"+{amount}"
            emoji = "📈"
        else:
            amount_str = f"-{amount}"
            emoji = "📉"
        
        text += f"{emoji} <b>{trans_type}:</b> {amount_str}\n"
        text += f"   {desc}\n"
        text += f"   <i>{time}</i>\n\n"
    
    await query.edit_message_text(
        text,
        reply_markup=get_back_button(),
        parse_mode='HTML'
    )
