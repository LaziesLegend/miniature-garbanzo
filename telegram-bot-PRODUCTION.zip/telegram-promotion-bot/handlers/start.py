from telegram import Update
from telegram.ext import ContextTypes
from database import Database
from handlers.menu import get_main_keyboard
import config
import logging

logger = logging.getLogger(__name__)

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start command with referral tracking"""
    user = update.effective_user
    db = Database()
    
    # Check for referral
    referrer_id = None
    if context.args and len(context.args) > 0:
        try:
            referrer_id = int(context.args[0])
            if referrer_id == user.id:
                referrer_id = None  # Prevent self-referral
        except ValueError:
            pass
    
    # Check if user exists
    existing = db.get_user(user.id)
    
    if not existing:
        # New user
        db.add_user(user.id, user.username, user.first_name, referrer_id)
        
        if referrer_id:
            # Process referral bonuses
            # Level 1 bonus
            db.update_user_tokens(referrer_id, config.REFERRAL_BONUS_L1)
            db.add_referral(referrer_id, user.id, 1, config.REFERRAL_BONUS_L1)
            db.add_transaction(referrer_id, 'referral', config.REFERRAL_BONUS_L1, 
                             f'L1 referral bonus from user {user.id}')
            
            # Level 2 bonus (referrer's referrer)
            referrer = db.get_user(referrer_id)
            if referrer and referrer['referred_by']:
                l2_referrer = referrer['referred_by']
                db.update_user_tokens(l2_referrer, config.REFERRAL_BONUS_L2)
                db.add_referral(l2_referrer, user.id, 2, config.REFERRAL_BONUS_L2)
                db.add_transaction(l2_referrer, 'referral', config.REFERRAL_BONUS_L2,
                                 f'L2 referral bonus from user {user.id}')
            
            # Notify referrer
            try:
                await context.bot.send_message(
                    referrer_id,
                    f"🎉 New referral! You earned {config.REFERRAL_BONUS_L1} tokens!\n"
                    f"User: {user.first_name}"
                )
            except:
                pass
    
    # Welcome message
    user_data = db.get_user(user.id)
    level_info = config.USER_LEVELS.get(user_data['level'], config.USER_LEVELS[1])
    
    if config.BOT_LOGO_URL and config.BOT_LOGO_URL != "https://i.imgur.com/your-logo.png":
        try:
            await update.message.reply_photo(
                photo=config.BOT_LOGO_URL,
                caption=f"""
👋 <b>Welcome to {config.BOT_NAME}!</b>

Hello {user.first_name}!

💰 <b>Your Stats:</b>
• Balance: {user_data['tokens']} tokens
• Level: {level_info['name']} (Level {user_data['level']})
• Trust Score: {user_data['trust_score']}/100

🎯 <b>How to Earn:</b>
• Join campaigns: {config.JOIN_REWARD}+ tokens per join
• Daily bonus: {config.DAILY_BONUS} tokens
• Refer friends: {config.REFERRAL_BONUS_L1} tokens per referral
• Play games: Win up to {config.GAMBLE_WIN_MULTIPLIER}x!

🚀 <b>How to Advertise:</b>
• Create campaigns starting at {config.ADVERTISER_COST} tokens/member
• Boost for priority delivery
• Track progress in real-time

💡 <b>Support:</b> {config.SUPPORT_CONTACT}

Use the buttons below to get started!
""",
                reply_markup=get_main_keyboard(),
                parse_mode='HTML'
            )
            return
        except:
            pass
    
    # Fallback text message
    await update.message.reply_text(
        f"""
👋 <b>Welcome to {config.BOT_NAME}!</b>

Hello {user.first_name}!

💰 Balance: {user_data['tokens']} tokens
🏆 Level: {level_info['name']}
⭐ Trust: {user_data['trust_score']}/100

🎯 Earn tokens by joining campaigns
🚀 Create your own campaigns
💎 Refer friends for bonuses

Support: {config.SUPPORT_CONTACT}
""",
        reply_markup=get_main_keyboard(),
        parse_mode='HTML'
    )
