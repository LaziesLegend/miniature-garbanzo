import sqlite3
import logging
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
import config

logger = logging.getLogger(__name__)

class Database:
    def __init__(self, db_name: str = "bot_database.db"):
        self.db_name = db_name
        self.init_database()
    
    def get_connection(self):
        """Get database connection"""
        conn = sqlite3.connect(self.db_name)
        conn.row_factory = sqlite3.Row
        return conn
    
    def init_database(self):
        """Initialize all database tables"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Users table with advanced fields
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                tokens INTEGER DEFAULT 0,
                level INTEGER DEFAULT 1,
                total_earned INTEGER DEFAULT 0,
                total_spent INTEGER DEFAULT 0,
                trust_score INTEGER DEFAULT 100,
                referred_by INTEGER,
                join_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_daily_bonus TIMESTAMP,
                daily_streak INTEGER DEFAULT 0,
                total_joins INTEGER DEFAULT 0,
                successful_joins INTEGER DEFAULT 0,
                is_banned BOOLEAN DEFAULT 0,
                ban_reason TEXT
            )
        ''')
        
        # Campaigns table with all types
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS campaigns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                campaign_type TEXT DEFAULT 'channel',
                channel_link TEXT,
                target_members INTEGER,
                delivered_members INTEGER DEFAULT 0,
                join_reward INTEGER DEFAULT 100,
                advertiser_cost INTEGER DEFAULT 115,
                platform_fee INTEGER DEFAULT 15,
                boost_amount INTEGER DEFAULT 0,
                status TEXT DEFAULT 'active',
                custom_instructions TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                completed_at TIMESTAMP,
                priority_score INTEGER DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        # Campaign joins tracking (prevents duplicates)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS campaign_joins (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                campaign_id INTEGER,
                user_id INTEGER,
                verified BOOLEAN DEFAULT 0,
                joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                left_early BOOLEAN DEFAULT 0,
                rewarded BOOLEAN DEFAULT 0,
                UNIQUE(campaign_id, user_id),
                FOREIGN KEY (campaign_id) REFERENCES campaigns(id),
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        # Custom campaign submissions
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS custom_submissions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                campaign_id INTEGER,
                user_id INTEGER,
                screenshot_file_id TEXT,
                status TEXT DEFAULT 'pending',
                submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                reviewed_at TIMESTAMP,
                FOREIGN KEY (campaign_id) REFERENCES campaigns(id),
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        # Transactions
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                type TEXT,
                amount INTEGER,
                description TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        # Deposits
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS deposits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                method TEXT,
                amount INTEGER,
                bonus_amount INTEGER DEFAULT 0,
                status TEXT DEFAULT 'pending',
                tx_hash TEXT,
                screenshot_file_id TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                approved_at TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        # Referrals with levels
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS referrals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                referrer_id INTEGER,
                referred_user_id INTEGER,
                level INTEGER DEFAULT 1,
                bonus_given INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (referrer_id) REFERENCES users(user_id),
                FOREIGN KEY (referred_user_id) REFERENCES users(user_id)
            )
        ''')
        
        # Daily bonuses
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS daily_bonuses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                amount INTEGER,
                streak_day INTEGER,
                claimed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        # Gamble history
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS gamble_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                bet_amount INTEGER,
                won BOOLEAN,
                winnings INTEGER,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        # Admin actions log
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS admin_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                admin_id INTEGER,
                action TEXT,
                target_user_id INTEGER,
                details TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Rate limiting
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS rate_limits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                action_type TEXT,
                count INTEGER DEFAULT 1,
                date DATE DEFAULT CURRENT_DATE,
                UNIQUE(user_id, action_type, date)
            )
        ''')
        
        conn.commit()
        conn.close()
        logger.info("Database initialized successfully")
    
    # ==================== USER OPERATIONS ====================
    
    def add_user(self, user_id: int, username: str = None, first_name: str = None, referred_by: int = None) -> bool:
        """Add new user"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR IGNORE INTO users (user_id, username, first_name, referred_by, trust_score)
                VALUES (?, ?, ?, ?, ?)
            ''', (user_id, username, first_name, referred_by, config.INITIAL_TRUST_SCORE))
            conn.commit()
            success = cursor.rowcount > 0
            conn.close()
            return success
        except Exception as e:
            logger.error(f"Error adding user: {e}")
            return False
    
    def get_user(self, user_id: int) -> Optional[Dict[str, Any]]:
        """Get user info"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
            row = cursor.fetchone()
            conn.close()
            return dict(row) if row else None
        except Exception as e:
            logger.error(f"Error getting user: {e}")
            return None
    
    def update_user_tokens(self, user_id: int, amount: int, update_stats: bool = True) -> bool:
        """Update tokens and stats"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            if update_stats:
                if amount > 0:
                    cursor.execute('''
                        UPDATE users 
                        SET tokens = tokens + ?, total_earned = total_earned + ?
                        WHERE user_id = ?
                    ''', (amount, amount, user_id))
                else:
                    cursor.execute('''
                        UPDATE users 
                        SET tokens = tokens + ?, total_spent = total_spent + ?
                        WHERE user_id = ?
                    ''', (amount, abs(amount), user_id))
            else:
                cursor.execute('UPDATE users SET tokens = tokens + ? WHERE user_id = ?', (amount, user_id))
            
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error updating tokens: {e}")
            return False
    
    def get_user_balance(self, user_id: int) -> int:
        """Get balance"""
        user = self.get_user(user_id)
        return user['tokens'] if user else 0
    
    def update_user_level(self, user_id: int) -> Optional[int]:
        """Update user level based on joins"""
        try:
            user = self.get_user(user_id)
            if not user:
                return None
            
            joins = user['total_joins']
            current_level = user['level']
            new_level = current_level
            
            for level, data in config.USER_LEVELS.items():
                if joins >= data['joins']:
                    new_level = level
            
            if new_level != current_level:
                conn = self.get_connection()
                cursor = conn.cursor()
                cursor.execute('UPDATE users SET level = ? WHERE user_id = ?', (new_level, user_id))
                conn.commit()
                conn.close()
                return new_level
            
            return current_level
        except Exception as e:
            logger.error(f"Error updating level: {e}")
            return None
    
    def update_trust_score(self, user_id: int, change: int) -> bool:
        """Update trust score"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE users 
                SET trust_score = MAX(0, MIN(100, trust_score + ?))
                WHERE user_id = ?
            ''', (change, user_id))
            conn.commit()
            
            # Check if should be banned
            cursor.execute('SELECT trust_score FROM users WHERE user_id = ?', (user_id,))
            score = cursor.fetchone()
            
            if score and score[0] < config.MIN_TRUST_SCORE:
                cursor.execute('''
                    UPDATE users SET is_banned = 1, ban_reason = ?
                    WHERE user_id = ?
                ''', ("Low trust score", user_id))
                conn.commit()
            
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error updating trust: {e}")
            return False
    
    def is_user_banned(self, user_id: int) -> bool:
        """Check if banned"""
        user = self.get_user(user_id)
        return user['is_banned'] if user else False
    
    # ==================== CAMPAIGN OPERATIONS ====================
    
    def create_campaign(self, user_id: int, campaign_type: str, channel_link: str,
                       target_members: int, join_reward: int, advertiser_cost: int,
                       platform_fee: int, boost_amount: int = 0,
                       custom_instructions: str = None) -> Optional[int]:
        """Create campaign"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            priority_score = boost_amount  # Higher boost = higher priority
            
            cursor.execute('''
                INSERT INTO campaigns (
                    user_id, campaign_type, channel_link, target_members,
                    join_reward, advertiser_cost, platform_fee, boost_amount,
                    custom_instructions, priority_score, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
            ''', (user_id, campaign_type, channel_link, target_members,
                  join_reward, advertiser_cost, platform_fee, boost_amount,
                  custom_instructions, priority_score))
            
            campaign_id = cursor.lastrowid
            conn.commit()
            conn.close()
            return campaign_id
        except Exception as e:
            logger.error(f"Error creating campaign: {e}")
            return None
    
    def get_available_campaigns(self, exclude_user_id: int = None) -> List[Dict[str, Any]]:
        """Get available campaigns sorted by priority"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            if exclude_user_id:
                cursor.execute('''
                    SELECT * FROM campaigns
                    WHERE status = 'active' 
                    AND delivered_members < target_members
                    AND user_id != ?
                    ORDER BY priority_score DESC, created_at DESC
                    LIMIT 50
                ''', (exclude_user_id,))
            else:
                cursor.execute('''
                    SELECT * FROM campaigns
                    WHERE status = 'active'
                    AND delivered_members < target_members
                    ORDER BY priority_score DESC, created_at DESC
                    LIMIT 50
                ''')
            
            rows = cursor.fetchall()
            conn.close()
            return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Error getting campaigns: {e}")
            return []
    
    def get_campaign(self, campaign_id: int) -> Optional[Dict[str, Any]]:
        """Get campaign by ID"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM campaigns WHERE id = ?', (campaign_id,))
            row = cursor.fetchone()
            conn.close()
            return dict(row) if row else None
        except Exception as e:
            logger.error(f"Error getting campaign: {e}")
            return None
    
    def get_user_campaigns(self, user_id: int) -> List[Dict[str, Any]]:
        """Get user's campaigns"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM campaigns
                WHERE user_id = ?
                ORDER BY created_at DESC
            ''', (user_id,))
            rows = cursor.fetchall()
            conn.close()
            return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Error getting user campaigns: {e}")
            return []
    
    def has_user_joined_campaign(self, user_id: int, campaign_id: int) -> bool:
        """Check if user already joined campaign"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                SELECT COUNT(*) FROM campaign_joins
                WHERE user_id = ? AND campaign_id = ?
            ''', (user_id, campaign_id))
            count = cursor.fetchone()[0]
            conn.close()
            return count > 0
        except Exception as e:
            logger.error(f"Error checking join: {e}")
            return False
    
    def add_campaign_join(self, campaign_id: int, user_id: int) -> Optional[int]:
        """Record campaign join"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO campaign_joins (campaign_id, user_id, verified)
                VALUES (?, ?, 1)
            ''', (campaign_id, user_id))
            join_id = cursor.lastrowid
            conn.commit()
            conn.close()
            return join_id
        except Exception as e:
            logger.error(f"Error adding join: {e}")
            return None
    
    def increment_campaign_members(self, campaign_id: int) -> bool:
        """Increment delivered members"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE campaigns
                SET delivered_members = delivered_members + 1
                WHERE id = ?
            ''', (campaign_id,))
            
            # Check if completed
            cursor.execute('''
                SELECT delivered_members, target_members
                FROM campaigns WHERE id = ?
            ''', (campaign_id,))
            row = cursor.fetchone()
            
            if row and row[0] >= row[1]:
                cursor.execute('''
                    UPDATE campaigns
                    SET status = 'completed', completed_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ''', (campaign_id,))
            
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error incrementing members: {e}")
            return False
    
    def mark_join_rewarded(self, join_id: int) -> bool:
        """Mark join as rewarded"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('UPDATE campaign_joins SET rewarded = 1 WHERE id = ?', (join_id,))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error marking rewarded: {e}")
            return False
    
    # ==================== CUSTOM CAMPAIGNS ====================
    
    def add_custom_submission(self, campaign_id: int, user_id: int, screenshot_id: str) -> Optional[int]:
        """Add custom submission"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO custom_submissions (campaign_id, user_id, screenshot_file_id)
                VALUES (?, ?, ?)
            ''', (campaign_id, user_id, screenshot_id))
            sub_id = cursor.lastrowid
            conn.commit()
            conn.close()
            return sub_id
        except Exception as e:
            logger.error(f"Error adding submission: {e}")
            return None
    
    def get_pending_submissions(self, campaign_id: int) -> List[Dict[str, Any]]:
        """Get pending submissions"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM custom_submissions
                WHERE campaign_id = ? AND status = 'pending'
                ORDER BY submitted_at ASC
            ''', (campaign_id,))
            rows = cursor.fetchall()
            conn.close()
            return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Error getting submissions: {e}")
            return []
    
    def approve_submission(self, submission_id: int) -> bool:
        """Approve submission"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE custom_submissions
                SET status = 'approved', reviewed_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ''', (submission_id,))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error approving submission: {e}")
            return False
    
    def get_submission(self, submission_id: int) -> Optional[Dict[str, Any]]:
        """Get submission by ID"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM custom_submissions WHERE id = ?', (submission_id,))
            row = cursor.fetchone()
            conn.close()
            return dict(row) if row else None
        except Exception as e:
            logger.error(f"Error getting submission: {e}")
            return None
    
    # ==================== TRANSACTIONS ====================
    
    def add_transaction(self, user_id: int, trans_type: str, amount: int, description: str) -> bool:
        """Add transaction"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO transactions (user_id, type, amount, description)
                VALUES (?, ?, ?, ?)
            ''', (user_id, trans_type, amount, description))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error adding transaction: {e}")
            return False
    
    def get_user_transactions(self, user_id: int, limit: int = 10) -> List[Dict[str, Any]]:
        """Get transactions"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM transactions
                WHERE user_id = ?
                ORDER BY timestamp DESC
                LIMIT ?
            ''', (user_id, limit))
            rows = cursor.fetchall()
            conn.close()
            return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Error getting transactions: {e}")
            return []
    
    # Continue with remaining methods in next file...
    
    # ==================== DEPOSITS ====================
    
    def create_deposit(self, user_id: int, method: str, amount: int,
                      tx_hash: str = None, screenshot_id: str = None) -> Optional[int]:
        """Create deposit"""
        try:
            # Calculate bonus
            bonus = 0
            for threshold, percent in sorted(config.DEPOSIT_BONUSES.items(), reverse=True):
                if amount >= threshold:
                    bonus = int(amount * percent / 100)
                    break
            
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO deposits (user_id, method, amount, bonus_amount, tx_hash, screenshot_file_id)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (user_id, method, amount, bonus, tx_hash, screenshot_id))
            deposit_id = cursor.lastrowid
            conn.commit()
            conn.close()
            return deposit_id
        except Exception as e:
            logger.error(f"Error creating deposit: {e}")
            return None
    
    def get_pending_deposits(self) -> List[Dict[str, Any]]:
        """Get pending deposits"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM deposits
                WHERE status = 'pending'
                ORDER BY created_at DESC
            ''')
            rows = cursor.fetchall()
            conn.close()
            return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Error getting deposits: {e}")
            return []
    
    def approve_deposit(self, deposit_id: int) -> bool:
        """Approve deposit"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE deposits
                SET status = 'approved', approved_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ''', (deposit_id,))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error approving deposit: {e}")
            return False
    
    def get_deposit(self, deposit_id: int) -> Optional[Dict[str, Any]]:
        """Get deposit"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM deposits WHERE id = ?', (deposit_id,))
            row = cursor.fetchone()
            conn.close()
            return dict(row) if row else None
        except Exception as e:
            logger.error(f"Error getting deposit: {e}")
            return None
    
    # ==================== REFERRALS ====================
    
    def add_referral(self, referrer_id: int, referred_id: int, level: int, bonus: int) -> bool:
        """Add referral"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO referrals (referrer_id, referred_user_id, level, bonus_given)
                VALUES (?, ?, ?, ?)
            ''', (referrer_id, referred_id, level, bonus))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error adding referral: {e}")
            return False
    
    def get_referral_count(self, user_id: int) -> int:
        """Get referral count"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT COUNT(*) FROM referrals WHERE referrer_id = ?', (user_id,))
            count = cursor.fetchone()[0]
            conn.close()
            return count
        except Exception as e:
            logger.error(f"Error getting referral count: {e}")
            return 0
    
    # ==================== DAILY BONUS ====================
    
    def can_claim_daily_bonus(self, user_id: int) -> bool:
        """Check if can claim daily bonus"""
        try:
            user = self.get_user(user_id)
            if not user or not user['last_daily_bonus']:
                return True
            
            last_claim = datetime.fromisoformat(user['last_daily_bonus'])
            return (datetime.now() - last_claim).days >= 1
        except Exception as e:
            logger.error(f"Error checking daily bonus: {e}")
            return False
    
    def claim_daily_bonus(self, user_id: int, amount: int, streak: int) -> bool:
        """Claim daily bonus"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE users
                SET last_daily_bonus = CURRENT_TIMESTAMP, daily_streak = ?
                WHERE user_id = ?
            ''', (streak, user_id))
            
            cursor.execute('''
                INSERT INTO daily_bonuses (user_id, amount, streak_day)
                VALUES (?, ?, ?)
            ''', (user_id, amount, streak))
            
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error claiming daily bonus: {e}")
            return False
    
    # ==================== GAMBLE ====================
    
    def add_gamble_record(self, user_id: int, bet: int, won: bool, winnings: int) -> bool:
        """Record gamble"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO gamble_history (user_id, bet_amount, won, winnings)
                VALUES (?, ?, ?, ?)
            ''', (user_id, bet, won, winnings))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error recording gamble: {e}")
            return False
    
    # ==================== ADMIN ====================
    
    def get_total_users(self) -> int:
        """Get total users"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT COUNT(*) FROM users')
            count = cursor.fetchone()[0]
            conn.close()
            return count
        except Exception as e:
            logger.error(f"Error getting user count: {e}")
            return 0
    
    def get_active_users_today(self) -> int:
        """Get active users today"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                SELECT COUNT(DISTINCT user_id) FROM transactions
                WHERE DATE(timestamp) = DATE('now')
            ''')
            count = cursor.fetchone()[0]
            conn.close()
            return count
        except Exception as e:
            logger.error(f"Error getting active users: {e}")
            return 0
    
    def get_total_campaigns(self) -> int:
        """Get total campaigns"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT COUNT(*) FROM campaigns')
            count = cursor.fetchone()[0]
            conn.close()
            return count
        except Exception as e:
            logger.error(f"Error getting campaign count: {e}")
            return 0
    
    def get_platform_revenue(self) -> int:
        """Get platform revenue"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT SUM(platform_fee) FROM campaigns WHERE status != "cancelled"')
            total = cursor.fetchone()[0]
            conn.close()
            return total if total else 0
        except Exception as e:
            logger.error(f"Error getting revenue: {e}")
            return 0
    
    def get_tokens_in_circulation(self) -> int:
        """Get total tokens"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT SUM(tokens) FROM users')
            total = cursor.fetchone()[0]
            conn.close()
            return total if total else 0
        except Exception as e:
            logger.error(f"Error getting tokens: {e}")
            return 0
    
    def log_admin_action(self, admin_id: int, action: str, target_user: int = None, details: str = None) -> bool:
        """Log admin action"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO admin_logs (admin_id, action, target_user_id, details)
                VALUES (?, ?, ?, ?)
            ''', (admin_id, action, target_user, details))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error logging admin action: {e}")
            return False
