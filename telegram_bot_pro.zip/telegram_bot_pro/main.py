"""
🤖 TELEGRAM MEMBER EXCHANGE BOT
Main bot file with all handlers
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, 
    MessageHandler, filters, ContextTypes
)
from telegram.error import TelegramError
from database import Database
from services.wallet import WalletService
from services.campaign import CampaignService
from services.referral import ReferralService
from config import *
import asyncio

# Setup logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Initialize services
db = Database(DATABASE_NAME)
wallet = WalletService(db)
campaigns = CampaignService(db, wallet)
referrals = ReferralService(db, wallet)

# ========================
# 🎯 UTILITY FUNCTIONS
# ========================

def is_admin(user_id: int) -> bool:
    """Check if user is admin"""
    return user_id in ADMIN_IDS

async def get_or_create_user(update: Update) -> dict:
    """Get user or create if new"""
    user = update.effective_user
    
    # Check if user exists
    existing = db.get_user(user.id)
    if existing:
        db.update_user_activity(user.id)
        return existing
    
    # Handle referral
    referrer_id = None
    if update.message and update.message.text.startswith('/start REF'):
        try:
            ref_code = update.message.text.split()[1]
            if ref_code.startswith('REF'):
                referrer_id = int(ref_code[3:])
        except (IndexError, ValueError):
            pass
    
    # Create user
    db.create_user(
        user_id=user.id,
        username=user.username or "Unknown",
        first_name=user.first_name or "User",
        referred_by=referrer_id,
        signup_bonus=SIGNUP_BONUS
    )
    
    # Process referral bonus
    if referrer_id:
        referrals.process_referral(referrer_id, user.id)
    
    return db.get_user(user.id)

def main_menu_keyboard():
    """Generate main menu keyboard"""
    keyboard = [
        [
            InlineKeyboardButton("💰 My Wallet", callback_data="wallet"),
            InlineKeyboardButton("🚀 Join Tasks", callback_data="tasks")
        ],
        [
            InlineKeyboardButton("📢 Create Campaign", callback_data="create_campaign"),
            InlineKeyboardButton("📊 My Campaigns", callback_data="my_campaigns")
        ],
        [
            InlineKeyboardButton("👥 Referrals", callback_data="referrals"),
            InlineKeyboardButton("💳 Deposit", callback_data="deposit")
        ],
        [
            InlineKeyboardButton("🏆 Leaderboard", callback_data="leaderboard"),
            InlineKeyboardButton("ℹ️ Help", callback_data="help")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

def main_reply_keyboard():
    """Generate reply keyboard (persistent bottom buttons)"""
    keyboard = [
        [
            KeyboardButton("💰 Wallet"),
            KeyboardButton("🚀 Earn Tasks"),
            KeyboardButton("📢 Campaign")
        ],
        [
            KeyboardButton("👥 Referrals"),
            KeyboardButton("📊 My Campaigns"),
            KeyboardButton("💳 Deposit")
        ],
        [
            KeyboardButton("🏆 Leaderboard"),
            KeyboardButton("ℹ️ Help"),
            KeyboardButton("🏠 Menu")
        ]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

# ========================
# 🎬 COMMAND HANDLERS
# ========================

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start command handler"""
    user_data = await get_or_create_user(update)
    
    message = WELCOME_MESSAGE.format(
        join_reward=JOIN_REWARD,
        referral_bonus=REFERRAL_BONUS_L1,
        signup_bonus=SIGNUP_BONUS,
        advertiser_cost=ADVERTISER_COST
    )
    
    await update.message.reply_text(
        message,
        reply_markup=main_reply_keyboard(),  # Add persistent keyboard
        parse_mode='HTML'
    )
    
    # Also send inline keyboard
    await update.message.reply_text(
        "👇 <b>Quick Actions:</b>",
        reply_markup=main_menu_keyboard(),
        parse_mode='HTML'
    )

async def menu_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show main menu"""
    await get_or_create_user(update)
    
    await update.message.reply_text(
        "🏠 <b>Main Menu</b>\n\nChoose an option:",
        reply_markup=main_menu_keyboard(),
        parse_mode='HTML'
    )

# ========================
# 💰 WALLET HANDLERS
# ========================

async def wallet_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show wallet balance and stats"""
    query = update.callback_query
    await query.answer()
    
    user = await get_or_create_user(update)
    
    # Get level info
    level_data = LEVELS.get(user['level'], LEVELS[1])
    
    # Calculate next level
    next_level = user['level'] + 1 if user['level'] < max(LEVELS.keys()) else None
    next_level_joins = LEVELS[next_level]['joins'] if next_level else 0
    
    message = f"""
💰 <b>Your Wallet</b>

💵 <b>Balance:</b> {user['tokens']:,} tokens
📊 <b>Level:</b> {level_data['name']} (Level {user['level']})
⭐ <b>Trust Score:</b> {user['trust_score']}/100

📈 <b>Statistics:</b>
• Total Earned: {user['total_earned']:,} tokens
• Total Spent: {user['total_spent']:,} tokens
• Total Joins: {user['total_joins']}
• Total Referrals: {user['total_referrals']}

🎯 <b>Reward Multiplier:</b> {level_data['reward_multiplier']}x
"""
    
    if next_level:
        progress = user['total_joins']
        needed = next_level_joins - progress
        message += f"\n🔓 <b>Next Level:</b> {needed} more joins needed"
    
    keyboard = [
        [InlineKeyboardButton("📜 Transaction History", callback_data="transactions")],
        [InlineKeyboardButton("🔙 Back to Menu", callback_data="menu")]
    ]
    
    await query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def transactions_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show transaction history"""
    query = update.callback_query
    await query.answer()
    
    user = await get_or_create_user(update)
    transactions = wallet.get_transaction_history(user['user_id'], limit=10)
    
    message = "📜 <b>Recent Transactions</b>\n\n"
    
    if not transactions:
        message += "No transactions yet."
    else:
        for tx in transactions:
            symbol = "+" if tx['amount'] > 0 else ""
            message += f"• {symbol}{tx['amount']} tokens - {tx['description']}\n"
    
    keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="wallet")]]
    
    await query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

# ========================
# 🚀 TASK HANDLERS
# ========================

async def tasks_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show available join tasks"""
    query = update.callback_query
    await query.answer()
    
    user = await get_or_create_user(update)
    
    # Get available campaigns
    available = campaigns.get_available_tasks(user['user_id'], page=0)
    
    message = "🚀 <b>Available Join Tasks</b>\n\n"
    
    if not available:
        message += "No campaigns available right now.\nCheck back later!"
        keyboard = [[InlineKeyboardButton("🔙 Back to Menu", callback_data="menu")]]
    else:
        message += f"💰 Earn <b>{JOIN_REWARD} tokens</b> per join!\n\n"
        
        keyboard = []
        for camp in available[:5]:
            progress = f"{camp['delivered_members']}/{camp['target_members']}"
            keyboard.append([
                InlineKeyboardButton(
                    f"@{camp['channel_username']} - {progress} members",
                    callback_data=f"join_{camp['id']}"
                )
            ])
        
        keyboard.append([InlineKeyboardButton("🔙 Back to Menu", callback_data="menu")])
    
    await query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def join_campaign_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle join campaign action"""
    query = update.callback_query
    await query.answer()
    
    campaign_id = int(query.data.split('_')[1])
    user = await get_or_create_user(update)
    
    # Attempt to join
    result = campaigns.join_campaign(campaign_id, user['user_id'])
    
    if not result['success']:
        await query.answer(result['error'], show_alert=True)
        return
    
    campaign = result['campaign']
    channel_username = result['channel_username']
    
    message = f"""
✅ <b>Task Accepted!</b>

📢 <b>Channel:</b> @{channel_username}
💰 <b>Reward:</b> {campaign['join_reward']} tokens

<b>Instructions:</b>
1️⃣ Click the button below
2️⃣ Join the Telegram channel
3️⃣ Come back and click "Verify Join"

⚠️ Do not leave the channel immediately or your trust score will decrease!
"""
    
    keyboard = [
        [InlineKeyboardButton("📢 Join Channel", url=f"https://t.me/{channel_username}")],
        [InlineKeyboardButton("✅ Verify Join", callback_data=f"verify_{campaign_id}")],
        [InlineKeyboardButton("❌ Cancel", callback_data="tasks")]
    ]
    
    await query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def verify_join_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Verify channel membership"""
    query = update.callback_query
    campaign_id = int(query.data.split('_')[1])
    user = await get_or_create_user(update)
    
    await query.answer("🔍 Verifying membership...", show_alert=False)
    
    # Get campaign details
    campaign = db.get_campaign(campaign_id)
    if not campaign:
        await query.answer("Campaign not found", show_alert=True)
        return
    
    # Verify membership using Telegram API
    is_member = await check_channel_membership(
        context.bot,
        f"@{campaign['channel_username']}",
        user['user_id']
    )
    
    # Process verification
    result = campaigns.verify_and_reward(campaign_id, user['user_id'], is_member)
    
    if result['success']:
        message = f"""
🎉 <b>Verification Successful!</b>

✅ Join verified!
💰 <b>Earned:</b> +{result['reward']} tokens
💵 <b>New Balance:</b> {result['new_balance']:,} tokens

📊 Campaign Progress: {result['campaign_progress']}

Keep earning by joining more campaigns!
"""
        keyboard = [
            [InlineKeyboardButton("🚀 More Tasks", callback_data="tasks")],
            [InlineKeyboardButton("🔙 Main Menu", callback_data="menu")]
        ]
    else:
        message = f"""
❌ <b>Verification Failed</b>

{result['error']}

Please make sure you:
1. Actually joined the channel
2. Didn't leave immediately
3. Have a good trust score

Try again or choose another task.
"""
        keyboard = [
            [InlineKeyboardButton("🔄 Try Again", callback_data=f"verify_{campaign_id}")],
            [InlineKeyboardButton("🚀 Other Tasks", callback_data="tasks")]
        ]
    
    await query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def check_channel_membership(bot, channel_username: str, user_id: int) -> bool:
    """Check if user is a member of the channel"""
    try:
        member = await bot.get_chat_member(chat_id=channel_username, user_id=user_id)
        return member.status in ['member', 'administrator', 'creator']
    except TelegramError:
        return False

# ========================
# 📢 CAMPAIGN CREATION
# ========================

async def create_campaign_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start campaign creation"""
    query = update.callback_query
    await query.answer()
    
    user = await get_or_create_user(update)
    
    message = f"""
📢 <b>Create Campaign</b>

Promote your Telegram channel!

💰 <b>Pricing:</b>
• {ADVERTISER_COST} tokens per member
• Minimum: {MIN_CAMPAIGN_MEMBERS} members
• Maximum: {MAX_CAMPAIGN_MEMBERS} members

💵 <b>Your Balance:</b> {user['tokens']:,} tokens

<b>To create a campaign, send:</b>
<code>/campaign @channel_username 100</code>

Where:
• @channel_username = your channel
• 100 = number of members wanted
"""
    
    keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="menu")]]
    
    await query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def campaign_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Process campaign creation command"""
    user = await get_or_create_user(update)
    
    try:
        # Parse command: /campaign @channel 100
        parts = update.message.text.split()
        if len(parts) != 3:
            raise ValueError("Invalid format")
        
        channel_link = parts[1]
        target_members = int(parts[2])
        
        # Create campaign
        result = campaigns.create_campaign(user['user_id'], channel_link, target_members)
        
        if result['success']:
            costs = result['costs']
            message = CAMPAIGN_CREATED_MESSAGE.format(
                channel=result['channel'],
                members=costs['members'],
                total_cost=costs['total_cost'],
                balance=result['remaining_balance']
            )
            
            keyboard = [
                [InlineKeyboardButton("📊 View Campaign", callback_data=f"campaign_{result['campaign_id']}")],
                [InlineKeyboardButton("🔙 Main Menu", callback_data="menu")]
            ]
        else:
            message = f"❌ <b>Campaign Creation Failed</b>\n\n{result['error']}"
            keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="menu")]]
        
        await update.message.reply_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='HTML'
        )
    
    except (ValueError, IndexError):
        await update.message.reply_text(
            "❌ <b>Invalid Format</b>\n\n"
            "Usage: <code>/campaign @username 100</code>\n\n"
            "Example: <code>/campaign @mychannel 50</code>",
            parse_mode='HTML'
        )

async def my_campaigns_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user's campaigns"""
    query = update.callback_query
    await query.answer()
    
    user = await get_or_create_user(update)
    user_campaigns = db.get_user_campaigns(user['user_id'])
    
    message = "📊 <b>My Campaigns</b>\n\n"
    
    if not user_campaigns:
        message += "You haven't created any campaigns yet."
        keyboard = [
            [InlineKeyboardButton("📢 Create Campaign", callback_data="create_campaign")],
            [InlineKeyboardButton("🔙 Back", callback_data="menu")]
        ]
    else:
        keyboard = []
        for camp in user_campaigns[:10]:
            status_emoji = {"active": "🟢", "completed": "✅", "cancelled": "❌"}.get(camp['status'], "⚪")
            progress = f"{camp['delivered_members']}/{camp['target_members']}"
            
            keyboard.append([
                InlineKeyboardButton(
                    f"{status_emoji} @{camp['channel_username']} - {progress}",
                    callback_data=f"campaign_{camp['id']}"
                )
            ])
        
        keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="menu")])
    
    await query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def campaign_details_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show campaign details"""
    query = update.callback_query
    await query.answer()
    
    campaign_id = int(query.data.split('_')[1])
    stats = campaigns.get_campaign_stats(campaign_id)
    
    if not stats:
        await query.answer("Campaign not found", show_alert=True)
        return
    
    status_emoji = {"active": "🟢 Active", "completed": "✅ Completed", "cancelled": "❌ Cancelled"}.get(stats['status'], "⚪ Unknown")
    
    message = f"""
📊 <b>Campaign Details</b>

📢 <b>Channel:</b> @{stats['channel_username']}
🔹 <b>Status:</b> {status_emoji}

📈 <b>Progress:</b>
• Delivered: {stats['delivered_members']}/{stats['target_members']} ({stats['completion_percentage']}%)
• Pending: {stats['pending_joins']}
• Remaining: {stats['remaining']}

💰 <b>Costs:</b>
• Total Paid: {stats['total_cost']:,} tokens
• Per Member: {stats['advertiser_rate']} tokens
• Reward/Member: {stats['join_reward']} tokens

📅 <b>Created:</b> {stats['created_at'][:16]}
"""
    
    keyboard = []
    
    # Add cancel button if active and user owns it
    user = await get_or_create_user(update)
    if stats['user_id'] == user['user_id'] and stats['status'] == 'active':
        keyboard.append([InlineKeyboardButton("❌ Cancel Campaign", callback_data=f"cancel_campaign_{campaign_id}")])
    
    keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="my_campaigns")])
    
    await query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def cancel_campaign_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancel campaign with confirmation"""
    query = update.callback_query
    
    campaign_id = int(query.data.split('_')[2])
    user = await get_or_create_user(update)
    
    if 'confirm' not in query.data:
        # Show confirmation
        await query.answer()
        message = "⚠️ Are you sure you want to cancel this campaign?\n\nYou'll get a refund for undelivered members."
        keyboard = [
            [InlineKeyboardButton("✅ Yes, Cancel", callback_data=f"cancel_campaign_confirm_{campaign_id}")],
            [InlineKeyboardButton("❌ No, Keep It", callback_data=f"campaign_{campaign_id}")]
        ]
        await query.edit_message_text(message, reply_markup=InlineKeyboardMarkup(keyboard))
    else:
        # Process cancellation
        result = campaigns.cancel_campaign(campaign_id, user['user_id'])
        
        if result['success']:
            message = f"""
✅ <b>Campaign Cancelled</b>

💰 <b>Refunded:</b> {result['refunded']:,} tokens
📊 <b>Members Delivered:</b> {result['delivered']}
💵 <b>New Balance:</b> {result['new_balance']:,} tokens
"""
            await query.answer("Campaign cancelled successfully!")
        else:
            message = f"❌ <b>Cancellation Failed</b>\n\n{result['error']}"
            await query.answer(result['error'], show_alert=True)
        
        keyboard = [[InlineKeyboardButton("🔙 My Campaigns", callback_data="my_campaigns")]]
        await query.edit_message_text(message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='HTML')

# ========================
# 👥 REFERRAL HANDLERS
# ========================

async def referrals_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show referral information"""
    query = update.callback_query
    await query.answer()
    
    user = await get_or_create_user(update)
    bot_username = (await context.bot.get_me()).username
    
    ref_link = referrals.get_referral_link(user['user_id'], bot_username)
    stats = referrals.get_referral_stats(user['user_id'])
    
    message = f"""
👥 <b>Referral Program</b>

🎁 <b>Your Referral Link:</b>
<code>{ref_link}</code>

💰 <b>Earnings:</b>
• Level 1: {REFERRAL_BONUS_L1} tokens/referral
• Level 2: {REFERRAL_BONUS_L2} tokens/referral

📊 <b>Your Stats:</b>
• Total Referrals: {stats['total_referrals']}
• Active Referrals: {stats['active_referrals']}
• Total Earned: {stats['total_earned']:,} tokens

Share your link and earn passive income!
"""
    
    keyboard = [
        [InlineKeyboardButton("📤 Share Link", url=f"https://t.me/share/url?url={ref_link}&text=Join this amazing bot!")],
        [InlineKeyboardButton("🔙 Back", callback_data="menu")]
    ]
    
    await query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

# ========================
# 💳 DEPOSIT HANDLERS
# ========================

async def deposit_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show deposit options"""
    query = update.callback_query
    await query.answer()
    
    message = """
💳 <b>Deposit Tokens</b>

Choose payment method:

💵 <b>UPI Payment</b>
• Instant processing
• +5% bonus tokens

💎 <b>Crypto Payment</b>
• BTC, ETH, USDT
• +10% bonus tokens

🎁 <b>Deposit Bonuses:</b>
• Bronze (1000+): +5%
• Silver (5000+): +10%
• Gold (10000+): +15%

Contact admin to deposit!
"""
    
    keyboard = [
        [InlineKeyboardButton("📱 Deposit via UPI", callback_data="deposit_upi")],
        [InlineKeyboardButton("💎 Deposit via Crypto", callback_data="deposit_crypto")],
        [InlineKeyboardButton("🔙 Back", callback_data="menu")]
    ]
    
    await query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

# ========================
# 🏆 LEADERBOARD HANDLER
# ========================

async def leaderboard_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show leaderboard"""
    query = update.callback_query
    await query.answer()
    
    top_users = db.get_leaderboard(LEADERBOARD_TOP_N)
    
    message = "🏆 <b>Top Earners Leaderboard</b>\n\n"
    
    medals = ["🥇", "🥈", "🥉"]
    for i, user_data in enumerate(top_users):
        medal = medals[i] if i < 3 else f"{i+1}."
        username = user_data['username'] or "Unknown"
        message += f"{medal} @{username} - {user_data['total_earned']:,} tokens\n"
    
    keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="menu")]]
    
    await query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

# ========================
# ℹ️ HELP HANDLER
# ========================

async def help_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show help information"""
    query = update.callback_query
    await query.answer()
    
    message = f"""
ℹ️ <b>Help & Information</b>

<b>🎯 How It Works:</b>
1. Join campaigns to earn {JOIN_REWARD} tokens
2. Create campaigns to promote channels
3. Refer friends for bonuses
4. Maintain high trust score

<b>💰 Token Economy:</b>
• Join Reward: {JOIN_REWARD} tokens
• Campaign Cost: {ADVERTISER_COST} tokens/member
• Referral Bonus: {REFERRAL_BONUS_L1} + {REFERRAL_BONUS_L2} tokens

<b>⭐ Trust Score:</b>
• Start at 100
• Earn +2 per verified join
• Lose -10 for fake joins
• Minimum 20 to earn

<b>🎮 Levels & Multipliers:</b>
• Bronze (50 joins): 1.05x
• Silver (200 joins): 1.10x
• Gold (500 joins): 1.15x
• Platinum (1000 joins): 1.20x

Need help? Contact admin!
"""
    
    keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="menu")]]
    
    await query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

# ========================
# 👑 ADMIN HANDLERS
# ========================

async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Admin panel"""
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("⛔ Access denied")
        return
    
    stats = db.get_platform_stats()
    
    message = f"""
👑 <b>Admin Panel</b>

📊 <b>Platform Statistics:</b>
• Total Users: {stats['total_users']:,}
• Active (24h): {stats['active_users_24h']:,}
• Total Campaigns: {stats['total_campaigns']:,}
• Active Campaigns: {stats['active_campaigns']:,}

💰 <b>Economy:</b>
• Tokens in Circulation: {stats['tokens_circulation']:,}
• Platform Profit: {stats['platform_profit']:,}

💳 <b>Pending Actions:</b>
• Pending Deposits: {stats['pending_deposits']}
"""
    
    keyboard = [
        [
            InlineKeyboardButton("💳 Deposits", callback_data="admin_deposits"),
            InlineKeyboardButton("👤 Users", callback_data="admin_users")
        ],
        [
            InlineKeyboardButton("➕ Add Tokens", callback_data="admin_add_tokens"),
            InlineKeyboardButton("➖ Deduct Tokens", callback_data="admin_deduct_tokens")
        ],
        [
            InlineKeyboardButton("📢 Broadcast", callback_data="admin_broadcast"),
            InlineKeyboardButton("🔒 Ban User", callback_data="admin_ban")
        ]
    ]
    
    await update.message.reply_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def admin_deposits_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show pending deposits"""
    query = update.callback_query
    
    if not is_admin(query.from_user.id):
        await query.answer("Access denied", show_alert=True)
        return
    
    await query.answer()
    
    pending = db.get_pending_deposits()
    
    message = "💳 <b>Pending Deposits</b>\n\n"
    
    if not pending:
        message += "No pending deposits."
        keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="admin_panel")]]
    else:
        keyboard = []
        for deposit in pending[:5]:
            text = f"{deposit['username']} - {deposit['amount']} tokens ({deposit['method']})"
            keyboard.append([
                InlineKeyboardButton(text, callback_data=f"deposit_view_{deposit['id']}")
            ])
        keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="admin_panel")])
    
    await query.edit_message_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Return to main menu"""
    query = update.callback_query
    await query.answer()
    
    await query.edit_message_text(
        "🏠 <b>Main Menu</b>\n\nChoose an option:",
        reply_markup=main_menu_keyboard(),
        parse_mode='HTML'
    )

# ========================
# 📱 KEYBOARD BUTTON HANDLERS
# ========================

async def keyboard_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle keyboard button presses"""
    text = update.message.text
    user = await get_or_create_user(update)
    
    # Map keyboard buttons to inline actions
    button_map = {
        "💰 Wallet": "wallet",
        "🚀 Earn Tasks": "tasks",
        "📢 Campaign": "create_campaign",
        "👥 Referrals": "referrals",
        "📊 My Campaigns": "my_campaigns",
        "💳 Deposit": "deposit",
        "🏆 Leaderboard": "leaderboard",
        "ℹ️ Help": "help",
        "🏠 Menu": "menu"
    }
    
    if text in button_map:
        # Create a fake callback query to reuse existing handlers
        action = button_map[text]
        
        if action == "wallet":
            await show_wallet(update, context, user)
        elif action == "tasks":
            await show_tasks(update, context, user)
        elif action == "create_campaign":
            await show_create_campaign(update, context, user)
        elif action == "referrals":
            await show_referrals(update, context, user)
        elif action == "my_campaigns":
            await show_my_campaigns(update, context, user)
        elif action == "deposit":
            await show_deposit(update, context, user)
        elif action == "leaderboard":
            await show_leaderboard(update, context, user)
        elif action == "help":
            await show_help(update, context, user)
        elif action == "menu":
            await update.message.reply_text(
                "🏠 <b>Main Menu</b>\n\nChoose an option:",
                reply_markup=main_menu_keyboard(),
                parse_mode='HTML'
            )

# Standalone functions for keyboard handlers
async def show_wallet(update: Update, context: ContextTypes.DEFAULT_TYPE, user: dict):
    """Show wallet for keyboard button"""
    level_data = LEVELS.get(user['level'], LEVELS[1])
    next_level = user['level'] + 1 if user['level'] < max(LEVELS.keys()) else None
    next_level_joins = LEVELS[next_level]['joins'] if next_level else 0
    
    message = f"""
💰 <b>Your Wallet</b>

💵 <b>Balance:</b> {user['tokens']:,} tokens
📊 <b>Level:</b> {level_data['name']} (Level {user['level']})
⭐ <b>Trust Score:</b> {user['trust_score']}/100

📈 <b>Statistics:</b>
• Total Earned: {user['total_earned']:,} tokens
• Total Spent: {user['total_spent']:,} tokens
• Total Joins: {user['total_joins']}
• Total Referrals: {user['total_referrals']}

🎯 <b>Reward Multiplier:</b> {level_data['reward_multiplier']}x
"""
    
    if next_level:
        progress = user['total_joins']
        needed = next_level_joins - progress
        message += f"\n🔓 <b>Next Level:</b> {needed} more joins needed"
    
    keyboard = [
        [InlineKeyboardButton("📜 Transaction History", callback_data="transactions")],
        [InlineKeyboardButton("🔙 Back to Menu", callback_data="menu")]
    ]
    
    await update.message.reply_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def show_tasks(update: Update, context: ContextTypes.DEFAULT_TYPE, user: dict):
    """Show tasks for keyboard button"""
    available = campaigns.get_available_tasks(user['user_id'], page=0)
    
    message = "🚀 <b>Available Join Tasks</b>\n\n"
    
    if not available:
        message += "No campaigns available right now.\nCheck back later!"
        keyboard = [[InlineKeyboardButton("🔙 Back to Menu", callback_data="menu")]]
    else:
        message += f"💰 Earn <b>{JOIN_REWARD} tokens</b> per join!\n\n"
        
        keyboard = []
        for camp in available[:5]:
            progress = f"{camp['delivered_members']}/{camp['target_members']}"
            keyboard.append([
                InlineKeyboardButton(
                    f"@{camp['channel_username']} - {progress} members",
                    callback_data=f"join_{camp['id']}"
                )
            ])
        
        keyboard.append([InlineKeyboardButton("🔙 Back to Menu", callback_data="menu")])
    
    await update.message.reply_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def show_create_campaign(update: Update, context: ContextTypes.DEFAULT_TYPE, user: dict):
    """Show campaign creation for keyboard button"""
    message = f"""
📢 <b>Create Campaign</b>

Promote your Telegram channel!

💰 <b>Pricing:</b>
• {ADVERTISER_COST} tokens per member
• Minimum: {MIN_CAMPAIGN_MEMBERS} members
• Maximum: {MAX_CAMPAIGN_MEMBERS} members

💵 <b>Your Balance:</b> {user['tokens']:,} tokens

<b>To create a campaign, send:</b>
<code>/campaign @channel_username 100</code>

Where:
• @channel_username = your channel
• 100 = number of members wanted
"""
    
    keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="menu")]]
    
    await update.message.reply_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def show_referrals(update: Update, context: ContextTypes.DEFAULT_TYPE, user: dict):
    """Show referrals for keyboard button"""
    bot_username = (await context.bot.get_me()).username
    ref_link = referrals.get_referral_link(user['user_id'], bot_username)
    stats = referrals.get_referral_stats(user['user_id'])
    
    message = f"""
👥 <b>Referral Program</b>

🎁 <b>Your Referral Link:</b>
<code>{ref_link}</code>

💰 <b>Earnings:</b>
• Level 1: {REFERRAL_BONUS_L1} tokens/referral
• Level 2: {REFERRAL_BONUS_L2} tokens/referral

📊 <b>Your Stats:</b>
• Total Referrals: {stats['total_referrals']}
• Active Referrals: {stats['active_referrals']}
• Total Earned: {stats['total_earned']:,} tokens

Share your link and earn passive income!
"""
    
    keyboard = [
        [InlineKeyboardButton("📤 Share Link", url=f"https://t.me/share/url?url={ref_link}&text=Join this amazing bot!")],
        [InlineKeyboardButton("🔙 Back", callback_data="menu")]
    ]
    
    await update.message.reply_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def show_my_campaigns(update: Update, context: ContextTypes.DEFAULT_TYPE, user: dict):
    """Show my campaigns for keyboard button"""
    user_campaigns = db.get_user_campaigns(user['user_id'])
    
    message = "📊 <b>My Campaigns</b>\n\n"
    
    if not user_campaigns:
        message += "You haven't created any campaigns yet."
        keyboard = [
            [InlineKeyboardButton("📢 Create Campaign", callback_data="create_campaign")],
            [InlineKeyboardButton("🔙 Back", callback_data="menu")]
        ]
    else:
        keyboard = []
        for camp in user_campaigns[:10]:
            status_emoji = {"active": "🟢", "completed": "✅", "cancelled": "❌"}.get(camp['status'], "⚪")
            progress = f"{camp['delivered_members']}/{camp['target_members']}"
            
            keyboard.append([
                InlineKeyboardButton(
                    f"{status_emoji} @{camp['channel_username']} - {progress}",
                    callback_data=f"campaign_{camp['id']}"
                )
            ])
        
        keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="menu")])
    
    await update.message.reply_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def show_deposit(update: Update, context: ContextTypes.DEFAULT_TYPE, user: dict):
    """Show deposit for keyboard button"""
    message = """
💳 <b>Deposit Tokens</b>

Choose payment method:

💵 <b>UPI Payment</b>
• Instant processing
• +5% bonus tokens

💎 <b>Crypto Payment</b>
• BTC, ETH, USDT
• +10% bonus tokens

🎁 <b>Deposit Bonuses:</b>
• Bronze (1000+): +5%
• Silver (5000+): +10%
• Gold (10000+): +15%

Contact admin to deposit!
"""
    
    keyboard = [
        [InlineKeyboardButton("📱 Deposit via UPI", callback_data="deposit_upi")],
        [InlineKeyboardButton("💎 Deposit via Crypto", callback_data="deposit_crypto")],
        [InlineKeyboardButton("🔙 Back", callback_data="menu")]
    ]
    
    await update.message.reply_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def show_leaderboard(update: Update, context: ContextTypes.DEFAULT_TYPE, user: dict):
    """Show leaderboard for keyboard button"""
    top_users = db.get_leaderboard(LEADERBOARD_TOP_N)
    
    message = "🏆 <b>Top Earners Leaderboard</b>\n\n"
    
    medals = ["🥇", "🥈", "🥉"]
    for i, user_data in enumerate(top_users):
        medal = medals[i] if i < 3 else f"{i+1}."
        username = user_data['username'] or "Unknown"
        message += f"{medal} @{username} - {user_data['total_earned']:,} tokens\n"
    
    keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="menu")]]
    
    await update.message.reply_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def show_help(update: Update, context: ContextTypes.DEFAULT_TYPE, user: dict):
    """Show help for keyboard button"""
    message = f"""
ℹ️ <b>Help & Information</b>

<b>🎯 How It Works:</b>
1. Join campaigns to earn {JOIN_REWARD} tokens
2. Create campaigns to promote channels
3. Refer friends for bonuses
4. Maintain high trust score

<b>💰 Token Economy:</b>
• Join Reward: {JOIN_REWARD} tokens
• Campaign Cost: {ADVERTISER_COST} tokens/member
• Referral Bonus: {REFERRAL_BONUS_L1} + {REFERRAL_BONUS_L2} tokens

<b>⭐ Trust Score:</b>
• Start at 100
• Earn +2 per verified join
• Lose -10 for fake joins
• Minimum 20 to earn

<b>🎮 Levels & Multipliers:</b>
• Bronze (50 joins): 1.05x
• Silver (200 joins): 1.10x
• Gold (500 joins): 1.15x
• Platinum (1000 joins): 1.20x

Need help? Contact admin!
"""
    
    keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="menu")]]
    
    await update.message.reply_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

# ========================
# 🚀 MAIN FUNCTION
# ========================

def main():
    """Start the bot"""
    print("🚀 Starting Telegram Member Exchange Bot...")
    print(f"📊 Database: {DATABASE_NAME}")
    print(f"💰 Join Reward: {JOIN_REWARD} tokens")
    print(f"💵 Advertiser Cost: {ADVERTISER_COST} tokens")
    print(f"🏢 Platform Fee: {PLATFORM_FEE} tokens")
    
    # Create application
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Command handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("menu", menu_command))
    application.add_handler(CommandHandler("campaign", campaign_command))
    application.add_handler(CommandHandler("admin", admin_command))
    
    # Keyboard button handlers (text messages)
    application.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND, 
        keyboard_handler
    ))
    
    # Callback query handlers
    application.add_handler(CallbackQueryHandler(wallet_handler, pattern="^wallet$"))
    application.add_handler(CallbackQueryHandler(transactions_handler, pattern="^transactions$"))
    application.add_handler(CallbackQueryHandler(tasks_handler, pattern="^tasks$"))
    application.add_handler(CallbackQueryHandler(join_campaign_handler, pattern="^join_"))
    application.add_handler(CallbackQueryHandler(verify_join_handler, pattern="^verify_"))
    application.add_handler(CallbackQueryHandler(create_campaign_handler, pattern="^create_campaign$"))
    application.add_handler(CallbackQueryHandler(my_campaigns_handler, pattern="^my_campaigns$"))
    application.add_handler(CallbackQueryHandler(campaign_details_handler, pattern="^campaign_\\d+$"))
    application.add_handler(CallbackQueryHandler(cancel_campaign_handler, pattern="^cancel_campaign"))
    application.add_handler(CallbackQueryHandler(referrals_handler, pattern="^referrals$"))
    application.add_handler(CallbackQueryHandler(deposit_handler, pattern="^deposit$"))
    application.add_handler(CallbackQueryHandler(leaderboard_handler, pattern="^leaderboard$"))
    application.add_handler(CallbackQueryHandler(help_handler, pattern="^help$"))
    application.add_handler(CallbackQueryHandler(admin_deposits_handler, pattern="^admin_deposits$"))
    application.add_handler(CallbackQueryHandler(menu_callback, pattern="^menu$"))
    
    # Start bot
    print("✅ Bot is running!")
    print("⚠️ Remember to add your BOT_TOKEN in config.py")
    print("🎹 Keyboard buttons enabled!")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
