"""
🚀 TELEGRAM MEMBER EXCHANGE BOT - CONFIGURATION
Advanced Token Economy System
"""

import os
from typing import Final

# ========================
# 🤖 BOT CONFIGURATION
# ========================
BOT_TOKEN: Final = "YOUR_BOT_TOKEN_HERE"  # Get from @BotFather
ADMIN_IDS: Final = [123456789]  # Add your Telegram user ID

# ========================
# 💰 TOKEN ECONOMY
# ========================
JOIN_REWARD: Final = 90  # Tokens user earns per join
ADVERTISER_COST: Final = 115  # Tokens advertiser pays per member
PLATFORM_FEE: Final = ADVERTISER_COST - JOIN_REWARD  # Auto-calculated: 25 tokens

MIN_CAMPAIGN_MEMBERS: Final = 5  # Minimum campaign size
MAX_CAMPAIGN_MEMBERS: Final = 10000  # Maximum campaign size

# ========================
# 👥 REFERRAL SYSTEM
# ========================
REFERRAL_BONUS_L1: Final = 10  # Level 1 referral bonus
REFERRAL_BONUS_L2: Final = 3   # Level 2 referral bonus
SIGNUP_BONUS: Final = 50       # Welcome bonus for new users

# ========================
# 💳 DEPOSIT SYSTEM
# ========================
DEPOSIT_METHODS = {
    "UPI": {"enabled": True, "bonus_percent": 5},
    "CRYPTO": {"enabled": True, "bonus_percent": 10}
}

DEPOSIT_TIERS = {
    "BRONZE": {"min": 1000, "bonus_percent": 5},
    "SILVER": {"min": 5000, "bonus_percent": 10},
    "GOLD": {"min": 10000, "bonus_percent": 15}
}

# ========================
# 🎮 LEVEL SYSTEM
# ========================
LEVELS = {
    1: {"joins": 0, "name": "Beginner", "reward_multiplier": 1.0},
    2: {"joins": 50, "name": "Bronze", "reward_multiplier": 1.05},
    3: {"joins": 200, "name": "Silver", "reward_multiplier": 1.10},
    4: {"joins": 500, "name": "Gold", "reward_multiplier": 1.15},
    5: {"joins": 1000, "name": "Platinum", "reward_multiplier": 1.20}
}

# ========================
# 🛡️ ANTI-CHEAT SYSTEM
# ========================
INITIAL_TRUST_SCORE: Final = 100
MIN_TRUST_SCORE: Final = 20
TRUST_PENALTIES = {
    "fake_join": -10,
    "leave_after_join": -5,
    "spam_report": -15
}
TRUST_REWARDS = {
    "successful_join": 2,
    "campaign_complete": 5
}

MAX_DAILY_JOINS: Final = 50  # Rate limiting
JOIN_COOLDOWN_SECONDS: Final = 60  # Prevent spam

# ========================
# 💸 WITHDRAWAL SYSTEM (Future)
# ========================
MIN_WITHDRAWAL: Final = 1000
WITHDRAWAL_FEE_PERCENT: Final = 5
DAILY_WITHDRAWAL_LIMIT: Final = 10000

# ========================
# 📊 ANALYTICS
# ========================
LEADERBOARD_TOP_N: Final = 10

# ========================
# 🎨 UI/UX
# ========================
ITEMS_PER_PAGE: Final = 5  # Pagination

# ========================
# 💬 MESSAGES
# ========================
WELCOME_MESSAGE = """
🎉 <b>Welcome to Member Exchange Bot!</b>

💰 <b>Earn Tokens:</b>
• Join campaigns: {join_reward} tokens per join
• Refer friends: {referral_bonus} tokens per referral
• Daily login bonus: 10 tokens

🚀 <b>Create Campaigns:</b>
• Promote your Telegram channels
• Only {advertiser_cost} tokens per member
• Fast & reliable delivery

🎁 <b>Welcome Bonus:</b> {signup_bonus} tokens!

👇 Choose an option:
"""

CAMPAIGN_CREATED_MESSAGE = """
✅ <b>Campaign Created Successfully!</b>

📊 <b>Campaign Details:</b>
• Channel: {channel}
• Target Members: {members}
• Cost: {total_cost} tokens
• Remaining Balance: {balance} tokens

⏳ Your campaign is now active!
Members will start joining shortly.
"""

# ========================
# 🗄️ DATABASE
# ========================
DATABASE_NAME: Final = "bot_database.db"

# ========================
# 🔒 SECURITY
# ========================
REQUIRE_CHANNEL_VERIFICATION: Final = True
ANTI_SPAM_ENABLED: Final = True
