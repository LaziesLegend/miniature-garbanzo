#!/bin/bash

# 🚀 Telegram Member Exchange Bot - Setup Script

echo "╔══════════════════════════════════════════╗"
echo "║  Telegram Member Exchange Bot Setup     ║"
echo "║  Advanced Token Economy System           ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# Check Python version
echo "🔍 Checking Python version..."
python3 --version

if [ $? -ne 0 ]; then
    echo "❌ Python 3 not found. Please install Python 3.8 or higher."
    exit 1
fi

echo "✅ Python found!"
echo ""

# Install dependencies
echo "📦 Installing dependencies..."
pip install -r requirements.txt

if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies."
    exit 1
fi

echo "✅ Dependencies installed!"
echo ""

# Initialize database
echo "🗄️ Initializing database..."
python3 -c "from database import Database; db = Database(); print('✅ Database initialized!')"

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║  🎉 Setup Complete!                      ║"
echo "╚══════════════════════════════════════════╝"
echo ""
echo "📝 Next Steps:"
echo "1. Edit config.py and add your BOT_TOKEN"
echo "2. Add your Telegram user ID to ADMIN_IDS"
echo "3. Customize token economy settings"
echo "4. Run: python3 main.py"
echo ""
echo "💡 Pro Tip: Test with a small campaign first!"
echo ""
echo "📖 Read README.md for complete documentation"
echo ""
