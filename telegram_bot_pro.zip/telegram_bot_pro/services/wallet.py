"""
💰 WALLET SERVICE
Handles all token transactions and balance management
"""

from database import Database
from config import *
from typing import Optional

class WalletService:
    def __init__(self, db: Database):
        self.db = db
    
    def get_balance(self, user_id: int) -> int:
        """Get user's token balance"""
        user = self.db.get_user(user_id)
        return user['tokens'] if user else 0
    
    def add_tokens(self, user_id: int, amount: int, reason: str, 
                   related_id: Optional[int] = None) -> bool:
        """Add tokens to user balance"""
        return self.db.update_tokens(
            user_id=user_id,
            amount=amount,
            transaction_type='earn',
            description=reason,
            related_id=related_id
        )
    
    def deduct_tokens(self, user_id: int, amount: int, reason: str,
                     related_id: Optional[int] = None) -> bool:
        """Deduct tokens from user balance"""
        return self.db.update_tokens(
            user_id=user_id,
            amount=-amount,
            transaction_type='spend',
            description=reason,
            related_id=related_id
        )
    
    def has_sufficient_balance(self, user_id: int, amount: int) -> bool:
        """Check if user has enough tokens"""
        return self.get_balance(user_id) >= amount
    
    def get_transaction_history(self, user_id: int, limit: int = 10):
        """Get user's recent transactions"""
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT * FROM transactions
            WHERE user_id = ?
            ORDER BY created_at DESC
            LIMIT ?
        """, (user_id, limit))
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]
