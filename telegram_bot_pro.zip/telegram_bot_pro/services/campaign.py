"""
🚀 CAMPAIGN SERVICE
Advanced campaign management with verification
"""

from database import Database
from services.wallet import WalletService
from config import *
from typing import Optional, Dict, List
import re

class CampaignService:
    def __init__(self, db: Database, wallet: WalletService):
        self.db = db
        self.wallet = wallet
    
    def validate_channel_link(self, link: str) -> Optional[str]:
        """Extract and validate Telegram channel username"""
        # Match t.me/username or @username
        patterns = [
            r't\.me/([a-zA-Z0-9_]+)',
            r'@([a-zA-Z0-9_]+)',
            r'([a-zA-Z0-9_]+)'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, link)
            if match:
                username = match.group(1)
                if len(username) >= 5:
                    return username
        return None
    
    def calculate_campaign_cost(self, members: int) -> Dict[str, int]:
        """Calculate campaign costs"""
        total_cost = members * ADVERTISER_COST
        total_rewards = members * JOIN_REWARD
        platform_profit = members * PLATFORM_FEE
        
        return {
            'members': members,
            'cost_per_member': ADVERTISER_COST,
            'reward_per_member': JOIN_REWARD,
            'platform_fee_per_member': PLATFORM_FEE,
            'total_cost': total_cost,
            'total_rewards': total_rewards,
            'platform_profit': platform_profit
        }
    
    def create_campaign(self, user_id: int, channel_link: str, 
                       target_members: int) -> Dict[str, any]:
        """Create new campaign with validation"""
        # Validate member count
        if target_members < MIN_CAMPAIGN_MEMBERS:
            return {
                'success': False,
                'error': f"Minimum {MIN_CAMPAIGN_MEMBERS} members required"
            }
        
        if target_members > MAX_CAMPAIGN_MEMBERS:
            return {
                'success': False,
                'error': f"Maximum {MAX_CAMPAIGN_MEMBERS} members allowed"
            }
        
        # Validate channel link
        channel_username = self.validate_channel_link(channel_link)
        if not channel_username:
            return {
                'success': False,
                'error': "Invalid channel link. Use format: @username or t.me/username"
            }
        
        # Calculate costs
        costs = self.calculate_campaign_cost(target_members)
        total_cost = costs['total_cost']
        
        # Check balance
        if not self.wallet.has_sufficient_balance(user_id, total_cost):
            current_balance = self.wallet.get_balance(user_id)
            return {
                'success': False,
                'error': f"Insufficient balance. Need {total_cost} tokens, have {current_balance}",
                'required': total_cost,
                'current': current_balance
            }
        
        # Deduct tokens
        if not self.wallet.deduct_tokens(
            user_id=user_id,
            amount=total_cost,
            reason=f"Campaign creation: {target_members} members"
        ):
            return {'success': False, 'error': "Payment failed"}
        
        # Create campaign
        campaign_id = self.db.create_campaign(
            user_id=user_id,
            channel_link=channel_link,
            channel_username=channel_username,
            target_members=target_members,
            join_reward=JOIN_REWARD,
            advertiser_rate=ADVERTISER_COST,
            platform_fee=PLATFORM_FEE,
            total_cost=total_cost
        )
        
        if not campaign_id:
            # Refund on failure
            self.wallet.add_tokens(user_id, total_cost, "Campaign creation refund")
            return {'success': False, 'error': "Failed to create campaign"}
        
        return {
            'success': True,
            'campaign_id': campaign_id,
            'channel': f"@{channel_username}",
            'costs': costs,
            'remaining_balance': self.wallet.get_balance(user_id)
        }
    
    def get_available_tasks(self, user_id: int, page: int = 0) -> List[Dict]:
        """Get campaigns available for user to join - excludes user's own campaigns"""
        # Check user's trust score
        user = self.db.get_user(user_id)
        if not user or user['trust_score'] < MIN_TRUST_SCORE:
            return []
        
        # Get campaigns - EXCLUDING user's own campaigns
        offset = page * ITEMS_PER_PAGE
        campaigns = self.db.get_active_campaigns(
            exclude_user=user_id,  # This excludes campaigns created by this user
            limit=ITEMS_PER_PAGE,
            offset=offset
        )
        
        # Additional filter: Remove already joined campaigns
        available = []
        for campaign in campaigns:
            # Double check it's not the user's campaign
            if campaign['user_id'] == user_id:
                continue
            
            # Check if already joined
            if not self.db.check_already_joined(campaign['id'], user_id):
                available.append(campaign)
        
        return available
    
    def join_campaign(self, campaign_id: int, user_id: int) -> Dict[str, any]:
        """User joins a campaign"""
        # Get campaign
        campaign = self.db.get_campaign(campaign_id)
        if not campaign:
            return {'success': False, 'error': "Campaign not found"}
        
        if campaign['status'] != 'active':
            return {'success': False, 'error': "Campaign is not active"}
        
        if campaign['delivered_members'] >= campaign['target_members']:
            return {'success': False, 'error': "Campaign is full"}
        
        # Check already joined
        if self.db.check_already_joined(campaign_id, user_id):
            return {'success': False, 'error': "Already joined this campaign"}
        
        # Check user's own campaign
        if campaign['user_id'] == user_id:
            return {'success': False, 'error': "Cannot join your own campaign"}
        
        # Check trust score
        user = self.db.get_user(user_id)
        if user['trust_score'] < MIN_TRUST_SCORE:
            return {'success': False, 'error': "Trust score too low"}
        
        # Record join attempt
        if not self.db.record_join_attempt(campaign_id, user_id):
            return {'success': False, 'error': "Failed to record join"}
        
        return {
            'success': True,
            'campaign': campaign,
            'channel_username': campaign['channel_username']
        }
    
    def verify_and_reward(self, campaign_id: int, user_id: int, 
                         is_verified: bool) -> Dict[str, any]:
        """Verify join and distribute rewards"""
        if not is_verified:
            # Penalize trust score for fake join
            self.db.update_trust_score(
                user_id=user_id,
                change=TRUST_PENALTIES['fake_join'],
                reason="Failed verification"
            )
            return {
                'success': False,
                'error': "Verification failed",
                'trust_penalty': TRUST_PENALTIES['fake_join']
            }
        
        # Mark as verified
        if not self.db.verify_join(campaign_id, user_id):
            return {'success': False, 'error': "Already verified or error occurred"}
        
        # Get campaign details
        campaign = self.db.get_campaign(campaign_id)
        reward = campaign['join_reward']
        
        # Apply level multiplier
        user = self.db.get_user(user_id)
        level_data = LEVELS.get(user['level'], LEVELS[1])
        reward = int(reward * level_data['reward_multiplier'])
        
        # Reward user
        self.wallet.add_tokens(
            user_id=user_id,
            amount=reward,
            reason=f"Joined campaign #{campaign_id}",
            related_id=campaign_id
        )
        
        # Reward trust score
        self.db.update_trust_score(
            user_id=user_id,
            change=TRUST_REWARDS['successful_join'],
            reason="Successful join verification"
        )
        
        # Check if campaign completed
        updated_campaign = self.db.get_campaign(campaign_id)
        if updated_campaign['delivered_members'] >= updated_campaign['target_members']:
            self.db.update_campaign_status(campaign_id, 'completed')
        
        # Check level up
        self.check_level_up(user_id)
        
        return {
            'success': True,
            'reward': reward,
            'new_balance': self.wallet.get_balance(user_id),
            'campaign_progress': f"{updated_campaign['delivered_members']}/{updated_campaign['target_members']}"
        }
    
    def check_level_up(self, user_id: int):
        """Check and update user level"""
        user = self.db.get_user(user_id)
        total_joins = user['total_joins']
        current_level = user['level']
        
        # Find appropriate level
        new_level = current_level
        for level, data in sorted(LEVELS.items(), reverse=True):
            if total_joins >= data['joins']:
                new_level = level
                break
        
        # Update if leveled up
        if new_level > current_level:
            conn = self.db.get_connection()
            cursor = conn.cursor()
            cursor.execute("UPDATE users SET level = ? WHERE user_id = ?", 
                         (new_level, user_id))
            conn.commit()
            conn.close()
            return new_level
        return None
    
    def get_campaign_stats(self, campaign_id: int) -> Optional[Dict]:
        """Get detailed campaign statistics"""
        campaign = self.db.get_campaign(campaign_id)
        if not campaign:
            return None
        
        conn = self.db.get_connection()
        cursor = conn.cursor()
        
        # Get join stats
        cursor.execute("""
            SELECT 
                COUNT(*) as total_joins,
                SUM(verified) as verified_joins,
                COUNT(*) - SUM(verified) as pending_joins
            FROM campaign_joins
            WHERE campaign_id = ?
        """, (campaign_id,))
        
        stats = dict(cursor.fetchone())
        conn.close()
        
        return {
            **campaign,
            **stats,
            'completion_percentage': int((campaign['delivered_members'] / campaign['target_members']) * 100),
            'remaining': campaign['target_members'] - campaign['delivered_members']
        }
    
    def cancel_campaign(self, campaign_id: int, user_id: int) -> Dict[str, any]:
        """Cancel campaign and refund remaining tokens"""
        campaign = self.db.get_campaign(campaign_id)
        
        if not campaign:
            return {'success': False, 'error': "Campaign not found"}
        
        if campaign['user_id'] != user_id:
            return {'success': False, 'error': "Not your campaign"}
        
        if campaign['status'] != 'active':
            return {'success': False, 'error': "Campaign already ended"}
        
        # Calculate refund
        delivered = campaign['delivered_members']
        pending = campaign['pending_members']
        target = campaign['target_members']
        remaining = target - delivered - pending
        
        refund_amount = remaining * ADVERTISER_COST
        
        # Update status
        self.db.update_campaign_status(campaign_id, 'cancelled')
        
        # Refund tokens
        if refund_amount > 0:
            self.wallet.add_tokens(
                user_id=user_id,
                amount=refund_amount,
                reason=f"Campaign #{campaign_id} cancellation refund",
                related_id=campaign_id
            )
        
        return {
            'success': True,
            'refunded': refund_amount,
            'delivered': delivered,
            'new_balance': self.wallet.get_balance(user_id)
        }
