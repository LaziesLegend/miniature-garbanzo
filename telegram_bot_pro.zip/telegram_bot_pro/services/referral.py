"""
👥 REFERRAL SERVICE
Multi-level referral system
"""

from database import Database
from services.wallet import WalletService
from config import *
import hashlib

class ReferralService:
    def __init__(self, db: Database, wallet: WalletService):
        self.db = db
        self.wallet = wallet
    
    def generate_referral_code(self, user_id: int) -> str:
        """Generate unique referral code"""
        return f"REF{user_id}"
    
    def get_referral_link(self, user_id: int, bot_username: str) -> str:
        """Generate referral link"""
        code = self.generate_referral_code(user_id)
        return f"https://t.me/{bot_username}?start={code}"
    
    def process_referral(self, referrer_id: int, referred_user_id: int) -> Dict[str, any]:
        """Process referral bonus"""
        # Check self-referral
        if referrer_id == referred_user_id:
            return {'success': False, 'error': "Cannot refer yourself"}
        
        # Level 1 bonus to direct referrer
        l1_bonus = REFERRAL_BONUS_L1
        if self.wallet.add_tokens(
            user_id=referrer_id,
            amount=l1_bonus,
            reason=f"Level 1 referral bonus (User {referred_user_id})"
        ):
            self.db.record_referral(referrer_id, referred_user_id, 1, l1_bonus)
        
        # Level 2 bonus (if referrer was also referred)
        referrer = self.db.get_user(referrer_id)
        if referrer and referrer['referred_by']:
            l2_referrer_id = referrer['referred_by']
            l2_bonus = REFERRAL_BONUS_L2
            
            if self.wallet.add_tokens(
                user_id=l2_referrer_id,
                amount=l2_bonus,
                reason=f"Level 2 referral bonus (User {referred_user_id})"
            ):
                self.db.record_referral(l2_referrer_id, referred_user_id, 2, l2_bonus)
        
        return {
            'success': True,
            'level_1_bonus': l1_bonus,
            'level_2_bonus': REFERRAL_BONUS_L2 if referrer['referred_by'] else 0
        }
    
    def get_referral_stats(self, user_id: int) -> Dict:
        """Get user's referral statistics"""
        referrals = self.db.get_user_referrals(user_id)
        
        total_earned = sum(r['bonus_given'] for r in referrals)
        active_referrals = len([r for r in referrals if r['total_earned'] > 0])
        
        return {
            'total_referrals': len(referrals),
            'active_referrals': active_referrals,
            'total_earned': total_earned,
            'referrals': referrals[:10]  # Top 10
        }
