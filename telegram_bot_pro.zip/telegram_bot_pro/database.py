"""
🗄️ DATABASE LAYER - Advanced Schema
Handles all data operations with proper relationships
"""

import sqlite3
from datetime import datetime
from typing import Optional, List, Dict, Any
import json

class Database:
    def __init__(self, db_name: str = "bot_database.db"):
        self.db_name = db_name
        self.init_database()
    
    def get_connection(self):
        """Get database connection"""
        conn = sqlite3.connect(self.db_name)
        conn.row_factory = sqlite3.Row
        return conn
    
    def init_database(self):
        """Initialize all database tables"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # ========================
        # 👤 USERS TABLE
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                tokens INTEGER DEFAULT 0,
                level INTEGER DEFAULT 1,
                trust_score INTEGER DEFAULT 100,
                total_joins INTEGER DEFAULT 0,
                total_earned INTEGER DEFAULT 0,
                total_spent INTEGER DEFAULT 0,
                total_referrals INTEGER DEFAULT 0,
                referred_by INTEGER,
                join_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_banned INTEGER DEFAULT 0,
                ban_reason TEXT,
                FOREIGN KEY (referred_by) REFERENCES users(user_id)
            )
        """)
        
        # ========================
        # 🚀 CAMPAIGNS TABLE
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS campaigns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                channel_link TEXT NOT NULL,
                channel_username TEXT,
                target_members INTEGER NOT NULL,
                delivered_members INTEGER DEFAULT 0,
                pending_members INTEGER DEFAULT 0,
                join_reward INTEGER NOT NULL,
                advertiser_rate INTEGER NOT NULL,
                platform_fee INTEGER NOT NULL,
                total_cost INTEGER NOT NULL,
                status TEXT DEFAULT 'active',
                priority INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                completed_at TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        
        # ========================
        # 🔗 CAMPAIGN JOINS TABLE
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS campaign_joins (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                campaign_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                verified INTEGER DEFAULT 0,
                verification_attempts INTEGER DEFAULT 0,
                joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                verified_at TIMESTAMP,
                left_channel INTEGER DEFAULT 0,
                FOREIGN KEY (campaign_id) REFERENCES campaigns(id),
                FOREIGN KEY (user_id) REFERENCES users(user_id),
                UNIQUE(campaign_id, user_id)
            )
        """)
        
        # ========================
        # 💰 TRANSACTIONS TABLE
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                type TEXT NOT NULL,
                amount INTEGER NOT NULL,
                description TEXT,
                related_id INTEGER,
                balance_before INTEGER,
                balance_after INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        
        # ========================
        # 💳 DEPOSITS TABLE
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS deposits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                method TEXT NOT NULL,
                amount INTEGER NOT NULL,
                bonus_amount INTEGER DEFAULT 0,
                total_credited INTEGER,
                status TEXT DEFAULT 'pending',
                tx_hash TEXT,
                screenshot_file_id TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                approved_at TIMESTAMP,
                approved_by INTEGER,
                reject_reason TEXT,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        
        # ========================
        # 👥 REFERRALS TABLE
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS referrals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                referrer_id INTEGER NOT NULL,
                referred_user_id INTEGER NOT NULL,
                level INTEGER DEFAULT 1,
                bonus_given INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (referrer_id) REFERENCES users(user_id),
                FOREIGN KEY (referred_user_id) REFERENCES users(user_id),
                UNIQUE(referrer_id, referred_user_id)
            )
        """)
        
        # ========================
        # 🛡️ SECURITY LOGS TABLE
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS security_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                event_type TEXT NOT NULL,
                description TEXT,
                severity TEXT DEFAULT 'low',
                metadata TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        
        # ========================
        # 📊 USER STATISTICS TABLE
        # ========================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_stats (
                user_id INTEGER PRIMARY KEY,
                daily_joins INTEGER DEFAULT 0,
                last_join_date DATE,
                join_success_rate REAL DEFAULT 100.0,
                avg_verification_time INTEGER,
                total_campaigns_created INTEGER DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        
        # Create indexes for performance
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_campaigns_status ON campaigns(status)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_campaigns_user ON campaigns(user_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_joins_campaign ON campaign_joins(campaign_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_joins_user ON campaign_joins(user_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_deposits_status ON deposits(status)")
        
        conn.commit()
        conn.close()
    
    # ========================
    # 👤 USER OPERATIONS
    # ========================
    
    def create_user(self, user_id: int, username: str, first_name: str, 
                   referred_by: Optional[int] = None, signup_bonus: int = 50) -> bool:
        """Create new user with signup bonus"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute("""
                INSERT INTO users (user_id, username, first_name, tokens, referred_by)
                VALUES (?, ?, ?, ?, ?)
            """, (user_id, username, first_name, signup_bonus, referred_by))
            
            # Log signup bonus transaction
            cursor.execute("""
                INSERT INTO transactions (user_id, type, amount, description, balance_after)
                VALUES (?, 'bonus', ?, 'Signup bonus', ?)
            """, (user_id, signup_bonus, signup_bonus))
            
            # Create user stats entry
            cursor.execute("""
                INSERT INTO user_stats (user_id) VALUES (?)
            """, (user_id,))
            
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False
        finally:
            conn.close()
    
    def get_user(self, user_id: int) -> Optional[Dict]:
        """Get user data"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None
    
    def update_user_activity(self, user_id: int):
        """Update last active timestamp"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE users SET last_active = CURRENT_TIMESTAMP WHERE user_id = ?
        """, (user_id,))
        conn.commit()
        conn.close()
    
    def update_tokens(self, user_id: int, amount: int, transaction_type: str, 
                     description: str, related_id: Optional[int] = None) -> bool:
        """Update user tokens with transaction log"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            # Get current balance
            cursor.execute("SELECT tokens FROM users WHERE user_id = ?", (user_id,))
            result = cursor.fetchone()
            if not result:
                return False
            
            balance_before = result[0]
            balance_after = balance_before + amount
            
            if balance_after < 0:
                return False  # Insufficient balance
            
            # Update balance
            cursor.execute("""
                UPDATE users SET tokens = ?, 
                total_earned = total_earned + CASE WHEN ? > 0 THEN ? ELSE 0 END,
                total_spent = total_spent + CASE WHEN ? < 0 THEN ABS(?) ELSE 0 END
                WHERE user_id = ?
            """, (balance_after, amount, amount, amount, amount, user_id))
            
            # Log transaction
            cursor.execute("""
                INSERT INTO transactions (user_id, type, amount, description, related_id,
                                        balance_before, balance_after)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (user_id, transaction_type, amount, description, related_id, 
                 balance_before, balance_after))
            
            conn.commit()
            return True
        except Exception as e:
            conn.rollback()
            return False
        finally:
            conn.close()
    
    def update_trust_score(self, user_id: int, change: int, reason: str):
        """Update user trust score"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            UPDATE users 
            SET trust_score = MAX(0, MIN(100, trust_score + ?))
            WHERE user_id = ?
        """, (change, user_id))
        
        # Log security event
        cursor.execute("""
            INSERT INTO security_logs (user_id, event_type, description, metadata)
            VALUES (?, 'trust_score_change', ?, ?)
        """, (user_id, reason, json.dumps({"change": change})))
        
        conn.commit()
        conn.close()
    
    def get_leaderboard(self, limit: int = 10) -> List[Dict]:
        """Get top users by earnings"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT user_id, username, first_name, total_earned, total_joins, level
            FROM users
            WHERE is_banned = 0
            ORDER BY total_earned DESC
            LIMIT ?
        """, (limit,))
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]
    
    # ========================
    # 🚀 CAMPAIGN OPERATIONS
    # ========================
    
    def create_campaign(self, user_id: int, channel_link: str, channel_username: str,
                       target_members: int, join_reward: int, advertiser_rate: int,
                       platform_fee: int, total_cost: int) -> Optional[int]:
        """Create new campaign"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute("""
                INSERT INTO campaigns (user_id, channel_link, channel_username,
                                     target_members, join_reward, advertiser_rate,
                                     platform_fee, total_cost)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (user_id, channel_link, channel_username, target_members,
                 join_reward, advertiser_rate, platform_fee, total_cost))
            
            campaign_id = cursor.lastrowid
            conn.commit()
            return campaign_id
        except Exception:
            conn.rollback()
            return None
        finally:
            conn.close()
    
    def get_campaign(self, campaign_id: int) -> Optional[Dict]:
        """Get campaign details"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM campaigns WHERE id = ?", (campaign_id,))
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None
    
    def get_active_campaigns(self, exclude_user: Optional[int] = None, 
                            limit: int = 5, offset: int = 0) -> List[Dict]:
        """Get active campaigns for users to join - excludes campaigns by exclude_user"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        query = """
            SELECT c.*, u.username as creator_username
            FROM campaigns c
            JOIN users u ON c.user_id = u.user_id
            WHERE c.status = 'active' 
            AND c.delivered_members < c.target_members
        """
        params = []
        
        # IMPORTANT: Exclude campaigns created by this user (they can't join their own)
        if exclude_user:
            query += " AND c.user_id != ?"
            params.append(exclude_user)
        
        query += " ORDER BY c.priority DESC, c.created_at DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        
        cursor.execute(query, params)
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]
    
    def get_user_campaigns(self, user_id: int) -> List[Dict]:
        """Get campaigns created by user"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT * FROM campaigns 
            WHERE user_id = ? 
            ORDER BY created_at DESC
        """, (user_id,))
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]
    
    def update_campaign_status(self, campaign_id: int, status: str):
        """Update campaign status"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE campaigns SET status = ?,
            completed_at = CASE WHEN ? = 'completed' THEN CURRENT_TIMESTAMP ELSE completed_at END
            WHERE id = ?
        """, (status, status, campaign_id))
        conn.commit()
        conn.close()
    
    # ========================
    # 🔗 JOIN OPERATIONS
    # ========================
    
    def record_join_attempt(self, campaign_id: int, user_id: int) -> bool:
        """Record a join attempt"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute("""
                INSERT INTO campaign_joins (campaign_id, user_id)
                VALUES (?, ?)
            """, (campaign_id, user_id))
            
            # Update pending count
            cursor.execute("""
                UPDATE campaigns 
                SET pending_members = pending_members + 1
                WHERE id = ?
            """, (campaign_id,))
            
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False  # Already joined
        finally:
            conn.close()
    
    def verify_join(self, campaign_id: int, user_id: int) -> bool:
        """Mark join as verified and process rewards"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            # Update join record
            cursor.execute("""
                UPDATE campaign_joins 
                SET verified = 1, verified_at = CURRENT_TIMESTAMP
                WHERE campaign_id = ? AND user_id = ? AND verified = 0
            """, (campaign_id, user_id))
            
            if cursor.rowcount == 0:
                return False
            
            # Update campaign counts
            cursor.execute("""
                UPDATE campaigns 
                SET delivered_members = delivered_members + 1,
                    pending_members = pending_members - 1
                WHERE id = ?
            """, (campaign_id,))
            
            # Update user join count
            cursor.execute("""
                UPDATE users SET total_joins = total_joins + 1
                WHERE user_id = ?
            """, (user_id,))
            
            conn.commit()
            return True
        except Exception:
            conn.rollback()
            return False
        finally:
            conn.close()
    
    def check_already_joined(self, campaign_id: int, user_id: int) -> bool:
        """Check if user already joined this campaign"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT 1 FROM campaign_joins 
            WHERE campaign_id = ? AND user_id = ?
        """, (campaign_id, user_id))
        result = cursor.fetchone()
        conn.close()
        return result is not None
    
    # ========================
    # 💳 DEPOSIT OPERATIONS
    # ========================
    
    def create_deposit(self, user_id: int, method: str, amount: int,
                      tx_hash: Optional[str] = None, 
                      screenshot_file_id: Optional[str] = None) -> int:
        """Create deposit request"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO deposits (user_id, method, amount, tx_hash, screenshot_file_id)
            VALUES (?, ?, ?, ?, ?)
        """, (user_id, method, amount, tx_hash, screenshot_file_id))
        
        deposit_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return deposit_id
    
    def get_pending_deposits(self) -> List[Dict]:
        """Get all pending deposits"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT d.*, u.username, u.first_name
            FROM deposits d
            JOIN users u ON d.user_id = u.user_id
            WHERE d.status = 'pending'
            ORDER BY d.created_at ASC
        """)
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]
    
    def approve_deposit(self, deposit_id: int, admin_id: int, 
                       bonus_amount: int, total_credited: int) -> bool:
        """Approve deposit and credit tokens"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            # Get deposit info
            cursor.execute("SELECT user_id FROM deposits WHERE id = ?", (deposit_id,))
            result = cursor.fetchone()
            if not result:
                return False
            
            user_id = result[0]
            
            # Update deposit
            cursor.execute("""
                UPDATE deposits 
                SET status = 'approved', bonus_amount = ?, total_credited = ?,
                    approved_at = CURRENT_TIMESTAMP, approved_by = ?
                WHERE id = ?
            """, (bonus_amount, total_credited, admin_id, deposit_id))
            
            conn.commit()
            return True
        except Exception:
            conn.rollback()
            return False
        finally:
            conn.close()
    
    # ========================
    # 👥 REFERRAL OPERATIONS
    # ========================
    
    def record_referral(self, referrer_id: int, referred_user_id: int, 
                       level: int, bonus: int) -> bool:
        """Record referral relationship"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute("""
                INSERT INTO referrals (referrer_id, referred_user_id, level, bonus_given)
                VALUES (?, ?, ?, ?)
            """, (referrer_id, referred_user_id, level, bonus))
            
            # Update referrer's total referrals
            cursor.execute("""
                UPDATE users SET total_referrals = total_referrals + 1
                WHERE user_id = ?
            """, (referrer_id,))
            
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False
        finally:
            conn.close()
    
    def get_user_referrals(self, user_id: int) -> List[Dict]:
        """Get user's referrals"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT r.*, u.username, u.first_name, u.total_earned
            FROM referrals r
            JOIN users u ON r.referred_user_id = u.user_id
            WHERE r.referrer_id = ?
            ORDER BY r.created_at DESC
        """, (user_id,))
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]
    
    # ========================
    # 📊 ANALYTICS
    # ========================
    
    def get_platform_stats(self) -> Dict:
        """Get platform statistics"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        stats = {}
        
        # Total users
        cursor.execute("SELECT COUNT(*) FROM users")
        stats['total_users'] = cursor.fetchone()[0]
        
        # Active users (last 24h)
        cursor.execute("""
            SELECT COUNT(*) FROM users 
            WHERE last_active > datetime('now', '-1 day')
        """)
        stats['active_users_24h'] = cursor.fetchone()[0]
        
        # Total campaigns
        cursor.execute("SELECT COUNT(*) FROM campaigns")
        stats['total_campaigns'] = cursor.fetchone()[0]
        
        # Active campaigns
        cursor.execute("SELECT COUNT(*) FROM campaigns WHERE status = 'active'")
        stats['active_campaigns'] = cursor.fetchone()[0]
        
        # Total tokens in circulation
        cursor.execute("SELECT SUM(tokens) FROM users")
        stats['tokens_circulation'] = cursor.fetchone()[0] or 0
        
        # Platform profit
        cursor.execute("SELECT SUM(platform_fee * delivered_members) FROM campaigns")
        stats['platform_profit'] = cursor.fetchone()[0] or 0
        
        # Pending deposits
        cursor.execute("SELECT COUNT(*) FROM deposits WHERE status = 'pending'")
        stats['pending_deposits'] = cursor.fetchone()[0]
        
        conn.close()
        return stats
