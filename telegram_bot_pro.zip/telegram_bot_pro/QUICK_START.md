# 🎯 QUICK START GUIDE

## Get Your Bot Running in 5 Minutes!

### Step 1: Get Bot Token (2 minutes)
1. Open Telegram and search for **@BotFather**
2. Send `/newbot`
3. Choose a name: "My Member Bot"
4. Choose a username: "my_member_exchange_bot"
5. **Copy the token** (looks like: `1234567890:ABCdefGHIjklMNOpqrsTUVwxyz`)

### Step 2: Get Your User ID (1 minute)
1. Search for **@userinfobot** in Telegram
2. Start it and it will show your ID
3. **Copy your ID** (looks like: `123456789`)

### Step 3: Configure Bot (1 minute)
Open `config.py` and edit these lines:

```python
BOT_TOKEN = "1234567890:ABCdefGHIjklMNOpqrsTUVwxyz"  # Paste your token
ADMIN_IDS = [123456789]  # Paste your ID
```

### Step 4: Install & Run (1 minute)
```bash
# Install dependencies
pip install python-telegram-bot

# Run the bot
python main.py
```

You should see:
```
🚀 Starting Telegram Member Exchange Bot...
✅ Bot is running!
```

### Step 5: Test Your Bot
1. Open Telegram and search for your bot
2. Send `/start`
3. You should receive the welcome message!

## 🎉 That's It!

Your bot is now running with all features:
- ✅ Token wallet system
- ✅ Campaign creation
- ✅ Join tasks
- ✅ Referral system
- ✅ Admin panel
- ✅ Trust scoring
- ✅ Level system

## 🧪 Test Everything

### As User:
1. `/start` - Get welcome bonus (50 tokens)
2. Click "💰 My Wallet" - See your balance
3. Click "🚀 Join Tasks" - Browse campaigns
4. Create a test campaign: `/campaign @testchannel 5`

### As Admin:
1. `/admin` - Access admin panel
2. View statistics
3. Manage users and deposits

## ⚙️ Customize Your Bot

Edit `config.py` to change:

```python
# Token rewards
JOIN_REWARD = 90              # User earns per join
ADVERTISER_COST = 115         # Advertiser pays
PLATFORM_FEE = 25             # Your profit

# Bonuses
REFERRAL_BONUS_L1 = 10        # Direct referral
SIGNUP_BONUS = 50             # Welcome bonus

# Limits
MIN_CAMPAIGN_MEMBERS = 5      # Minimum campaign size
MAX_CAMPAIGN_MEMBERS = 10000  # Maximum campaign size
```

## 🚀 Launch Checklist

- [ ] Bot token configured
- [ ] Admin ID added
- [ ] Token economy set
- [ ] Bot tested with `/start`
- [ ] Test campaign created
- [ ] Join task verified
- [ ] Referral link tested
- [ ] Admin panel checked

## 💡 Pro Tips

1. **Start Small**: Test with 5-10 users first
2. **Monitor Closely**: Check trust scores daily
3. **Adjust Pricing**: Based on demand
4. **Engage Users**: Create contests
5. **Support Channel**: Create a group for support

## 📞 Need Help?

Common issues:

**Bot not responding?**
- Check if bot token is correct
- Verify bot is not blocked
- Check internet connection

**Can't verify joins?**
- Make sure channel is public
- Bot must be admin in channel
- Username must be correct

**Database errors?**
- Check file permissions
- Ensure SQLite is installed

## 🎯 Next Steps

1. **Invite Users**: Share your bot
2. **Monitor**: Watch for abuse
3. **Scale**: Add more features
4. **Profit**: Enjoy the platform fee!

---

**Ready to build your token economy! 🚀**

Need more help? Check README.md for complete documentation.
