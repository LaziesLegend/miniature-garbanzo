# 🚀 INSTALLATION GUIDE - Git Bash Terminal

## 📦 Step-by-Step Installation Commands

### Option 1: If You Have the ZIP File

```bash
# Navigate to where you downloaded the file
cd ~/Downloads

# Unzip the file
unzip telegram_bot_pro.zip

# Navigate into the folder
cd telegram_bot_pro

# Install Python dependencies
pip install -r requirements.txt

# Configure your bot (edit config.py)
nano config.py
# Or use any text editor:
# notepad config.py

# Run the bot
python main.py
```

---

### Option 2: Direct Setup (No ZIP)

If you're cloning or copying the files directly:

```bash
# Create project directory
mkdir telegram_bot_pro
cd telegram_bot_pro

# After copying all files to this directory, install dependencies
pip install -r requirements.txt

# Make setup script executable (Linux/Mac)
chmod +x setup.sh

# Run setup (optional)
./setup.sh

# Configure bot
nano config.py

# Run the bot
python main.py
```

---

## 🔧 Complete Setup Commands (Copy & Paste)

### For Windows Git Bash:

```bash
# 1. Navigate to Downloads folder
cd ~/Downloads

# 2. Unzip the file
unzip telegram_bot_pro.zip

# 3. Enter the directory
cd telegram_bot_pro

# 4. Install dependencies
pip install python-telegram-bot

# 5. Open config.py in notepad
notepad config.py

# ✏️ Edit these lines in config.py:
# BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"  # Get from @BotFather
# ADMIN_IDS = [123456789]  # Your Telegram user ID

# 6. Save and close notepad

# 7. Run the bot
python main.py
```

---

### For Linux/Mac Terminal:

```bash
# 1. Navigate to Downloads folder
cd ~/Downloads

# 2. Unzip the file
unzip telegram_bot_pro.zip

# 3. Enter the directory
cd telegram_bot_pro

# 4. Make setup script executable
chmod +x setup.sh

# 5. Run setup script (installs dependencies)
./setup.sh

# 6. Edit config file
nano config.py

# ✏️ Edit these lines:
# BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"
# ADMIN_IDS = [123456789]

# 7. Press Ctrl+X, then Y, then Enter to save

# 8. Run the bot
python main.py
```

---

## 🎯 Quick Copy-Paste Commands

### Windows (Git Bash):
```bash
cd ~/Downloads && unzip telegram_bot_pro.zip && cd telegram_bot_pro && pip install python-telegram-bot && notepad config.py
```

After editing config.py:
```bash
python main.py
```

---

### Linux/Mac:
```bash
cd ~/Downloads && unzip telegram_bot_pro.zip && cd telegram_bot_pro && chmod +x setup.sh && ./setup.sh && nano config.py
```

After editing config.py:
```bash
python main.py
```

---

## 📝 Before Running - Get Your Credentials

### 1. Get Bot Token (2 minutes):
```
1. Open Telegram
2. Search: @BotFather
3. Send: /newbot
4. Follow instructions
5. Copy the token (looks like: 1234567890:ABCdefGHI...)
```

### 2. Get Your User ID (1 minute):
```
1. Open Telegram
2. Search: @userinfobot
3. Start it
4. Copy your ID (looks like: 123456789)
```

### 3. Edit config.py:
```python
BOT_TOKEN = "1234567890:ABCdefGHI..."  # Paste your token
ADMIN_IDS = [123456789]  # Paste your ID
```

---

## ✅ Verify Installation

After running `python main.py`, you should see:

```
🚀 Starting Telegram Member Exchange Bot...
📊 Database: bot_database.db
💰 Join Reward: 90 tokens
💵 Advertiser Cost: 115 tokens
🏢 Platform Fee: 25 tokens
✅ Bot is running!
⚠️ Remember to add your BOT_TOKEN in config.py
🎹 Keyboard buttons enabled!
```

---

## 🐛 Troubleshooting Commands

### If `python` command not found:
```bash
# Try python3 instead
python3 main.py
```

### If `pip` not found:
```bash
# Try pip3
pip3 install python-telegram-bot

# Or install pip
python -m ensurepip --upgrade
```

### If `unzip` not found (Windows):
```bash
# Use PowerShell instead
powershell -command "Expand-Archive telegram_bot_pro.zip"
cd telegram_bot_pro
```

### Check Python version:
```bash
python --version
# Should be 3.8 or higher
```

### Check if dependencies installed:
```bash
pip list | grep telegram
# Should show: python-telegram-bot
```

---

## 🔄 Running in Background (Linux/Mac)

### Using nohup:
```bash
nohup python main.py > bot.log 2>&1 &
```

### Using screen:
```bash
screen -S telegram_bot
python main.py
# Press Ctrl+A then D to detach
# To reattach: screen -r telegram_bot
```

### Using tmux:
```bash
tmux new -s telegram_bot
python main.py
# Press Ctrl+B then D to detach
# To reattach: tmux attach -t telegram_bot
```

---

## 🛑 Stopping the Bot

### If running in foreground:
```bash
# Press Ctrl+C
```

### If running in background:
```bash
# Find process
ps aux | grep main.py

# Kill process (replace PID with actual number)
kill PID
```

---

## 📂 Project Structure After Unzip

```
telegram_bot_pro/
├── main.py                  # Main bot file
├── config.py                # Configuration (EDIT THIS!)
├── database.py              # Database layer
├── requirements.txt         # Dependencies
├── setup.sh                 # Setup script
├── services/
│   ├── wallet.py
│   ├── campaign.py
│   └── referral.py
├── README.md                # Full documentation
├── QUICK_START.md           # Quick guide
├── FEATURES.md              # Feature list
├── KEYBOARD_UPDATE.md       # Keyboard info
└── PROJECT_SUMMARY.md       # Overview
```

---

## 🚀 Complete Installation Script

Save this as `install.sh` and run it:

```bash
#!/bin/bash

echo "🚀 Telegram Bot Installation Script"
echo "===================================="
echo ""

# Check Python
if ! command -v python &> /dev/null; then
    echo "❌ Python not found. Please install Python 3.8+"
    exit 1
fi

echo "✅ Python found: $(python --version)"

# Unzip if needed
if [ -f "telegram_bot_pro.zip" ]; then
    echo "📦 Unzipping files..."
    unzip -q telegram_bot_pro.zip
    cd telegram_bot_pro
fi

# Install dependencies
echo "📥 Installing dependencies..."
pip install -q python-telegram-bot

echo ""
echo "✅ Installation complete!"
echo ""
echo "📝 Next steps:"
echo "1. Edit config.py - add your BOT_TOKEN and ADMIN_ID"
echo "2. Run: python main.py"
echo ""
echo "Need help? Check QUICK_START.md"
```

Make it executable and run:
```bash
chmod +x install.sh
./install.sh
```

---

## 🎯 One-Line Install & Run

### For experienced users:

```bash
cd ~/Downloads && unzip telegram_bot_pro.zip && cd telegram_bot_pro && pip install python-telegram-bot && echo "Edit config.py now!" && sleep 3 && nano config.py && python main.py
```

---

## 📞 Need Help?

If you encounter issues:

1. **Check Python version**: `python --version` (need 3.8+)
2. **Check pip**: `pip --version`
3. **Read error messages** carefully
4. **Check config.py** has correct token
5. **Check firewall** isn't blocking Python

---

## ✅ Success Checklist

- [ ] Python 3.8+ installed
- [ ] Files unzipped
- [ ] Dependencies installed
- [ ] config.py edited with bot token
- [ ] config.py edited with your user ID
- [ ] Bot running without errors
- [ ] Can message bot in Telegram
- [ ] Bot responds to /start

---

## 🎉 You're Ready!

Once you see the success message, your bot is running!

Open Telegram and search for your bot to test it.

**Happy botting! 🚀**
